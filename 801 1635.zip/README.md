# 灰燼年代 RPG

## 主專案（請改這裡）
```
game/
  index.html          # 入口
  css/game.css        # 樣式
  js/                 # 依序載入的模組
    00-utils.js
    01-sprites.js
    02-data-classes.js
    03-data-monsters.js
    04-data-equipment.js
    05-data-events-npc.js
    06-state.js
    07-combat.js
    08-explore-inventory.js
    09-render.js
    10-shop-tavern.js
```

## 其他
| 路徑 | 說明 |
|------|------|
| `docs/` | 更新公告、TODO、修補說明 |
| `archive/` | 舊單檔備份（index_mobile 等），勿當主修改目標 |
| `game.zip` | 可下載的打包 |

## 本地預覽
```bash
cd game && python3 -m http.server 8080
```
瀏覽 http://localhost:8080
