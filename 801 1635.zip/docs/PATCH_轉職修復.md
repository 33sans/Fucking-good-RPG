# 灰燼紀元 — 轉職 BUG 修復補丁

單元測試結果：**40 passed, 0 failed**（含 200 次隨機完整轉職流程）

---

## 修改 1：`routeHome` — 回營地強制重算轉職（最重要）

找到：
```js
function routeHome(){
  if(S.pendingStage==='profession') S.screen='evolve-profession';
  else if(S.pendingStage==='class') S.screen='evolve-class';
  else if(S.pendingStage==='branch') S.screen='evolve-branch';
  else S.screen='hub';
}
```

改成：
```js
function routeHome(){
  // 修復：每次回營地都重算，避免 pendingStage 因重整/異常而遺失後卡死
  if(S.hero) evaluateEvolution(S.hero);
  if(S.pendingStage==='profession') S.screen='evolve-profession';
  else if(S.pendingStage==='class') S.screen='evolve-class';
  else if(S.pendingStage==='branch') S.screen='evolve-branch';
  else S.screen='hub';
}
```

---

## 修改 2：`checkKillReward` — 主角倒地仍拿經驗

找到：
```js
  S.party.filter(m=>m.hp>0).forEach(m=> gainExp(m, exp, log));
```

改成：
```js
  // 修復：主角即使倒地也拿經驗（避免卡在轉職門檻）
  S.party.forEach(m=>{
    if(m.isHero || m.hp>0) gainExp(m, exp, log);
  });
```

---

## 修改 3：`renderEvolveClass` — 防呆，避免白屏

找到 `renderEvolveClass` 函式開頭：
```js
function renderEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
```

改成：
```js
function renderEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  if(!prof){
    S.pendingStage = null;
    S.log.unshift('職業資料異常，已返回營地。請再試一次。');
    S.screen = 'hub';
    return renderHub ? renderHub() : '<div class="panel"><p>職業資料異常，請返回營地。</p><button class="btn gold" id="back-hub-err">返回營地</button></div>';
  }
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
  if(opts.length===0){
    S.pendingStage = null;
    S.screen = 'hub';
    return '<div class="panel"><p>無可用職業路線，已返回營地。</p></div>';
  }
```

（若回傳 `renderHub()` 造成循環，可改成只回傳錯誤 panel，並在 `bindEvolveClass` 開頭加 back 按鈕綁定。）

更簡潔的安全寫法（建議用這個）：
```js
function renderEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  if(!prof || !prof.leadsTo){
    // 延後到下一幀回營地，避免 render 中改 state 再 render 的複雜度
    setTimeout(()=>{ S.pendingStage=null; S.screen='hub'; render(); }, 0);
    return `<div class="panel"><p class="event-text">職業資料異常（professionId=${esc(hero.professionId)}），正在返回營地…</p></div>`;
  }
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
  // ... 其餘不變
```

---

## 修改 4：`renderEvolveBranch` — 同樣防呆

找到：
```js
function renderEvolveBranch(){
  const hero = S.hero;
  const cls = CLASSES.find(c=>c.id===hero.classId);
  const cards = cls.advancements.map((adv,i)=>`
```

改成：
```js
function renderEvolveBranch(){
  const hero = S.hero;
  const cls = CLASSES.find(c=>c.id===hero.classId);
  if(!cls || !cls.advancements){
    setTimeout(()=>{ S.pendingStage=null; S.screen='hub'; render(); }, 0);
    return `<div class="panel"><p class="event-text">職業資料異常（classId=${esc(hero.classId)}），正在返回營地…</p></div>`;
  }
  const cards = cls.advancements.map((adv,i)=>`
```

---

## 修改 5（可選）：`bindEvolveClass` 同步防呆

```js
function bindEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  if(!prof) return; // 資料異常時不綁事件
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
  // ... 其餘不變
```

`bindEvolveBranch` 同樣：
```js
function bindEvolveBranch(){
  const hero = S.hero;
  const cls = CLASSES.find(c=>c.id===hero.classId);
  if(!cls || !cls.advancements) return;
  // ... 其餘不變
```

---

## 測試結果摘要

| 情境 | 原版 | 修復後 |
|------|------|--------|
| professionId 無效 → render | **crash 白屏** | 安全回營地 |
| 主角倒地時殺怪升等 | 不升等、不轉職 | 升等並觸發轉職 |
| pendingStage 重整遺失 | **卡在 hub 100%** | 回營地自動重觸發 100% |
| 一次從 Lv1 跳到 Lv22 鏈式轉職 | 理論可但脆弱 | 完整 profession→class→branch |
| 200 次隨機完整流程 | — | **200/200 成功** |
| 4 條生活職業 × leadsTo | 資料正確 | 全部通過 |

---

## 套用後建議自測

1. 打到主角 0 HP，讓隊友殺怪升到 5 → 應出現生活職業選擇
2. 升到 5 出現轉職畫面後 F5 重整 → 回營地應再次出現轉職
3. Console 執行（測試防呆）：
   ```js
   S.hero.level=10; S.hero.professionId='xxx'; S.pendingStage='class'; routeHome(); render();
   ```
   不應白屏
4. 正常從 1 練到 20，確認三次轉職畫面都正常跳出
