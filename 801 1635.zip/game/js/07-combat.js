/* ============ 戰鬥系統 ============ */
function startBattle(){
  const rng = Math.random;
  const avgLevel = avgPartyLevel();
  // 解鎖階級：偏「當前可打」而非一次全開
  const availableTiers = [1];
  if(avgLevel>=5) availableTiers.push(2);
  if(avgLevel>=12) availableTiers.push(3);
  if(avgLevel>=22) availableTiers.push(4);
  // Boss 僅 50 等後、較低機率
  const bossRoll = avgLevel>=50 && rng()<0.08;
  let pool = bossRoll
    ? MONSTER_TYPES.filter(m=>m.boss)
    : MONSTER_TYPES.filter(m=>!m.boss && availableTiers.includes(m.tier));
  if(pool.length===0) pool = MONSTER_TYPES.filter(m=>m.tier===1 && !m.boss);

  function pickTier(){
    if(availableTiers.length===1) return availableTiers[0];
    const top = availableTiers[availableTiers.length-1];
    const wmap = availableTiers.map(ti=>{
      let w = 10;
      if(ti===top) w = 40;
      else if(ti===top-1) w = 30;
      else w = 12;
      return {item:ti, w};
    });
    return weightedChoice(rng, wmap);
  }

  const monsters=[];
  if(bossRoll){
    const tmpl = choice(rng, pool);
    monsters.push(makeMonster(tmpl, avgLevel, rng, {}));
  } else {
    const leadRank = rollMonsterRank(avgLevel, rng);
    const tPick = pickTier();
    const sub = pool.filter(m=> m.tier===tPick);
    const leadTmpl = choice(rng, sub.length ? sub : pool);

    if(leadRank === 'king'){
      monsters.push(makeMonster(leadTmpl, avgLevel, rng, { rank:'king' }));
      for(let i=0;i<5;i++){
        const r = rng() < 0.45 ? 'refined' : 'veteran';
        monsters.push(makeMonster(leadTmpl, avgLevel, rng, { rank:r }));
      }
    } else if(leadRank === 'emperor'){
      monsters.push(makeMonster(leadTmpl, avgLevel, rng, { rank:'emperor' }));
      for(let i=0;i<5;i++){
        const t2 = pickTier();
        const sub2 = pool.filter(m=> m.tier===t2);
        const tm = choice(rng, sub2.length ? sub2 : pool);
        monsters.push(makeMonster(tm, avgLevel, rng, { rank:'king' }));
      }
    } else {
      let maxC = 3;
      if(avgLevel>=6) maxC = 4;
      if(avgLevel>=14) maxC = 5;
      if(avgLevel>=26) maxC = 6;
      if(avgLevel>=38) maxC = Math.max(6, (typeof MAX_MONSTER_PARTY!=='undefined'?MAX_MONSTER_PARTY:6));
      const weights = [];
      for(let c=2;c<=maxC;c++) weights.push({item:c, w: Math.max(1, (maxC-c+2)*2)});
      weights.forEach(w=>{ if(w.item>=3 && w.item<=4) w.w *= 1.4; });
      let count = weightedChoice(rng, weights);
      monsters.push(makeMonster(leadTmpl, avgLevel, rng, { rank: leadRank }));
      for(let i=1;i<count;i++){
        const t2 = pickTier();
        const sub2 = pool.filter(m=> m.tier===t2);
        const tm = choice(rng, sub2.length ? sub2 : pool);
        let r = rollMonsterRank(avgLevel, rng);
        if(r==='king'||r==='emperor') r = (rng()<0.5?'veteran':'elite');
        monsters.push(makeMonster(tm, avgLevel, rng, { rank: r }));
      }
    }
  }
  S.party.forEach(m=>{
    m.usedGuardianAngel=false;
    m.taunting=false; m.buffDef=0; m.buffTurns=0;
    m.skipTurn=false; m.atkDebuff=0; m.spdDebuff=0;
  });
  S.battle = {
    monsters, turnLog:[], selectedActor:null, selectedAction:null, over:false, win:null,
    order: buildTurnOrder(monsters), turnIndex:0, roundNum:1,
    bossMinionCount: 5, lastMinionRefillRound: 0
  };
  if(bossRoll){
    const boss = monsters.find(m=>m.boss) || monsters[0];
    if(boss){
      boss.boss = true;
      if(!boss.mech && boss.baseName){
        const tmpl = MONSTER_TYPES.find(m=>m.boss && m.n===boss.baseName);
        if(tmpl) boss.mech = tmpl.mech;
      }
      // 再保險：魔王血量地板
      if(num(boss.maxHp,0) < 30000){
        boss.maxHp = Math.max(30000, num(boss.maxHp,30000));
        boss.hp = boss.maxHp;
      }
    }
    S.battle.bossMinionCount = 5;
    const before = S.battle.monsters.length;
    for(let i=0;i<5;i++){
      try{
        const minion = makeBossMinion(boss, avgLevel, rng, i);
        if(minion){
          minion.isBossMinion = true;
          minion.boss = false;
          S.battle.monsters.push(minion);
        }
      }catch(err){
        // 建立失敗時用保底眷屬，避免整場沒人
        const fallback = makeMonster({n:'魔王親衛',type:(boss&&boss.type)||'beast',tier:2}, avgLevel, rng, {rank:'elite'});
        fallback.name = '魔王親衛'+(i+1);
        fallback.isBossMinion = true;
        fallback.boss = false;
        fallback.maxHp = Math.max(800, Math.round(num(boss.maxHp,30000)*0.1));
        fallback.hp = fallback.maxHp;
        fallback.minionRole = 'taunt';
        S.battle.monsters.push(fallback);
      }
    }
    const added = S.battle.monsters.length - before;
    S.battle.order = buildTurnOrder(S.battle.monsters);
    S.battle.turnLog.unshift('⚠ 強大的 Boss「'+boss.name+'」率 '+added+' 名專屬眷屬擋在前方！（HP '+boss.maxHp+'）');
    S.battle.turnLog.unshift('（每隻眷屬有獨特光環／技能；攻擊可輸送生命給 Boss；每 2 回合嘗試補齊編成）');
  }
  S.screen='battle';
  advanceBattleTurn(true);
  render();
}
function buildTurnOrder(monsters){
  const combatants = [...S.party.filter(m=>m.hp>0).map(m=>({type:'party',ref:m})), ...monsters.filter(m=>m.hp>0).map(m=>({type:'monster',ref:m}))];
  combatants.sort((a,b)=> statTotal2(b)-statTotal2(a));
  return combatants;
}
function statTotal2(c){ return c.type==='party'? statTotal(c.ref,'spd') : c.ref.spd; }
function advanceBattleTurn(first){
  const b = S.battle;
  if(!b || b.over) return;
  // rebuild order excluding dead
  b.order = buildTurnOrder(b.monsters);
  if(b.order.length===0){
    checkBattleEnd();
    return;
  }
  if(!first) b.turnIndex++;
  if(b.turnIndex >= b.order.length){
    b.turnIndex=0; b.roundNum++;
    // Boss 戰：每 2 回合補滿眷屬
    if(b.roundNum > 1 && b.roundNum % 2 === 1){
      const boss = getBattleBoss(b);
      if(boss && boss.hp>0){
        refillBossMinions(b, false);
      }
    }
    // 每回合：眷屬光環／盤根／焦土等
    if(typeof tickBossMinionAuras === 'function'){
      b._antiHeal = 0; b._missAura = 0; b._skillDampen = 0; b._mutualVuln = false;
      tickBossMinionAuras(b);
    }
    S.party.forEach(m=>{
      if(m.buffTurns>0){
        m.buffTurns--;
        if(m.buffTurns<=0){ m.buffTurns=0; m.buffDef=0; m.taunting=false; }
      }
      // 玩家中毒結算（怪物毒觸／Boss 瘟疫等）
      if(m.hp>0 && m.status==='poison' && m.statusTurns>0){
        const dmg = Math.max(1, Math.round(m.maxHp * 0.05));
        m.hp = clamp(m.hp - dmg, 0, m.maxHp);
        b.turnLog.unshift(m.name+' 受到中毒侵蝕，損失 '+dmg+' HP。');
        m.statusTurns--;
        if(m.statusTurns<=0) m.status=null;
        if(m.hp===0){
          const guardian = S.party.find(p=>p.hp>0 && hasPassive(p,'guardianAngel') && !p.usedGuardianAngel);
          if(guardian){
            m.hp=1; guardian.usedGuardianAngel=true;
            b.turnLog.unshift('⚜️ '+guardian.name+' 的守護天使發動，'+m.name+' 保住 1 HP！');
          } else {
            b.turnLog.unshift(m.name+' 中毒倒下了！');
          }
        }
      }
      if(m.hp>0 && m.maxMp>0 && m.mp < m.maxMp){
        const baseRegen = Math.max(1, Math.round(m.maxMp*0.04));
        const bonusRegen = hasPassive(m,'manaRegen') ? Math.max(1, Math.round(m.maxMp*0.06)) : 0;
        const regen = baseRegen + bonusRegen;
        m.mp = clamp(m.mp+regen, 0, m.maxMp);
        if(bonusRegen>0) b.turnLog.unshift(m.name+' 的魔力自然涌動，回復 '+regen+' MP。');
      }
    });
  }
  const current = b.order[b.turnIndex];
  if(!current || (current.type==='party'&&current.ref.hp<=0) || (current.type==='monster'&&current.ref.hp<=0)){
    return advanceBattleTurn(false);
  }
  if(current.type==='monster'){
    tickMonsterStatus(current.ref);
    checkBattleEnd();
    if(!b.over && current.ref.hp>0){
      const mon = current.ref;
      if(num(mon.stunnedTurns, 0) > 0){
        mon.stunnedTurns--;
        b.turnLog.unshift(mon.name+' 處於暈眩，本回合無法行動！');
      } else {
        monsterAct(mon);
      }
      checkBattleEnd();
    }
    if(!b.over) setTimeout(()=>{ advanceBattleTurn(false); render(); }, 550);
  }
}
function tickMonsterStatus(mon){
  const b=S.battle;
  if(mon.hasRegen && mon.hp>0 && mon.hp<mon.maxHp){
    const rate = mon.regenRate || 0.05;
    const heal = Math.max(1, Math.round(mon.maxHp*rate));
    mon.hp = clamp(mon.hp+heal, 0, mon.maxHp);
    b.turnLog.unshift(mon.name+' 再生，恢復 '+heal+' HP。');
  }
  if(mon.auraBurn && mon.hp>0){
    S.party.forEach(p=>{
      if(p.hp<=0) return;
      const bd = Math.max(1, Math.round(p.maxHp * mon.auraBurn));
      p.hp = clamp(p.hp-bd, 0, p.maxHp);
      b.turnLog.unshift(mon.name+' 的燃燒光環灼傷了 '+p.name+'（'+bd+'）。');
    });
  }
  if(mon.status==='poison' && mon.statusTurns>0){
    const dmg = Math.max(1, Math.round(mon.maxHp*(mon.poisonHeavy?0.09:0.06)));
    mon.hp = clamp(mon.hp-dmg,0,mon.maxHp);
    b.turnLog.unshift(mon.name+' 受到中毒侵蝕，損失 '+dmg+' HP。');
    mon.statusTurns--;
    if(mon.statusTurns<=0) mon.status=null;
    checkKillReward(mon, b);
    if(mon.hp===0) b.turnLog.unshift(mon.name+' 被毒素侵蝕殆盡而倒下了！');
  }
  if(mon.marked && mon.markTurns>0){
    mon.markTurns--;
    if(mon.markTurns<=0){
      mon.marked=false; mon.markMult=1; mon.markTurns=0;
      b.turnLog.unshift(mon.name+' 身上的追蹤標記消散了。');
    }
  }
}
/** 對怪物結算傷害（閃避／抗性／護盾／荊棘／不死／死亡爆炸） */

/** 戰鬥畫面回饋佇列 */
function ensureBattleFx(b){
  if(!b) return [];
  if(!b.fx) b.fx = [];
  return b.fx;
}
function pushBattleFx(kind, opts, battle){
  const b = battle || ((typeof S!=='undefined' && S) ? S.battle : null);
  if(!b) return;
  const fx = ensureBattleFx(b);
  fx.push(Object.assign({ kind: kind, t: Date.now() }, opts||{}));
  if(fx.length > 24) fx.splice(0, fx.length-24);
}
function impactLabel(dmg, crit){
  if(crit) return '會心一擊！';
  if(dmg >= 80) return '重擊！';
  if(dmg >= 40) return '削砍！';
  return null;
}
function playHitBeep(crit, kill){
  try{
    const AC = window.AudioContext || window.webkitAudioContext;
    if(!AC) return;
    if(!window._combatAC) window._combatAC = new AC();
    const ctx = window._combatAC;
    if(ctx.state==='suspended') ctx.resume();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = kill ? 'sawtooth' : (crit ? 'square' : 'triangle');
    o.frequency.value = kill ? 180 : (crit ? 520 : 320);
    g.gain.value = 0.03;
    o.connect(g); g.connect(ctx.destination);
    const now = ctx.currentTime;
    g.gain.setValueAtTime(0.04, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + (kill?0.18:0.09));
    o.frequency.exponentialRampToValueAtTime(kill?90:(crit?280:200), now+(kill?0.16:0.08));
    o.start(now); o.stop(now+(kill?0.2:0.1));
  }catch(e){}
}


function applyPlayerHitToMonster(actor, mon, hit, b, isMagic){
  hit = hit || { dmg:0, crit:false };
  if(b) b._lastHitCrit = !!hit.crit;
  const dmg = applyDamageToMonster(actor, mon, num(hit.dmg,0), !!isMagic, b);
  return dmg;
}
function applyDamageToMonster(actor, mon, rawDmg, isMagic, b){
  if(!mon || mon.hp<=0) return 0;
  // 防禦：任何上游 NaN 傷害在此截斷
  mon.maxHp = Math.max(1, num(mon.maxHp, 1));
  mon.hp = clamp(num(mon.hp, mon.maxHp), 0, mon.maxHp);
  let dmg = Math.max(0, num(rawDmg, 0));
  if(!Number.isFinite(dmg) || dmg < 0) dmg = 0;
  if(!isMagic && mon.evade && Math.random() < mon.evade){
    if(b&&b.turnLog) b.turnLog.unshift(mon.name+' 閃避了攻擊！');
    return 0;
  }
  if(b._missAura && Math.random() < b._missAura){
    b.turnLog.unshift('命中被干擾，攻擊落空！');
    return 0;
  }
  if(!isMagic && mon.physResist) dmg = Math.max(1, Math.round(dmg * (1 - num(mon.physResist, 0))));
  if(isMagic && mon.magResist) dmg = Math.max(1, Math.round(dmg * (1 - num(mon.magResist, 0))));
  if(mon.shieldCharges > 0){
    const red = mon.shieldReduce != null ? num(mon.shieldReduce, 0.5) : 0.5;
    dmg = Math.max(1, Math.round(dmg * (1 - red)));
    mon.shieldCharges--;
    b.turnLog.unshift(mon.name+' 的護盾抵銷了部分傷害（剩餘 '+mon.shieldCharges+'）。');
  }
  // Boss 眷屬防禦鉤子（替傷／分攤／反魔／抗暴等）
  if(dmg > 0 && typeof applyBossMinionDefenseHooks === 'function'){
    dmg = applyBossMinionDefenseHooks(actor, mon, dmg, isMagic, b);
  }
  // 星印：Boss 技能打有印記的人在 runBossMechanic；此處玩家打被印記的？跳過
  if(dmg > 0) mon.hp = clamp(mon.hp - dmg, 0, mon.maxHp);
  // 荊棘／反傷（帝王詞等）
  if(dmg > 0 && mon._thorns && actor && actor.hp>0){
    const ref=Math.max(1, Math.round(dmg * num(mon._thorns,0.1)));
    actor.hp=clamp(actor.hp-ref,0,actor.maxHp);
    b.turnLog.unshift(mon.name+' 反刺造成 '+ref+' 傷害！');
  }
  // 唯一裝備：吸血／回魔／擊暈
  if(dmg > 0 && actor && actor.hp > 0 && typeof equippedUniqueEffects === 'function'){
    const ls = sumEquipSpecial(actor, 'lifesteal');
    if(ls > 0){
      const heal = Math.max(1, Math.round(dmg * ls));
      actor.hp = clamp(actor.hp + heal, 0, actor.maxHp);
      b.turnLog.unshift(actor.name+' 的唯一裝備吸血恢復了 '+heal+' HP。');
    }
    const mpHit = sumEquipSpecial(actor, 'mpOnHit');
    if(mpHit > 0){
      actor.mp = clamp(actor.mp + Math.round(mpHit), 0, actor.maxMp);
    }
    const stun = sumEquipSpecial(actor, 'stunChance');
    if(stun > 0 && Math.random() < stun){
      mon.stunnedTurns = Math.max(num(mon.stunnedTurns, 0), 1);
      b.turnLog.unshift(actor.name+' 的唯一裝備使 '+mon.name+' 暈眩！');
    }
  }
  if(mon.thorns && actor && actor.hp > 0){
    const ref = Math.max(1, Math.round(dmg * mon.thorns));
    actor.hp = clamp(actor.hp - ref, 0, actor.maxHp);
    b.turnLog.unshift(mon.name+' 反彈了 '+ref+' 點傷害！');
  }
  // 唯一反傷（穿在身上時，被打才觸發 — 見 monsterAct）
  if(mon.hp <= 0 && mon.undying){
    mon.undying = false;
    mon.hp = Math.max(1, Math.round(mon.maxHp * 0.2));
    b.turnLog.unshift(mon.name+' 的不死之力發動，以殘血重生！');
  }
  if(mon.hp <= 0 && mon.deathBurst){
    S.party.forEach(p=>{
      if(p.hp<=0) return;
      const bd = Math.max(1, Math.round(p.maxHp * mon.deathBurst));
      p.hp = clamp(p.hp - bd, 0, p.maxHp);
    });
    b.turnLog.unshift(mon.name+' 死亡時發生爆炸，波及全隊！');
  }
  // 打擊回饋
  if(dmg > 0){
    const midx = (b.monsters||[]).indexOf(mon);
    const crit = !!(b._lastHitCrit);
    const killed = mon.hp <= 0;
    pushBattleFx('hit', { target:'monster', idx:midx, dmg:dmg, crit:crit, magic:!!isMagic, kill:killed }, b);
    const lab = impactLabel(dmg, crit);
    if(lab) b.turnLog.unshift(lab);
    if(killed) b.turnLog.unshift('💥 '+mon.name+' 被擊倒！');
    playHitBeep(crit, killed);
    b._hitstopMs = Math.max(num(b._hitstopMs,0), killed ? 90 : (crit ? 70 : 45));
  }
  b._lastHitCrit = false;
  return dmg;
}
function effectiveMonAtk(mon){
  let atk = mon.atk;
  if(mon.enrageAt && mon.hp <= mon.maxHp * mon.enrageAt){
    atk = Math.round(atk * (mon.enrageMult || 1.5));
  }
  return atk;
}
function runBossMechanic(mon, b){
  if(!mon.boss || !mon.mech) return;
  mon.bossTurns = (mon.bossTurns || 0) + 1;
  const t = mon.bossTurns;
  const party = S.party.filter(p=>p.hp>0);
  if(!party.length) return;
  switch(mon.mech){
    case 'inferno':
      if(t % 3 === 0){
        const bonus = 1 + num(mon._breathBonus, 0);
        party.forEach(p=>{ const d=Math.max(1,Math.round(mon.atk*0.7*bonus)); p.hp=clamp(p.hp-d,0,p.maxHp); });
        b.turnLog.unshift(mon.name+' 釋放【煉獄吐息】'+(bonus>1?'（焰心強化）':'')+'，全隊受到火焰傷害！');
      }
      break;
    case 'void':
      if(t % 4 === 0){
        const p = choice(Math.random, party);
        p.mp = clamp(p.mp - Math.round(p.maxMp*0.25), 0, p.maxMp);
        b.turnLog.unshift(mon.name+' 的【虛空汲取】抽走了 '+p.name+' 的魔力！');
      }
      if(mon._entropyBonus){
        if(mon.baseAtk == null) mon.baseAtk = num(mon.atk, 1);
        mon.atk = Math.round(num(mon.baseAtk, mon.atk) * (1 + mon._entropyBonus));
      }
      break;
    case 'reaper':
      if(mon.hp < mon.maxHp*0.4 && !mon._reaperBuff){
        mon._reaperBuff=true; mon.atk=Math.round(mon.atk*1.35);
        b.turnLog.unshift(mon.name+' 進入【收割】狀態，攻擊大幅提升！');
      }
      break;
    case 'tide':
      if(t % 3 === 0){
        const amp = 1 + num(mon._tideAmp, 0);
        const heal = Math.round(mon.maxHp*0.06*amp);
        mon.hp = clamp(mon.hp + heal, 0, mon.maxHp);
        // 侍女連攜：其他眷屬也回一點
        b.monsters.filter(m=>m.isBossMinion && m.hp>0).forEach(m=>{
          m.hp = clamp(m.hp + Math.max(1, Math.round(m.maxHp*0.04)), 0, m.maxHp);
        });
        b.turnLog.unshift(mon.name+' 藉【潮汐】恢復了 '+heal+' 生命！眷屬也沐浴潮水。');
      }
      break;
    case 'roots':
      if(t % 3 === 0){
        const p = choice(Math.random, party);
        p.skipTurn = true;
        b.turnLog.unshift(mon.name+' 的【纏繞根須】困住了 '+p.name+'！');
      }
      break;
    case 'colossus':
      if(t === 1){ mon.shieldCharges = (mon.shieldCharges||0)+3; mon.shieldReduce=0.4; b.turnLog.unshift(mon.name+' 展開【鋼鐵結界】！'); }
      break;
    case 'bloodmoon':
      if(t % 2 === 0){
        const p = choice(Math.random, party);
        let d = Math.max(1, Math.round(mon.atk*0.9));
        if((p._bleed||0)>0) d = Math.round(d * 1.25);
        p.hp = clamp(p.hp-d,0,p.maxHp);
        const suck = Math.round(d * ((p._bleed||0)>0 ? 0.7 : 0.5));
        mon.hp = clamp(mon.hp+suck,0,mon.maxHp);
        b.turnLog.unshift(mon.name+' 【血月噬咬】造成 '+d+' 傷害並吸血 '+suck+'！');
      }
      break;
    case 'frost':
      if(t % 3 === 0){
        party.forEach(p=>{ p.spdDebuff = (p.spdDebuff||0)+2; });
        b.turnLog.unshift(mon.name+' 的【永凍】減慢了全隊速度！');
      }
      break;
    case 'plague':
      if(t % 2 === 0){
        const p = choice(Math.random, party);
        p.status = 'poison'; p.statusTurns = 3;
        b.turnLog.unshift(mon.name+' 散播【瘟疫】，'+p.name+' 中毒了！');
      }
      if(mon._plagueBurst || (b && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='plague_flag') && party.filter(p=>p.status==='poison').length>=2)){
        if(t % 3 === 0){
          party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(mon.atk*0.4)), 0, p.maxHp); });
          b.turnLog.unshift(mon.name+' 引爆【疫爆】！');
          mon._plagueBurst = false;
        }
      }
      break;
    case 'shadowcourt':
      if(t % 4 === 0){ mon.evade = Math.min(0.5, (mon.evade||0)+0.15); b.turnLog.unshift(mon.name+' 隱入【影殿】，閃避提升！'); }
      break;
    case 'titan':
      if(t % 3 === 0){
        party.forEach(p=>{ const d=Math.max(1,Math.round(mon.atk*0.55)); p.hp=clamp(p.hp-d,0,p.maxHp); });
        b.turnLog.unshift(mon.name+' 【熔核重踏】震擊全隊！');
      }
      break;
    case 'kraken':
      if(t % 3 === 0){
        party.forEach(p=>{ p.hp=clamp(p.hp-Math.max(1,Math.round(mon.atk*0.4)),0,p.maxHp); });
        b.turnLog.unshift(mon.name+' 的【觸手拍擊】掃過全隊！');
      }
      break;
    case 'boneking':
      if(t % 4 === 0){
        mon.def = Math.round(mon.def*1.15);
        b.turnLog.unshift(mon.name+' 召喚骨牆，防禦上升！');
      }
      break;
    case 'berserk':
      if(mon.hp < mon.maxHp*0.5 && !mon._berserk){
        mon._berserk=true; mon.atk=Math.round(mon.atk*1.5); mon.def=Math.round(mon.def*0.8);
        b.turnLog.unshift(mon.name+' 陷入【狂戰】！');
      }
      break;
    case 'starseal':
      if(t % 5 === 0){
        party.forEach(p=>{ p.mp = clamp(p.mp - 15, 0, p.maxMp); });
        b.turnLog.unshift(mon.name+' 【星隕封印】壓制全隊魔力！');
      }
      if((mon._starCharge||0) >= 4){
        mon._starCharge = 0;
        const p = choice(Math.random, party);
        const d = Math.max(1, Math.round(mon.atk * 1.4 * (1 + 0.15 * num(p._starMark,0))));
        p.hp = clamp(p.hp - d, 0, p.maxHp);
        b.turnLog.unshift(mon.name+' 釋出星屑轟擊 '+p.name+'（'+d+'）！');
      }
      break;
    case 'nightmare':
      if(t % 3 === 0){
        const p = choice(Math.random, party);
        p.skipTurn = true;
        b.turnLog.unshift(mon.name+' 織出【夢魘】，'+p.name+' 無法行動！');
      }
      break;
    case 'judgment':
      if(t % 3 === 0){
        const p = party.slice().sort((a,b)=>b.hp-a.hp)[0];
        const d = Math.max(1, Math.round(mon.atk*1.1));
        p.hp = clamp(p.hp-d,0,p.maxHp);
        b.turnLog.unshift(mon.name+' 【聖焰審判】點名了 '+p.name+'（'+d+'）！');
      }
      break;
    case 'garden':
      if(t % 3 === 0){
        mon.hp = clamp(mon.hp + Math.round(mon.maxHp*0.08), 0, mon.maxHp);
        party.forEach(p=>{ if(Math.random()<0.4){ p.status='poison'; p.statusTurns=2; } });
        b.turnLog.unshift(mon.name+' 的【腐朽花園】蔓延，回復並散播毒素！');
      }
      break;
  }
}
/* ============================================================
 * 戰鬥公式（J 技能重做核心）
 * ------------------------------------------------------------
 * 物理：max(1, round( 物攻 × 倍率 − 敵防 × 0.50 × (1−穿甲比例) ))
 * 魔法：max(1, round( 魔攻 × 倍率 − 敵防 × 0.25 ))
 * 治療：round( 魔攻 × 係數 + 智力 × 0.6 + 等級 × 2 )
 * 自癒：round( 自身最大HP × 係數 )，可附帶回 MP
 * 暴擊率：基礎 8% + 敏捷 × 0.4%（技能可覆寫），暴擊傷害 ×1.6
 * 標記：結算後再 × markMult
 * 聖光：對 undead / shadow 額外 ×1.25
 * 普通攻擊：物攻 × (0.9~1.2 隨機)
 * ============================================================ */
const CF = {
  PHYS_DEF: 0.32,
  MAG_DEF: 0.18,
  PHYS_FLOOR: 0.28,
  MAG_FLOOR: 0.30,
  CRIT_MULT: 1.6,
  BASE_CRIT: 0.08,
  AGI_CRIT: 0.004,
  HOLY_BONUS: 1.25,
  PIERCE_RATIO: 0.30,
  ATK_VAR_MIN: 0.90,
  ATK_VAR_MAX: 1.20
};
const EVIL_TYPES = ['undead','shadow'];
function isEvilMon(mon){ return !!(mon && EVIL_TYPES.indexOf(mon.type)>=0); }
function critChance(actor, sk){
  if(sk && sk.crit != null) return clamp(sk.crit, 0, 0.95);
  let c = CF.BASE_CRIT + (actor.agi||0) * CF.AGI_CRIT;
  if(typeof sumEquipSpecial === 'function') c += sumEquipSpecial(actor, 'critBonus');
  return clamp(c, 0, 0.85);
}
function rollCrit(actor, sk){ return Math.random() < critChance(actor, sk); }
function pierceIgnore(actor, targetDef){
  let ratio = hasPassive(actor,'pierce') ? CF.PIERCE_RATIO : 0;
  if(typeof sumEquipSpecial === 'function') ratio += sumEquipSpecial(actor, 'pierceBonus');
  return targetDef * Math.min(0.6, ratio);
}
function markMultOf(target){
  let m = (target && target.marked && target.markMult) ? target.markMult : 1;
  if(target && target.markVulnerable && m > 1) m *= target.markVulnerable;
  return m;
}
/** 物理傷害。opts: {mult, variance, canCrit, sk, forceCrit} */
function calcPhysDmg(actor, target, opts){
  opts = opts || {};
  const mult = num(opts.mult != null ? opts.mult : 1, 1);
  const atk = Math.max(1, num(statTotal(actor,'atk'), 1));
  const def = Math.max(0, num(target && target.def, 0));
  const ignore = num(pierceIgnore(actor, def), 0);
  let variance = 1;
  if(opts.variance){
    variance = CF.ATK_VAR_MIN + Math.random() * (CF.ATK_VAR_MAX - CF.ATK_VAR_MIN);
  }
  const raw = atk * mult * variance;
  const mitigated = raw - (def - ignore) * CF.PHYS_DEF;
  const floor = raw * (CF.PHYS_FLOOR != null ? CF.PHYS_FLOOR : 0.28);
  let dmg = Math.max(1, Math.round(Math.max(floor, mitigated)));
  const didCrit = opts.forceCrit || (opts.canCrit && rollCrit(actor, opts.sk));
  if(didCrit) dmg = Math.round(dmg * CF.CRIT_MULT);
  dmg = Math.round(dmg * num(markMultOf(target), 1));
  return { dmg: Math.max(1, num(dmg, 1)), crit: !!didCrit, marked: markMultOf(target) > 1 };
}
/** 魔法傷害。opts: {mult, holy, sk} */
function calcMagicDmg(actor, target, opts){
  opts = opts || {};
  const mult = num(opts.mult != null ? opts.mult : 1, 1);
  const matk = Math.max(1, num(statTotal(actor,'matk'), 1));
  const def = Math.max(0, num(target && target.def, 0));
  let raw = matk * mult;
  if(typeof sumUniqueEffect === 'function'){
    const burn = sumEquipSpecial(actor, 'burnBonus');
    if(burn > 0) raw *= (1 + burn);
  }
  const mitigated = raw - def * CF.MAG_DEF;
  const floor = raw * (CF.MAG_FLOOR != null ? CF.MAG_FLOOR : 0.30);
  let dmg = Math.max(1, Math.round(Math.max(floor, mitigated)));
  if(opts.holy && isEvilMon(target)) dmg = Math.round(dmg * CF.HOLY_BONUS);
  dmg = Math.round(dmg * num(markMultOf(target), 1));
  return { dmg: Math.max(1, num(dmg, 1)), crit: false, marked: markMultOf(target) > 1, holy: !!(opts.holy && isEvilMon(target)) };
}
/** 治療量（單體／群體共用係數） */
function calcHealAmt(actor, healCoef){
  const matk = statTotal(actor,'matk');
  const intel = actor.int || 0;
  let amt = matk * (healCoef||1) + intel * 0.6 + actor.level * 2;
  if(typeof sumEquipSpecial === 'function') amt *= (1 + sumEquipSpecial(actor, 'healBonus'));
  if(S && S.battle && S.battle._antiHeal) amt *= (1 - Math.min(0.5, S.battle._antiHeal));
  return Math.max(1, Math.round(amt));
}
function dmgTag(r){
  let t = '';
  if(r.crit) t += '（會心一擊！）';
  if(r.holy) t += '（聖光克邪）';
  if(r.marked) t += '（標記加成）';
  return t;
}

function monsterAct(mon){
  const b=S.battle;
  runBossMechanic(mon, b);
  const aliveParty = S.party.filter(m=>m.hp>0);
  if(aliveParty.length===0) return;

  const attackOnce = (target)=>{
    let atk = Math.max(1, num(effectiveMonAtk(mon), 1));
    if(mon.execute && target.hp < target.maxHp * 0.5) atk = Math.round(atk * num(mon.execute, 1));
    // 怪物打人：同級要有痛感（保底提高、防禦折算再降）
    const rawM = atk * (1.00 + Math.random()*0.28);
    const mitM = rawM - num(statTotal(target,'def'),0)*0.18;
    let dmg = Math.max(1, Math.round(Math.max(rawM*0.48, mitM)));
    if(mon.arcBonus) dmg = Math.round(dmg * (1 + mon.arcBonus * 0.5));
    let blocked = false;
    if(hasPassive(target,'block') && Math.random()<0.18){
      dmg = Math.max(1, Math.round(dmg*0.65));
      blocked = true;
    }
    // 唯一：受傷減免
    if(typeof sumUniqueEffect === 'function'){
      const dr = sumEquipSpecial(target, 'dmgReduce');
      if(dr > 0) dmg = Math.max(1, Math.round(dmg * (1 - Math.min(0.4, dr))));
    }
    target.hp = clamp(target.hp-dmg,0,target.maxHp);
    b.turnLog.unshift(mon.name+' 攻擊了 '+target.name+'，造成 '+dmg+' 點傷害。'+(blocked?'（格擋減傷！）':''));
    const pidx = S.party.indexOf(target);
    pushBattleFx('hit', { target:'party', idx:pidx, dmg:dmg, crit:false, magic:false, kill: target.hp<=0 }, b);
    playHitBeep(false, target.hp<=0);
    b._hitstopMs = Math.max(num(b._hitstopMs,0), target.hp<=0 ? 80 : 40);
    if(target.hp<=0){
      const boss = getBattleBoss(b);
      if(boss && boss.hp>0 && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='on_ko_buff')){
        boss.atk = Math.round(num(boss.atk,1) * 1.12);
        b.turnLog.unshift('終末鴉振翅：'+boss.name+' 因敵人倒下而攻擊暴衝！');
      }
    }
    // 唯一：反傷
    if(typeof sumUniqueEffect === 'function' && dmg > 0 && mon.hp > 0){
      const th = sumEquipSpecial(target, 'thorns');
      if(th > 0){
        const ref = Math.max(1, Math.round(dmg * th));
        mon.hp = clamp(mon.hp - ref, 0, mon.maxHp);
        b.turnLog.unshift(target.name+' 的唯一裝備反彈了 '+ref+' 點傷害！');
      }
    }
    // Boss 眷屬：攻擊傷害的 25% 轉為 Boss 回血 + 專屬命中效果
    if(mon.isBossMinion && dmg > 0){
      const boss = getBattleBoss(b);
      if(boss && boss.hp > 0){
        let ratio = 0.25;
        if(mon.minionRole==='tide_echo') ratio = 0.15;
        if(mon.minionRole==='leech_cc' && target.skipTurn) ratio = 0.4;
        const heal = Math.max(1, Math.round(dmg * ratio));
        boss.hp = clamp(boss.hp + heal, 0, boss.maxHp);
        b.turnLog.unshift('🩸 '+mon.name+' 為 '+boss.name+' 輸送生命 +'+heal+'！');
      }
      if(typeof applyMinionOnHit === 'function') applyMinionOnHit(mon, target, dmg, b);
    }
    if(mon.vampiric || mon._vampRate){
      const rate = num(mon._vampRate, (typeof mon.vampiric==='number' ? mon.vampiric : 0.25));
      const heal = Math.max(1, Math.round(dmg * rate));
      mon.hp = clamp(mon.hp+heal, 0, mon.maxHp);
      b.turnLog.unshift(mon.name+' 吸血恢復了 '+heal+' HP。');
    }
    // 帝王／詞條命中效果
    if(dmg>0 && mon._poisonOnHit){
      target.status='poison'; target.statusTurns=Math.max(num(target.statusTurns,0), 2);
    }
    if(dmg>0 && mon._rootOnHit && Math.random()<0.2){
      target.skipTurn=true;
      b.turnLog.unshift(mon.name+' 纏住了 '+target.name+'！');
    }
    if(dmg>0 && mon._lifeTap){
      mon.hp=clamp(mon.hp+Math.max(1,Math.round(dmg*0.2)),0,mon.maxHp);
    }
    if(dmg>0 && mon._goldSteal && S.hero){
      const g=Math.min(S.hero.gold||0, rint(Math.random,1,5));
      if(g>0){ S.hero.gold-=g; b.turnLog.unshift(mon.name+' 偷走了 '+g+' 金幣！'); }
    }
    if(mon.poisonTouch){
      target.status = 'poison';
      target.statusTurns = mon.poisonHeavy ? 4 : 3;
      b.turnLog.unshift(target.name+' 中毒了！');
    }
    if(mon.manaBurn){
      const burn = Math.max(3, Math.round(target.maxMp * 0.08));
      target.mp = clamp(target.mp - burn, 0, target.maxMp);
      b.turnLog.unshift(mon.name+' 灼燒了 '+target.name+' 的魔力（-'+burn+' MP）！');
    }
    if(mon.chillTouch){
      target.spdDebuff = (target.spdDebuff||0) + 3;
      b.turnLog.unshift(target.name+' 被寒氣侵襲，速度下降！');
    }
    if(mon.crippleTouch){
      target.atkDebuff = (target.atkDebuff||0) + Math.max(1, Math.round(statTotal(target,'atk')*0.08));
      b.turnLog.unshift(target.name+' 被致殘，攻擊力下降！');
    }
    if(mon.stunChance && Math.random() < mon.stunChance){
      target.skipTurn = true;
      b.turnLog.unshift(target.name+' 被震暈，下回合無法行動！');
    }
    if(target.hp===0){
      const guardian = S.party.find(p=>(p.hp>0 || p.uid===target.uid) && hasPassive(p,'guardianAngel') && !p.usedGuardianAngel);
      if(guardian){
        target.hp = 1;
        guardian.usedGuardianAngel = true;
        b.turnLog.unshift('⚜️ '+guardian.name+' 的守護天使發動，'+target.name+' 奇蹟般保住了 1 點HP！');
      } else {
        b.turnLog.unshift(target.name+' 倒下了！');
      }
    }
  };

  // 選目標：嘲諷（鐵志可無視）
  let tauntTarget = aliveParty.find(m=>m.taunting);
  if(tauntTarget && mon.ignoreTaunt && Math.random() < mon.ignoreTaunt) tauntTarget = null;
  const mainTarget = tauntTarget || choice(Math.random, aliveParty);

  if(mon.aoeAtk && Math.random() < mon.aoeAtk){
    b.turnLog.unshift(mon.name+' 使出橫掃！');
    S.party.filter(m=>m.hp>0).forEach(p=> attackOnce(p));
  } else {
    attackOnce(mainTarget);
    if(mon.doubleAtk && Math.random() < mon.doubleAtk && mainTarget.hp > 0){
      b.turnLog.unshift(mon.name+' 追加連擊！');
      attackOnce(mainTarget);
    }
  }
}
function playerAction(actorUid, action, targetIdx, skillIdx, potionUid){
  const b=S.battle;
  if(!b || b.over) return;
  const actor = S.party.find(m=>m.uid===actorUid);
  if(!actor || actor.hp<=0) return;
  actor.taunting=false;
  if(actor.skipTurn){
    actor.skipTurn=false;
    b.turnLog.unshift(actor.name+' 仍受控無法行動！');
    checkBattleEnd();
    if(!b.over) advanceBattleTurn(false);
    render();
    return;
  }
  if(action==='attack'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    const r = calcPhysDmg(actor, target, { mult:1, variance:true, canCrit:true, sk:null });
    const dealt = (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, target, r.dmg, false, b));
    if(dealt>0) b.turnLog.unshift(actor.name+' 攻擊了 '+target.name+'，造成 '+dealt+' 點傷害'+dmgTag(r)+'。');
    if(hasPassive(actor,'doubleStrike') && target.hp>0 && Math.random()<0.22){
      const r2 = calcPhysDmg(actor, target, { mult:0.55, canCrit:false });
      const d2 = (b._lastHitCrit=!!(r2).crit, applyDamageToMonster(actor, target, r2.dmg, false, b));
      if(d2>0) b.turnLog.unshift(actor.name+' 觸發追加攻擊，額外造成 '+d2+' 點傷害！');
    }
    if(hasPassive(actor,'virulence') && target.hp>0 && !target.status && Math.random()<0.25){
      target.status='poison'; target.statusTurns=3;
      b.turnLog.unshift(target.name+' 被腐蝕氣息感染，陷入中毒狀態！');
    }
    if(hasPassive(actor,'combatFlow')){
      actor.mp = clamp(actor.mp+4,0,actor.maxMp);
    }
    checkKillReward(target, b);
    if(target.hp===0) b.turnLog.unshift(target.name+' 被擊敗了！');
  } else if(action==='skill'){
    const sk = getSkills(actor)[skillIdx];
    if(!sk){ render(); return; }
    if(actor._skillJam){
      actor._skillJam = 0;
      b.turnLog.unshift(actor.name+' 遭到干擾，技能施放失敗！');
      checkBattleEnd();
      if(!b.over) advanceBattleTurn(false);
      render(); return;
    }
    const needMp = num(sk.mp, 0);
    if(actor.mp < needMp){ b.turnLog.unshift(actor.name+' 的MP不足以使用 '+sk.name+'！'); render(); return; }
    actor.mp -= needMp;
    applySkill(actor, sk, targetIdx, b);
  } else if(action==='item'){
    const item = potionUid ? S.inventory.find(i=>i.uid===potionUid) : S.inventory.find(i=>i.slot==='potion');
    if(!item){ render(); return; }
    const potName = item.name;
    const potVal = item.value;
    const potKind = item.kind;
    if(!consumePotion(item)){ render(); return; }
    if(potKind==='mp'){
      actor.mp = clamp(actor.mp+potVal,0,actor.maxMp);
      b.turnLog.unshift(actor.name+' 使用了 '+potName+'，恢復 '+potVal+' MP。');
    } else {
      actor.hp = clamp(actor.hp+potVal,0,actor.maxHp);
      b.turnLog.unshift(actor.name+' 使用了 '+potName+'，恢復 '+potVal+' HP。');
    }
  } else if(action==='defend'){
    actor.buffDef = Math.round(statTotal(actor,'def')*0.5); actor.buffTurns=1;
    b.turnLog.unshift(actor.name+' 擺出防禦姿態。');
  } else if(action==='flee'){
    const chance = 0.4 + statTotal(actor,'spd')*0.01;
    if(Math.random()<chance){
      b.turnLog.unshift('隊伍成功逃離了戰鬥！');
      b.over=true; b.win='flee';
      routeHome();
      render(); return;
    } else {
      b.turnLog.unshift(actor.name+' 試圖逃跑，但失敗了！');
    }
  }
  checkBattleEnd();
  if(!b.over) advanceBattleTurn(false);
  render();
}
function applySkill(actor, sk, targetIdx, b){
  const type = sk.type;
  if(type==='mark'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    target.marked = true;
    target.markTurns = sk.markTurns||3;
    target.markMult = sk.markMult||1.35;
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」標記了 '+target.name+'！'+target.markTurns+' 回合內受傷提升 '+Math.round((target.markMult-1)*100)+'%。');
  } else if(type==='phys' || type==='phys_crit'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    const skCrit = Object.assign({}, sk, { crit: sk.crit != null ? sk.crit : (type==='phys_crit' ? 0.45 : undefined) });
    const r = calcPhysDmg(actor, target, { mult: sk.mult||1, canCrit:true, sk: skCrit });
    const dealt = (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, target, r.dmg, false, b));
    if(dealt>0) b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」對 '+target.name+' 造成 '+dealt+' 點傷害'+dmgTag(r)+'。');
    if(sk.poison && target.hp>0){ target.status='poison'; target.statusTurns=sk.poisonTurns||3; b.turnLog.unshift(target.name+' 中毒了！'); }
    checkKillReward(target, b);
    if(target.hp===0) b.turnLog.unshift(target.name+' 被擊敗了！');
  } else if(type==='magic'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    const r = calcMagicDmg(actor, target, { mult: sk.mult||1, holy: !!sk.holy });
    const dealt = (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, target, r.dmg, true, b));
    if(dealt>0) b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」對 '+target.name+' 造成 '+dealt+' 點傷害'+dmgTag(r)+'。');
    checkKillReward(target, b);
    if(target.hp===0) b.turnLog.unshift(target.name+' 被擊敗了！');
  } else if(type==='phys_multi' || type==='phys_multi2'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    const hits = sk.hits || (type==='phys_multi' ? 3 : 2);
    let total=0, anyMark=false;
    for(let i=0;i<hits;i++){
      if(target.hp<=0) break;
      const r = calcPhysDmg(actor, target, { mult: sk.mult||1, canCrit: !!sk.canCrit, sk });
      total += (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, target, r.dmg, false, b));
      if(r.marked) anyMark=true;
    }
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」共 '+hits+' 擊，造成 '+total+' 點傷害'+(anyMark?'（標記加成）':'')+'。');
    if(sk.poison && target.hp>0){ target.status='poison'; target.statusTurns=sk.poisonTurns||3; }
    checkKillReward(target, b);
    if(target.hp===0) b.turnLog.unshift(target.name+' 被擊敗了！');
  } else if(type==='magic_aoe' || type==='magic_dot'){
    let total=0;
    b.monsters.forEach(mo=>{
      if(mo.hp<=0) return;
      const r = calcMagicDmg(actor, mo, { mult: sk.mult||1, holy: !!sk.holy });
      total += (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, mo, r.dmg, true, b));
      if(type==='magic_dot' || sk.poison){ mo.status='poison'; mo.statusTurns=sk.poisonTurns||3; }
      checkKillReward(mo, b);
    });
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」對全體造成共 '+total+' 點傷害'+(type==='magic_dot'||sk.poison?'，並附加中毒':'')+'。');
  } else if(type==='heal'){
    const target = S.party[targetIdx];
    if(!target) return;
    let amt = calcHealAmt(actor, sk.heal||1);
    if(hasPassive(actor,'mercyHeal') && target.hp > 0 && target.hp < target.maxHp*0.3) amt = Math.round(amt*1.25);
    const r = applyHealToMember(target, amt, {canRevive:true, reviveRatio:0.25});
    if(r.revived){
      b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」救起了 '+target.name+'（回復 '+r.healed+' HP，為治療量的 25%）！');
    } else {
      b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」為 '+target.name+' 恢復 '+r.healed+' HP。');
    }
  } else if(type==='heal_aoe'){
    const amt = calcHealAmt(actor, sk.heal||0.8);
    const revived = [];
    S.party.forEach(m=>{
      const r = applyHealToMember(m, amt, {canRevive:true, reviveRatio:0.25});
      if(r.revived) revived.push(m.name);
    });
    let msg = actor.name+' 使用了「'+sk.name+'」為全隊恢復 '+amt+' HP。';
    if(revived.length) msg += ' '+revived.join('、')+' 被救起（回復治療量的 25%）！';
    b.turnLog.unshift(msg);
  } else if(type==='buff'){
    const turns = sk.buffTurns||2;
    const ratio = sk.buffDefRatio != null ? sk.buffDefRatio : 0.20;
    S.party.forEach(m=>{
      if(m.hp>0){ m.buffDef = Math.round(statTotal(m,'def')*ratio); m.buffTurns=turns; }
    });
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」，全隊防禦提升 '+Math.round(ratio*100)+'%（'+turns+' 回合）！');
  } else if(type==='guard'){
    const turns = sk.buffTurns||2;
    const ratio = sk.buffDefRatio != null ? sk.buffDefRatio : 0.60;
    actor.taunting=true;
    actor.buffDef=Math.round(statTotal(actor,'def')*ratio);
    actor.buffTurns=turns;
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」，嘲諷敵人並提升防禦 '+Math.round(ratio*100)+'%（'+turns+' 回合）！');
  } else if(type==='steal'){
    const target = b.monsters[targetIdx];
    if(!target||target.hp<=0) return;
    const r = calcPhysDmg(actor, target, { mult: sk.mult||1.1, canCrit:false });
    const dealt = (b._lastHitCrit=!!(r).crit, applyDamageToMonster(actor, target, r.dmg, false, b));
    const stolen = rint(Math.random, sk.stealMin||5, sk.stealMax||15);
    S.hero.gold += stolen;
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」，造成 '+dealt+' 傷害並偷得 '+stolen+' 金幣。');
    checkKillReward(target, b);
    if(target.hp===0) b.turnLog.unshift(target.name+' 被擊敗了！');
  } else if(type==='self_heal'){
    const amt = Math.max(1, Math.round(actor.maxHp * (sk.heal||0.2)));
    const mpGain = sk.mpGain != null ? sk.mpGain : 10;
    actor.hp = clamp(actor.hp+amt,0,actor.maxHp);
    actor.mp = clamp(actor.mp+mpGain,0,actor.maxMp);
    b.turnLog.unshift(actor.name+' 使用了「'+sk.name+'」，恢復 '+amt+' HP 與 '+mpGain+' MP。');
  }
  if(hasPassive(actor,'combatFlow') && ['phys','phys_crit','phys_multi','phys_multi2'].includes(type)){
    actor.mp = clamp(actor.mp+5,0,actor.maxMp);
  }
}
function checkKillReward(mon, b){
  if(mon.hp>0 || mon.rewarded) return;
  // 眷屬死亡特效（可能再起則暫不標 rewarded）
  if(mon.isBossMinion && typeof onBossMinionDeath === 'function'){
    const hpBefore = mon.hp;
    onBossMinionDeath(mon, b);
    if(mon.hp > 0){ return; } // 再起
  }
  if(mon.rewarded) return;
  mon.rewarded = true;
  const affixCount = mon.affixes ? mon.affixes.length : 0;
  const mult = 1 + affixCount*0.2;
  const exp = Math.max(0, Math.round(num(mon.exp, 0)*mult));
  const gold = Math.max(0, Math.round(num(mon.gold, 0)*mult));
  const log=[];
  // 倒地隊友也拿經驗（避免落後等級／卡成長）
  S.party.forEach(m=> gainExp(m, exp, log));
  S.hero.gold = num(S.hero.gold, 0) + gold;
  b.turnLog.unshift('獲得 '+exp+' 經驗值與 '+gold+' 金幣。'+(affixCount>0?'（詞綴加成 x'+mult.toFixed(1)+'）':''));
  log.forEach(l=> b.turnLog.unshift(l));
}
function checkBattleEnd(){
  const b=S.battle;
  if(b.monsters.every(m=>m.hp<=0)){
    if(!b.over){
      b.over=true; b.win=true;
      b.turnLog.unshift('=== 戰鬥勝利！ ===');
      let dropped=[];
      b.monsters.forEach(m=>{
        const affixCount = m.affixes ? m.affixes.length : 0;
        const dropChance = m.boss?1:(m.elite?0.55:(m.tier>=3?0.5:0.28)) + affixCount*0.08;
        if(Math.random()<dropChance){
          let floor = m.boss ? 'epic' : (m.elite ? 'rare' : null);
          if(affixCount>=3) floor='legend';
          else if(affixCount>=2) floor= floor || 'epic';
          else if(affixCount>=1 && !floor) floor='rare';
          const item = rollEquip(Math.random, floor, m.level);
          if(addToInventory(item)) dropped.push(item.name);
        }
      });
      if(dropped.length) b.turnLog.unshift('掉落裝備：'+dropped.join('、'));
    }
  } else if(S.party.every(m=>m.hp<=0)){
    b.over=true; b.win=false;
    b.turnLog.unshift('=== 隊伍全滅……你們狼狽地撤退了 ===');
    S.party.forEach(m=> m.hp = Math.max(m.hp, Math.round(m.maxHp*0.15)));
    S.hero.gold = Math.round(S.hero.gold*0.7);
    S.shopStock = null; // 復活後商店自動免費刷新一批新商品
  }
}

