/* ============ 資料：職業 ============ */
const PALETTES = {
  fire:['#c94a3b','#e07a3f','#f2c14e'],
  water:['#2f6a8f','#4ba3c7','#8fd0e0'],
  nature:['#3d7a3d','#6ba84f','#a8d878'],
  shadow:['#3a2d52','#6b4a8a','#a06bc9'],
  undead:['#4a5a3d','#7a8f5a','#c9d8a0'],
  beast:['#6b4a2f','#9a6b3f','#c9a05f'],
  holy:['#c9a63f','#e8d078','#fff2c0'],
  metal:['#5a5a6b','#8a8a9a','#c0c0d0'],
  blood:['#5a1a1f','#8f2a30','#c94a4a'],
  ice:['#3a5a7a','#6b9ac9','#c0e8f0']
};
const PROFESSION_LEVEL = 5;
const CLASS_LEVEL = 10;
const BRANCH_LEVEL = 20;

/* 第0階：普通人 —— 所有人的起點 */
const COMMONER = {
  name:'普通人', palette:PALETTES.metal,
  base:{hp:70,mp:15,atk:8,def:6,spd:8}, grow:{hp:6,mp:1,atk:0.8,def:0.6,spd:0.6},
  skills:[{name:'拼命揮擊',mp:5,mult:1.15,type:'phys',desc:'物攻×1.15 − 防×0.5。尚未覺醒時的全力一擊'}]
};

/* 第1階（Lv.5）：4種生活職業，決定未來的成長方向 */
const PROFESSIONS = [
  {id:'farmer', name:'農夫', tag:'刻苦耐勞，體魄強健 → 通往戰士／武僧', palette:PALETTES.beast,
    statBonus:{hp:25,mp:0,atk:3,def:5,spd:0}, growBonus:{hp:3,mp:0,atk:0.5,def:0.6,spd:0},
    skill:{name:'咬牙硬撐',mp:6,type:'self_heal',heal:0.18,mpGain:8,desc:'恢復最大HP×18% + 8 MP'},
    leadsTo:['warrior','monk']},
  {id:'merchant', name:'商人', tag:'八面玲瓏，善於交涉 → 通往牧師／聖騎士', palette:PALETTES.holy,
    statBonus:{hp:15,mp:10,atk:1,def:4,spd:1}, growBonus:{hp:1.5,mp:1,atk:0.3,def:0.4,spd:0.2},
    skill:{name:'精明議價',mp:6,type:'steal',mult:1.0,stealMin:8,stealMax:18,desc:'物攻×1.0 的傷害，並偷取 8~18 金幣'},
    leadsTo:['cleric','paladin']},
  {id:'hunter', name:'獵人', tag:'身手矯健，眼光精準 → 通往弓箭手／盜賊', palette:PALETTES.nature,
    statBonus:{hp:10,mp:2,atk:4,def:1,spd:6}, growBonus:{hp:1,mp:0.2,atk:0.6,def:0.2,spd:0.8},
    skill:{name:'追蹤標記',mp:6,type:'mark',markTurns:3,markMult:1.35,desc:'輔助：標記目標 3 回合，期間受到傷害 +35%（不造成直接傷害）'},
    leadsTo:['archer','rogue']},
  {id:'apprentice', name:'學徒', tag:'博覽群書，初窺門道 → 通往法師／死靈法師', palette:PALETTES.ice,
    statBonus:{hp:0,mp:20,atk:2,def:0,spd:1}, growBonus:{hp:0,mp:2,atk:0.3,def:0,spd:0.1},
    skill:{name:'魔力衝擊',mp:8,mult:1.25,type:'magic',desc:'魔攻×1.25 − 防×0.25 的魔法傷害'},
    leadsTo:['mage','necromancer']}
];

/* 第2階（Lv.10）：8大職業，各自擁有獨特被動能力 + 專屬技能 */
const CLASSES = [
  {id:'warrior', name:'戰士', tag:'前排肉盾，穩定物理輸出', palette:PALETTES.metal,
    statBonus:{hp:48,mp:5,atk:8,def:14,spd:0}, growBonus:{hp:10,mp:1,atk:1.6,def:2.2,spd:0.6},
    passive:{id:'block', name:'格擋', desc:'受到攻擊時有機率格擋，減少35%傷害'},
    skills:[{name:'猛力斬',mp:8,mult:1.85,type:'phys',desc:'物攻×1.85 − 防×0.5'},{name:'守護怒吼',mp:12,type:'buff',buffDefRatio:0.22,buffTurns:2,desc:'全隊防禦+22%，2 回合'},{name:'嘲諷怒吼',mp:10,type:'guard',buffDefRatio:0.55,buffTurns:2,desc:'嘲諷；自身防禦+55%，2 回合'}],
    advancements:[
      {id:'berserker', name:'狂戰士', desc:'捨棄防禦換取毀滅性輸出，越戰越狂暴。',
        statBonus:{hp:15,mp:0,atk:10,def:-3,spd:3}, growBonus:{hp:3,mp:0,atk:1.8,def:0.5,spd:0.3},
        skill:{name:'血怒連斬',mp:12,mult:2.3,type:'phys_multi',desc:'狂暴狀態下連續揮砍兩次'}},
      {id:'guardian', name:'守護者', desc:'化身移動堡壘，替隊友承受所有傷害。',
        statBonus:{hp:30,mp:5,atk:2,def:12,spd:-2}, growBonus:{hp:5,mp:0.5,atk:0.8,def:1.6,spd:0.2},
        skill:{name:'不動堡壘',mp:14,type:'guard',desc:'嘲諷全體敵人並大幅提升自身防禦'}},
      {id:'holyblade', name:'聖鋒騎士', desc:'劍與信仰並重，攻防兼具的聖光戰士。',
        statBonus:{hp:18,mp:10,atk:8,def:6,spd:2}, growBonus:{hp:3,mp:1,atk:1.3,def:1,spd:0.3},
        skill:{name:'聖輝斬',mp:16,mult:1.9,type:'magic',holy:true,desc:'魔攻×1.9；對亡靈／暗影再×1.25'}}
    ]},
  {id:'mage', name:'法師', tag:'高魔法輸出，血脆需保護', palette:PALETTES.fire,
    statBonus:{hp:5,mp:45,atk:4,def:1,spd:1}, growBonus:{hp:2,mp:6,atk:0.8,def:0.4,spd:0.6},
    passive:{id:'manaRegen', name:'魔力涌動', desc:'每回合開始自動回復少量MP'},
    skills:[{name:'烈焰爆破',mp:16,mult:2.45,type:'magic',desc:'魔攻×2.45 − 防×0.25'},{name:'烈焰風暴',mp:26,mult:1.35,type:'magic_aoe',desc:'魔攻×1.35／敵'}],
    advancements:[
      {id:'pyromancer', name:'烈焰宗師', desc:'將烈焰之力推向極致的毀滅法師。',
        statBonus:{hp:0,mp:15,atk:12,def:0,spd:0}, growBonus:{hp:0,mp:1.5,atk:1.8,def:0,spd:0},
        skill:{name:'超新星',mp:30,mult:1.7,type:'magic_aoe',desc:'毀滅性的全體火焰爆炸'}},
      {id:'elementalist', name:'元素賢者', desc:'掌控多重元素，擅長附加異常狀態。',
        statBonus:{hp:10,mp:20,atk:6,def:0,spd:0}, growBonus:{hp:1.5,mp:2,atk:1,def:0,spd:0},
        skill:{name:'寒冰烈焰',mp:20,mult:1.4,type:'magic_dot',desc:'元素複合傷害並附加中毒效果'}},
      {id:'arcanist', name:'秘術學者', desc:'鑽研秘術護持之道，戰場上的魔法支援核心。',
        statBonus:{hp:0,mp:25,atk:0,def:5,spd:0}, growBonus:{hp:0,mp:2.5,atk:0,def:0.8,spd:0},
        skill:{name:'虛無屏障',mp:22,heal:0.5,type:'heal_aoe',desc:'轉化秘術能量為全隊護盾（恢復HP）'}}
    ]},
  {id:'archer', name:'弓箭手', tag:'高敏捷單體爆發，先手優勢', palette:PALETTES.nature,
    statBonus:{hp:18,mp:15,atk:13,def:2,spd:9}, growBonus:{hp:3.5,mp:1.5,atk:2.1,def:0.5,spd:1.3},
    passive:{id:'pierce', name:'破甲', desc:'普通攻擊與技能皆無視部分敵人防禦'},
    skills:[{name:'精準射擊',mp:10,mult:2.25,type:'phys',desc:'物攻×2.25 − 防×0.5（破甲另算）'},{name:'連射',mp:14,mult:1.05,type:'phys_multi',hits:3,desc:'3 連擊，每段物攻×1.05'}],
    advancements:[
      {id:'ranger', name:'遊俠', desc:'精通穿甲箭術，專職單體爆發。',
        statBonus:{hp:0,mp:0,atk:8,def:0,spd:6}, growBonus:{hp:0,mp:0,atk:1.5,def:0,spd:1.2},
        skill:{name:'穿透射擊',mp:14,mult:2.2,type:'phys_crit',desc:'高暴擊率的穿甲箭'}},
      {id:'shadowhunter', name:'影襲獵手', desc:'潛行於暗處，以毒箭連續狙殺目標。',
        statBonus:{hp:0,mp:0,atk:5,def:0,spd:10}, growBonus:{hp:0,mp:0,atk:1,def:0,spd:1.8},
        skill:{name:'暗影連射',mp:16,mult:1.0,type:'phys_multi',desc:'連續射出三支毒箭'}},
      {id:'hawkeye', name:'鷹眼哨兵', desc:'穩紮穩打的狙擊專家，一擊必殺。',
        statBonus:{hp:10,mp:0,atk:6,def:6,spd:0}, growBonus:{hp:1.5,mp:0,atk:1,def:1,spd:0},
        skill:{name:'狙擊絕殺',mp:20,mult:2.6,type:'phys',desc:'蓄力後的致命一擊'}}
    ]},
  {id:'rogue', name:'盜賊', tag:'暴擊與偷竊，機動性極高', palette:PALETTES.shadow,
    statBonus:{hp:15,mp:10,atk:9,def:1,spd:10}, growBonus:{hp:3,mp:1,atk:1.5,def:0.4,spd:1.4},
    passive:{id:'doubleStrike', name:'連攻', desc:'普通攻擊有機率觸發追加攻擊'},
    skills:[{name:'背刺',mp:9,mult:2.2,type:'phys_crit',crit:0.48,desc:'物攻×2.2，爆擊率 48%'},{name:'掠奪',mp:8,type:'steal',mult:1.15,stealMin:6,stealMax:16,desc:'物攻×1.15 + 偷 6~16 金'}],
    advancements:[
      {id:'assassin', name:'刺客', desc:'致命效率的殺戮專家。',
        statBonus:{hp:0,mp:0,atk:10,def:0,spd:5}, growBonus:{hp:0,mp:0,atk:1.8,def:0,spd:1},
        skill:{name:'致命暗殺',mp:14,mult:2.55,type:'phys_crit',crit:0.55,desc:'物攻×2.55，爆擊率 55%'}},
      {id:'swashbuckler', name:'江湖遊俠', desc:'華麗多變的劍舞戰法，攻守兼備。',
        statBonus:{hp:10,mp:0,atk:6,def:0,spd:6}, growBonus:{hp:1.2,mp:0,atk:1.2,def:0,spd:1.2},
        skill:{name:'亂舞連斬',mp:12,mult:0.85,type:'phys_multi',desc:'華麗的連續劍舞'}},
      {id:'shadowthief', name:'影盜', desc:'專精於掠奪與逃脫的暗影盜賊。',
        statBonus:{hp:0,mp:0,atk:4,def:0,spd:8}, growBonus:{hp:0,mp:0,atk:0.8,def:0,spd:1.5},
        skill:{name:'巨額掠奪',mp:10,type:'steal',mult:1.2,stealMin:15,stealMax:35,desc:'物攻×1.2 + 偷 15~35 金'}}
    ]},
  {id:'cleric', name:'牧師', tag:'治療與淨化，隊伍續航核心', palette:PALETTES.holy,
    statBonus:{hp:25,mp:35,atk:2,def:3,spd:2}, growBonus:{hp:5,mp:4.5,atk:0.4,def:0.6,spd:0.4},
    passive:{id:'mercyHeal', name:'仁慈之心', desc:'治療目標HP過低時，治療量提升'},
    skills:[{name:'治癒之光',mp:14,heal:1.6,type:'heal',desc:'治療＝魔攻×1.6＋智力×0.6＋Lv×2'},{name:'群體祝福',mp:22,heal:0.95,type:'heal_aoe',desc:'全隊治療＝魔攻×0.95＋智力×0.6＋Lv×2'}],
    advancements:[
      {id:'bishop', name:'聖光主教', desc:'掌握強大群體聖光術的教會高階聖職者。',
        statBonus:{hp:0,mp:20,atk:0,def:6,spd:0}, growBonus:{hp:0,mp:2,atk:0,def:1,spd:0},
        skill:{name:'神聖庇護',mp:25,heal:1.2,type:'heal_aoe',desc:'強力的全體治療術'}},
      {id:'warpriest', name:'戰鬥牧師', desc:'手持戰錘衝鋒陷陣的攻擊型聖職者。',
        statBonus:{hp:15,mp:0,atk:8,def:0,spd:0}, growBonus:{hp:2,mp:0,atk:1.3,def:0,spd:0},
        skill:{name:'審判之錘',mp:16,mult:1.7,type:'magic',holy:true,desc:'魔攻×1.7；對邪惡×1.25'}},
      {id:'sagehealer', name:'治癒賢者', desc:'將治癒術鑽研至化境的療癒大師。',
        statBonus:{hp:10,mp:25,atk:0,def:0,spd:0}, growBonus:{hp:1.2,mp:2.5,atk:0,def:0,spd:0},
        skill:{name:'甘露之泉',mp:18,heal:2.2,type:'heal',desc:'對單一隊友的超強治療'}}
    ]},
  {id:'paladin', name:'聖騎士', tag:'攻防兼備的混合坦克', palette:PALETTES.holy,
    statBonus:{hp:42,mp:20,atk:5,def:12,spd:1}, growBonus:{hp:8,mp:2.5,atk:1,def:1.9,spd:0.5},
    passive:{id:'guardianAngel', name:'守護天使', desc:'每場戰鬥一次，隊友瀕死時保留1HP'},
    skills:[{name:'聖光審判',mp:15,mult:1.75,type:'magic',holy:true,desc:'魔攻×1.75；對邪惡×1.25'},{name:'守護誓約',mp:16,type:'guard',buffDefRatio:0.65,buffTurns:2,desc:'嘲諷；自身防禦+65%，2 回合'}],
    advancements:[
      {id:'inquisitor', name:'審判者', desc:'專精聖光攻擊，追獵邪惡的裁決者。',
        statBonus:{hp:0,mp:10,atk:10,def:0,spd:0}, growBonus:{hp:0,mp:1,atk:1.6,def:0,spd:0},
        skill:{name:'神罰審判',mp:20,mult:2.1,type:'magic',holy:true,desc:'魔攻×2.1；對邪惡×1.25'}},
      {id:'shieldbearer', name:'聖盾衛士', desc:'固若金湯的絕對防禦專家。',
        statBonus:{hp:20,mp:0,atk:0,def:14,spd:0}, growBonus:{hp:2.5,mp:0,atk:0,def:2,spd:0},
        skill:{name:'絕對防禦',mp:18,type:'guard',buffDefRatio:1.0,buffTurns:3,desc:'嘲諷；自身防禦+100%，3 回合'}},
      {id:'dawnbringer', name:'曙光騎士', desc:'兼顧輸出與治療的全能戰場核心。',
        statBonus:{hp:10,mp:10,atk:6,def:6,spd:0}, growBonus:{hp:1.2,mp:1,atk:1,def:1,spd:0},
        skill:{name:'曙光祝禱',mp:20,heal:1.0,type:'heal_aoe',desc:'戰場中的治癒之光'}}
    ]},
  {id:'monk', name:'武僧', tag:'連擊型輸出，恢復自身氣力', palette:PALETTES.beast,
    statBonus:{hp:26,mp:12,atk:7,def:4,spd:5}, growBonus:{hp:5,mp:1.2,atk:1.2,def:0.6,spd:1},
    passive:{id:'combatFlow', name:'氣勁循環', desc:'攻擊命中後回復少量MP'},
    skills:[{name:'連環腿',mp:10,mult:1.15,type:'phys_multi2',hits:2,desc:'2 連擊，每段物攻×1.15'},{name:'內功調息',mp:0,heal:0.28,mpGain:14,type:'self_heal',desc:'最大HP×28% + 14 MP'}],
    advancements:[
      {id:'fistsaint', name:'拳聖', desc:'將連擊拳法練至巔峰的武學宗師。',
        statBonus:{hp:0,mp:0,atk:12,def:0,spd:4}, growBonus:{hp:0,mp:0,atk:2,def:0,spd:0.8},
        skill:{name:'千烈連拳',mp:14,mult:0.95,type:'phys_multi',desc:'更強力的三連擊拳法'}},
      {id:'ironbody', name:'鐵布衫羅漢', desc:'金鐘罩鐵布衫護體，越打越耐打。',
        statBonus:{hp:20,mp:0,atk:0,def:10,spd:0}, growBonus:{hp:2.5,mp:0,atk:0,def:1.6,spd:0},
        skill:{name:'金鐘罩',mp:0,heal:0.45,type:'self_heal',desc:'更強的自我修復與氣力回復'}},
      {id:'qimaster', name:'氣功宗師', desc:'凝聚體內真氣化為遠距衝擊的高手。',
        statBonus:{hp:0,mp:15,atk:6,def:0,spd:4}, growBonus:{hp:0,mp:1.5,atk:1,def:0,spd:0.8},
        skill:{name:'破魔氣彈',mp:18,mult:1.8,type:'magic',desc:'凝聚氣勁的遠距衝擊波'}}
    ]},
  {id:'necromancer', name:'死靈法師', tag:'詛咒與腐蝕，持續傷害流', palette:PALETTES.undead,
    statBonus:{hp:8,mp:40,atk:4,def:1,spd:0}, growBonus:{hp:2,mp:5,atk:0.7,def:0.3,spd:0.3},
    passive:{id:'virulence', name:'致病之息', desc:'普通攻擊有機率附加中毒效果'},
    skills:[{name:'腐蝕詛咒',mp:15,mult:1.25,type:'magic_dot',poisonTurns:3,desc:'魔攻×1.25／敵 + 中毒 3 回合'},{name:'亡者低語',mp:20,mult:1.6,type:'magic_aoe',desc:'魔攻×1.6／敵'}],
    advancements:[
      {id:'plaguelord', name:'瘟疫使者', desc:'散播無盡瘟疫，讓戰場逐漸腐朽。',
        statBonus:{hp:0,mp:15,atk:6,def:0,spd:0}, growBonus:{hp:0,mp:1.8,atk:1,def:0,spd:0},
        skill:{name:'瘟疫蔓延',mp:22,mult:1.5,type:'magic_dot',desc:'強力的持續毒傷擴散全場'}},
      {id:'lichking', name:'亡靈君主', desc:'統御亡者大軍的不死君王。',
        statBonus:{hp:10,mp:20,atk:0,def:6,spd:0}, growBonus:{hp:1.2,mp:2,atk:0,def:1,spd:0},
        skill:{name:'死亡輪迴',mp:26,mult:1.8,type:'magic_aoe',desc:'召喚亡者之力打擊全體敵人'}},
      {id:'bloodwarlock', name:'血咒巫師', desc:'以鮮血為代價換取毀滅性黑暗咒術。',
        statBonus:{hp:15,mp:0,atk:8,def:0,spd:0}, growBonus:{hp:1.8,mp:0,atk:1.4,def:0,spd:0},
        skill:{name:'噬血詛咒',mp:18,mult:1.7,type:'magic',desc:'吸取生命的黑暗咒術'}}
    ]},
];

