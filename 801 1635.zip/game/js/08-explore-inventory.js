/* ============ 探索 / 事件 ============ */
function explore(){
  S.daysSurvived++;
  const rng=Math.random;
  const roll = rng();
  // 遇敵 52%／事件 33%／平靜 15%
  if(roll < 0.52){
    startBattle();
  } else if(roll < 0.85){
    const pool = S.party.length>=4 ? EVENTS.filter(e=>e.id!=='wanderer') : EVENTS;
    const ev = choice(rng, pool);
    S.event = ev;
    S.screen='event';
  } else {
    const gold = rint(Math.random,12,36);
    S.hero.gold += gold;
    S.log.unshift('平靜的旅途中，你撿到了 '+gold+' 金幣。');
    routeHome();
  }
  render();
}
function resolveEvent(choiceIdx){
  const ev = S.event;
  const result = ev.choices[choiceIdx].act(S);
  S.log.unshift('【'+ev.title+'】'+result);
  S.event=null;
  routeHome();
  render();
}

/* ============ 背包容量 / 倉庫 / 鎖定 ============ */
/** 背包裝備格硬上限（藥水可堆疊，不占此上限）；超出自動進倉庫 */
const BACKPACK_CAP = 30;
const WAREHOUSE_CAP = 80;
const WAREHOUSE_PAGE_SIZE = 20;
function ensureWarehouse(){
  if(!S) return;
  if(!Array.isArray(S.warehouse)) S.warehouse = [];
}
function backpackGearCount(){
  if(!S || !S.inventory) return 0;
  return S.inventory.filter(i=>i && i.slot!=='potion').length;
}
function backpackHasSpace(n){
  n = n==null ? 1 : n;
  return backpackGearCount() + n <= BACKPACK_CAP;
}
function toggleItemLock(item){
  if(!item || item.slot==='potion') return;
  item.locked = !item.locked;
  if(S && S.log) S.log.unshift((item.locked?'🔒 已鎖定：':'🔓 已解鎖：') + item.name);
}
/** 背包滿時：進倉庫；倉庫也滿：折價金幣（鎖定物不自動賣） */
function overflowDispose(item, silent){
  ensureWarehouse();
  if(!item || item.slot==='potion') return 'potion';
  if(S.warehouse.length < WAREHOUSE_CAP){
    S.warehouse.push(item);
    if(!silent && S.log) S.log.unshift('📦 背包已滿（'+BACKPACK_CAP+'），'+item.name+' 已自動存入倉庫。');
    return 'warehouse';
  }
  // 倉庫滿 → 折價（鎖定則無法取得）
  if(item.locked){
    if(!silent && S.log) S.log.unshift('倉庫與背包皆滿，且 '+item.name+' 已鎖定，無法收納。');
    return 'reject';
  }
  const gold = Math.max(1, Math.floor(equipPrice(item) * 0.35));
  if(S.hero) S.hero.gold = (S.hero.gold||0) + gold;
  if(!silent && S.log) S.log.unshift('📦 背包與倉庫皆滿，'+item.name+' 已折價出售 +'+gold+' 金。');
  return 'sold';
}
function depositToWarehouse(uid){
  ensureWarehouse();
  const item = S.inventory.find(i=>i.uid===uid);
  if(!item || item.slot==='potion') return false;
  if(S.warehouse.length >= WAREHOUSE_CAP){
    if(S.log) S.log.unshift('倉庫已滿（'+WAREHOUSE_CAP+'），無法存入。');
    return false;
  }
  S.inventory = S.inventory.filter(i=>i.uid!==uid);
  S.warehouse.push(item);
  if(S.log) S.log.unshift('已將 '+item.name+' 存入倉庫。');
  return true;
}
function withdrawFromWarehouse(uid){
  ensureWarehouse();
  const item = S.warehouse.find(i=>i.uid===uid);
  if(!item) return false;
  if(!backpackHasSpace(1)){
    if(S.log) S.log.unshift('背包已滿（'+BACKPACK_CAP+'），請先整理或存倉後再取出。');
    return false;
  }
  S.warehouse = S.warehouse.filter(i=>i.uid!==uid);
  S.inventory.push(item);
  if(S.log) S.log.unshift('已從倉庫取出 '+item.name+'。');
  return true;
}

/* ============ 裝備 / 背包 ============ */

function equipItem(item, memberUid){
  const m = S.party.find(p=>p.uid===(memberUid||S.invSelectedUid)) || S.hero;
  if(!m || !item || item.slot==='potion') return;
  normalizeItem(item);
  ensureMemberEquip(m);

  if(item.isUnique || item.rarity==='unique'){
    if(uniqueAlreadyHeld(item, item.uid)){
      if(S.log) S.log.unshift('【唯一】「'+(item.baseName||item.name)+'」全隊僅能裝備一件（其他可收進倉庫）。');
      render();
      return;
    }
  }

  // 僅允許已知裝備欄；未知 slot 進不去紙娃娃
  let targetSlot = item.slot;
  if(!EQUIP_SLOT_IDS.includes(targetSlot)){
    if(S.log) S.log.unshift('此物品目前無法裝備。');
    render();
    return;
  }
  const cur = m.equip[targetSlot];
  // 先從背包移除要穿的，再放回舊裝備（避免暫時超過格數）
  S.inventory = S.inventory.filter(i=>i.uid!==item.uid);
  m.equip[targetSlot] = item;
  if(cur){
    if(backpackHasSpace(1)) S.inventory.push(cur);
    else overflowDispose(cur, false);
  }
  applyComputedStats(m);
  if(S.log) S.log.unshift(m.name+' 裝備了 '+item.name+'（'+equipAffixText(item)+'）');
  S.invSelectedItemUid = null;
  S.itemModalUid = null;
  render();
}
function unequipItem(slot, memberUid){
  const m = S.party.find(p=>p.uid===(memberUid||S.invSelectedUid)) || S.hero;
  const cur = m.equip[slot];
  if(cur){
    m.equip[slot]=null;
    if(backpackHasSpace(1)) S.inventory.push(cur);
    else {
      const fate = overflowDispose(cur, false);
      if(fate==='reject'){
        // 放不回去就重新穿上
        m.equip[slot]=cur;
        if(S.log) S.log.unshift('無法卸下：背包與倉庫皆滿。');
      }
    }
  }
  applyComputedStats(m);
  render();
}
function addPotion(kind, value, name){
  const existing = S.inventory.find(i=>i.slot==='potion' && i.kind===kind && i.value===value);
  if(existing){
    existing.count = (existing.count||1) + 1;
    return existing;
  }
  const pot = {
    uid:'pot_'+Math.floor(Math.random()*1e9),
    slot:'potion', kind, value,
    name: name || (kind==='mp' ? '魔力藥水' : '治療藥水'),
    count:1
  };
  S.inventory.push(pot);
  return pot;
}
function consumePotion(item){
  if(!item || item.slot!=='potion') return false;
  const c = item.count||1;
  if(c<=1){
    S.inventory = S.inventory.filter(i=>i.uid!==item.uid);
  } else {
    item.count = c - 1;
  }
  return true;
}
function usePotionOutOfBattle(item, memberUid){
  const m = S.party.find(p=>p.uid===(memberUid||S.invSelectedUid)) || S.hero;
  if(item.slot!=='potion') return;
  if(item.kind==='mp'){ m.mp = clamp(m.mp+item.value,0,m.maxMp); }
  else { m.hp = clamp(m.hp+item.value,0,m.maxHp); }
  consumePotion(item);
  render();
}
/** 合併舊存檔中散落的同款藥水 */
function stackExistingPotions(){
  if(!S || !S.inventory) return;
  const pots = S.inventory.filter(i=>i.slot==='potion');
  const others = S.inventory.filter(i=>i.slot!=='potion');
  const map = {};
  pots.forEach(p=>{
    const key = p.kind+'_'+p.value;
    if(!map[key]){
      map[key] = Object.assign({}, p, {count: p.count||1});
    } else {
      map[key].count += (p.count||1);
    }
  });
  S.inventory = others.concat(Object.values(map));
}

