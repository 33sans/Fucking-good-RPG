/* ============ 像素精靈產生器 ============ */
/**
 * 頭像／像素系統規劃（星露谷風格框）：
 * - 人物：寫實向像素半身像（膚色／髮型／五官由 seed 決定，非名人翻拍）
 * - 怪物：自訂像素風，依 type 套用輪廓模板 + 調色
 * - 裝備：仍用簡化圖示
 */
const SKIN_TONES = [
  ['#f7e4cc','#ebc8a4','#d4a574','#b07a4a'],
  ['#f0d5b8','#e0b898','#c9956c','#9a6b45'],
  ['#e8c4a0','#d4a574','#b07a4a','#8a5a32'],
  ['#d4a574','#b07a4a','#8a5a32','#5c3a20'],
  ['#b07a4a','#8a5a32','#5c3a20','#3a2414'],
  ['#f0d0c0','#d4a090','#b07060','#8a5040'],
  ['#e8d8c0','#d0b898','#b09070','#8a6a48']
];
const HAIR_COLORS = [
  '#1a120c','#2c1810','#4a2c14','#6b3a1f','#8b4513','#a06030',
  '#c9a227','#e8d080','#d8d0c0','#c0c0c8','#5a1a1a','#2a1a3a',
  '#1a2a4a','#3a5a2a','#4a4a4a','#e8e0d0','#6b2030','#203050'
];
const EYE_COLORS = ['#2a1a10','#3a5a8a','#3a6b3a','#5a3a1a','#4a2a6a','#1a1a1a','#6b4a2a','#5a7080','#8a4a20'];
const SHIRT_COLORS = [
  ['#3a5a8a','#2a3a5a','#1a2a40'],['#8a3a3a','#5a2020','#3a1010'],['#3a6b3a','#2a4a2a','#1a3018'],
  ['#6b4a8a','#3a2a5a','#2a1a40'],['#8a6b3a','#5a4a20','#3a3010'],['#4a4a4a','#2a2a2a','#1a1a1a'],
  ['#c9a05f','#8a7030','#5a4820'],['#2f6a8f','#1a3a5a','#0a2030'],['#6a3030','#4a1818','#2a0c0c'],
  ['#2a5a5a','#1a3a3a','#0a2020']
];

function pxFill(ctx, cell, pts, color){
  ctx.fillStyle = color;
  pts.forEach(([x,y])=> ctx.fillRect(x*cell, y*cell, cell, cell));
}
function pxRect(ctx, cell, x,y,w,h, color){
  ctx.fillStyle = color;
  ctx.fillRect(x*cell, y*cell, w*cell, h*cell);
}
function pxDot(ctx, cell, x,y, color){ pxRect(ctx, cell, x,y, 1,1, color); }

/** 依名字判斷性別（female / male） */
const FEMALE_NAME_SET = new Set([
  '艾莉絲','露娜','薇拉','希兒','陳美蘭','謝金燕','葉玫瑰','春艷','吳卓源','蔡英文',
  '厚片女孩','女拳主義者','玫','林萌','栗子','芋比','gummy B','KITCAT','小卡比'
]);
const MALE_NAME_HINTS = /先生|大叔|大哥|小子|肥哥|哥$|弟$|叔|伯|漢|君|雄|強|偉|傑|俊|鋒|龍|虎|john|jimmy|rex|barry|george/i;

function extractNameFromSeed(seed){
  const s = String(seed||'');
  const idx = s.lastIndexOf('_');
  if(idx>0 && /^[a-zA-Z0-9]+$/.test(s.slice(idx+1))) return s.slice(0, idx);
  return s;
}

const MALE_NAME_SET = new Set([
  '凱因','托爾加','布蘭登','葛瑞姆','喬治','史丹利','喬','羅傑','惡魔貓','比利','西薩','熊信寬','Toyz',
  'jay chou','BR','山豬','蝦味先','蛋頭','禁藥王','陳老師','潮州土狗','godone','majin','玉麟','天峰',
  '王希銘','迪拉胖','YOUND LEE','潤少','趙翊帆','李權哲','YB','有錢人','前人','不公們','沒人能殺死的鬼','費玉清',
  '阿兄喬治','QUANZO','O.DKIZZYA','REX','macdella','eyeballray','SheATH','yappy','drew','呂士軒','ANBA',
  '林聖夫','約翰','rgry','Barry chen','熱狗','大隻','小人','陳星翰','朱軒羊','公園','凡尼師男孩','馬英九',
  '消防隊的楊先生','水哥DJDIDILONG','DIE4REALLL','NGKE配菜','KAPPERKIRA','LOKI LU','JIMMY','33','死肥胖哥',
  '修斗','駱楓','林俊傑','6YI7','謝欣達'
]);
function guessGenderFromName(name){
  const n = String(name||'').trim();
  if(!n) return 'male';
  const low = n.toLowerCase();
  if(FEMALE_NAME_SET.has(n) || FEMALE_NAME_SET.has(low)) return 'female';
  if(MALE_NAME_SET.has(n) || MALE_NAME_SET.has(low)) return 'male';
  // 明確女關鍵字（整詞／強特徵）
  if(/女|姐|妹|娘|媽|小姐|女孩|夫人|玫瑰|春艷|女拳/.test(n)) return 'female';
  if(/^(艾莉|露娜|薇拉|希兒|美蘭|金燕|林萌)/.test(n)) return 'female';
  if(/\b(alice|luna|vera|anna|amy|lisa|mary|jenny|lily|rose|gummy)\b/i.test(n)) return 'female';
  // 男關鍵字
  if(MALE_NAME_HINTS.test(n)) return 'male';
  if(/[哥弟叔伯漢君雄強偉傑俊鋒龍虎]/.test(n)) return 'male';
  if(/\b(jay|chou|jimmy|john|rex|barry|george|tony|kevin|mike)\b/i.test(n)) return 'male';
  // 未知：偏男性，少量女（避免誤判男名）
  const h = (typeof hashStr==='function' ? hashStr('gender_'+n) : n.length*17);
  return (Math.abs(h) % 100) < 22 ? 'female' : 'male';
}

/** 人物：依性別區分的星露谷風半身像 */
function drawHumanPortrait(canvas, seed, size, genderOpt){
  size = size || 16;
  const name = extractNameFromSeed(seed);
  const gender = genderOpt || guessGenderFromName(name);
  const isF = gender === 'female';
  const rng = mulberry32(hashStr('human_v4_'+gender+'_'+seed));
  const cell = Math.floor(160/size);
  canvas.width = size*cell; canvas.height = size*cell;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);

  const bgChoices = isF
    ? ['#2a1a28','#1a1a2a','#241820','#302028','#1a2430','#281a24']
    : ['#1a3040','#1a2a1a','#2a2418','#182830','#1a1a2a','#202018'];
  pxRect(ctx, cell, 0,0, size,size, bgChoices[Math.floor(rng()*bgChoices.length)]);
  for(let i=0;i<6;i++){
    if(rng()>0.5) pxDot(ctx, cell, 1+Math.floor(rng()*14), 1+Math.floor(rng()*3), 'rgba(255,255,255,0.04)');
  }

  const skin = SKIN_TONES[Math.floor(rng()*SKIN_TONES.length)];
  // 女性偏亮／暖髮色權重略高
  let hair;
  if(isF){
    const fHair = ['#1a120c','#2c1810','#4a2c14','#6b3a1f','#8b4513','#c9a227','#e8d080','#c0c0c8','#5a1a1a','#2a1a3a','#e8e0d0','#6b2030'];
    hair = fHair[Math.floor(rng()*fHair.length)];
  } else {
    hair = HAIR_COLORS[Math.floor(rng()*HAIR_COLORS.length)];
  }
  const eye = EYE_COLORS[Math.floor(rng()*EYE_COLORS.length)];
  const shirt = SHIRT_COLORS[Math.floor(rng()*SHIRT_COLORS.length)];
  // 髮型：女偏長／馬尾／蓬；男偏短／側分／刺
  let hairStyle;
  if(isF){
    const pool = [1,2,2,3,4,4,5,5]; // 中長長側分蓬馬尾
    hairStyle = pool[Math.floor(rng()*pool.length)];
  } else {
    const pool = [0,0,1,3,6,6,4];
    hairStyle = pool[Math.floor(rng()*pool.length)];
  }
  const faceW = isF ? (rng()>0.6 ? 7 : 8) : (rng()>0.4 ? 8 : 7);
  const faceX = 4;
  const hasBeard = !isF && rng()>0.55;
  const hasScar = !isF && rng()>0.82;
  const blush = isF ? rng()>0.25 : rng()>0.85;
  // 配件：女耳環／項鍊多；男眼鏡／頭帶多
  let accessory;
  if(isF){
    const pool = [0,1,1,1,2,4,4,3];
    accessory = pool[Math.floor(rng()*pool.length)];
  } else {
    const pool = [0,0,2,3,3,4];
    accessory = pool[Math.floor(rng()*pool.length)];
  }

  // 衣服／肩（男肩寬、女肩窄＋圓領）
  if(isF){
    pxRect(ctx, cell, 3,12, 10,4, shirt[0]);
    pxRect(ctx, cell, 4,12, 8,1, shirt[1]);
    pxRect(ctx, cell, 3,13, 2,2, shirt[2]||shirt[1]);
    pxRect(ctx, cell, 11,13, 2,2, shirt[2]||shirt[1]);
    pxRect(ctx, cell, 6,12, 4,1, shirt[1]);
    pxRect(ctx, cell, 7,11, 2,1, skin[1]);
  } else {
    pxRect(ctx, cell, 2,12, 12,4, shirt[0]);
    pxRect(ctx, cell, 3,12, 10,1, shirt[1]);
    pxRect(ctx, cell, 2,13, 2,2, shirt[2]||shirt[1]);
    pxRect(ctx, cell, 12,13, 2,2, shirt[2]||shirt[1]);
    pxRect(ctx, cell, 6,12, 4,1, shirt[1]);
    pxRect(ctx, cell, 7,11, 2,1, skin[1]);
  }

  // 脖子
  pxRect(ctx, cell, 7,10, 2,2, skin[1]);
  pxRect(ctx, cell, 7,11, 1,1, skin[2]);

  // 臉型
  pxRect(ctx, cell, faceX,4, faceW,7, skin[0]);
  pxRect(ctx, cell, faceX+1,3, faceW-2,1, skin[0]);
  pxRect(ctx, cell, faceX+1,10, faceW-2,1, skin[1]);
  pxRect(ctx, cell, faceX-1,5, 1,5, skin[1]);
  pxRect(ctx, cell, faceX+faceW,5, 1,5, skin[1]);
  // 陰影
  pxRect(ctx, cell, faceX+faceW-2,7, 1,3, skin[2]);
  pxRect(ctx, cell, faceX+1,9, 2,1, skin[2]);
  if(blush){
    pxDot(ctx, cell, faceX+1,8, 'rgba(220,120,120,0.45)');
    pxDot(ctx, cell, faceX+faceW-2,8, 'rgba(220,120,120,0.45)');
  }

  // 眼睛（更大更清楚）
  pxRect(ctx, cell, 5,6, 2,2, '#f8f4e8');
  pxRect(ctx, cell, 9,6, 2,2, '#f8f4e8');
  pxDot(ctx, cell, 5,6, eye);
  pxDot(ctx, cell, 6,7, eye);
  pxDot(ctx, cell, 9,6, eye);
  pxDot(ctx, cell, 10,7, eye);
  // 眼神高光
  pxDot(ctx, cell, 6,6, '#ffffff');
  pxDot(ctx, cell, 10,6, '#ffffff');
  // 眉毛
  const browY = 5;
  if(rng()>0.3){
    pxRect(ctx, cell, 5,browY, 2,1, hair);
    pxRect(ctx, cell, 9,browY, 2,1, hair);
  } else {
    pxRect(ctx, cell, 5,browY, 3,1, hair);
    pxRect(ctx, cell, 8,browY, 3,1, hair);
  }
  // 鼻子
  pxDot(ctx, cell, 7,8, skin[2]);
  pxDot(ctx, cell, 8,8, skin[3]||skin[2]);
  // 嘴
  const mouth = Math.floor(rng()*3);
  if(mouth===0) pxRect(ctx, cell, 6,9, 4,1, '#a05050');
  else if(mouth===1){ pxRect(ctx, cell, 7,9, 2,1, '#8a4040'); pxDot(ctx, cell, 6,9, '#8a4040'); }
  else pxRect(ctx, cell, 6,9, 4,1, '#6a3030');

  if(hasScar) pxRect(ctx, cell, 10,5, 1,3, 'rgba(140,60,60,0.7)');
  if(hasBeard){
    pxRect(ctx, cell, 5,10, 6,1, hair);
    pxRect(ctx, cell, 6,11, 4,1, hair);
  }

  // 頭髮樣式（更立體）
  const hd = hair;
  if(hairStyle===0){ // 短
    pxRect(ctx, cell, 4,2, 8,2, hd);
    pxRect(ctx, cell, 3,3, 2,2, hd);
    pxRect(ctx, cell, 11,3, 2,2, hd);
    pxRect(ctx, cell, 5,2, 6,1, skin[0]); // 額際
  } else if(hairStyle===1){ // 中
    pxRect(ctx, cell, 3,2, 10,3, hd);
    pxRect(ctx, cell, 2,4, 2,3, hd);
    pxRect(ctx, cell, 12,4, 2,3, hd);
  } else if(hairStyle===2){ // 長
    pxRect(ctx, cell, 3,2, 10,3, hd);
    pxRect(ctx, cell, 2,4, 2,7, hd);
    pxRect(ctx, cell, 12,4, 2,7, hd);
    pxRect(ctx, cell, 3,10, 1,2, hd);
    pxRect(ctx, cell, 12,10, 1,2, hd);
  } else if(hairStyle===3){ // 側分
    pxRect(ctx, cell, 4,2, 8,2, hd);
    pxRect(ctx, cell, 3,3, 4,3, hd);
    pxRect(ctx, cell, 11,3, 2,2, hd);
    pxRect(ctx, cell, 2,5, 2,5, hd);
  } else if(hairStyle===4){ // 蓬鬆
    pxRect(ctx, cell, 3,1, 10,3, hd);
    pxRect(ctx, cell, 2,3, 3,3, hd);
    pxRect(ctx, cell, 11,3, 3,3, hd);
    pxDot(ctx, cell, 4,4, hd); pxDot(ctx, cell, 11,4, hd);
  } else if(hairStyle===5){ // 馬尾
    pxRect(ctx, cell, 4,2, 8,2, hd);
    pxRect(ctx, cell, 3,3, 2,2, hd);
    pxRect(ctx, cell, 11,3, 2,3, hd);
    pxRect(ctx, cell, 12,6, 2,5, hd);
    pxRect(ctx, cell, 13,10, 1,2, hd);
  } else { // 短刺／光頭邊緣
    pxRect(ctx, cell, 5,3, 6,1, hd);
    pxRect(ctx, cell, 4,4, 1,2, hd);
    pxRect(ctx, cell, 11,4, 1,2, hd);
  }
  // 瀏海
  if(hairStyle!==6 && rng()>0.35){
    pxRect(ctx, cell, 5,3, 3,2, hd);
    pxRect(ctx, cell, 9,3, 2,1, hd);
  }
  // 髮絲高光
  pxDot(ctx, cell, 6,2, 'rgba(255,255,255,0.15)');

  // 配件
  if(accessory===1){ // 耳環
    pxDot(ctx, cell, 3,8, '#c9a227');
    pxDot(ctx, cell, 12,8, '#c9a227');
  } else if(accessory===2){ // 頭帶
    pxRect(ctx, cell, 4,4, 8,1, shirt[0]);
  } else if(accessory===3){ // 眼鏡
    pxRect(ctx, cell, 5,6, 2,2, 'rgba(40,40,50,0.55)');
    pxRect(ctx, cell, 9,6, 2,2, 'rgba(40,40,50,0.55)');
    pxRect(ctx, cell, 7,6, 2,1, 'rgba(40,40,50,0.4)');
  } else if(accessory===4){ // 項鍊
    pxDot(ctx, cell, 7,12, '#c9a227');
    pxDot(ctx, cell, 8,12, '#c9a227');
  }

  // 臉部高光
  pxDot(ctx, cell, 6,5, skin[0]);

  ctx.strokeStyle = 'rgba(0,0,0,0.5)';
  ctx.lineWidth = Math.max(1, cell/4);
  ctx.strokeRect(0.5, 0.5, canvas.width-1, canvas.height-1);
}

/** 怪物：更豐富的自訂像素輪廓 */
const MONSTER_TEMPLATES = {
  slime: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,6, 8,7, p[0]);
    pxRect(ctx,cell, 5,5, 6,1, p[1]);
    pxRect(ctx,cell, 3,8, 1,3, p[1]);
    pxRect(ctx,cell, 12,8, 1,3, p[1]);
    pxRect(ctx,cell, 5,13, 6,1, p[2]);
    pxRect(ctx,cell, 6,8, 1,2, '#1a1a1a');
    pxRect(ctx,cell, 9,8, 1,2, '#1a1a1a');
    pxRect(ctx,cell, 7,10, 2,1, p[2]);
    pxDot(ctx,cell, 5,7, '#ffffff');
    if(rng()>0.5) pxDot(ctx,cell, 10,9, p[2]);
  },
  skeleton: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,2, 6,3, p[2]);
    pxRect(ctx,cell, 4,5, 8,4, p[1]);
    pxRect(ctx,cell, 5,5, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 9,5, 2,2, '#1a1a1a');
    pxDot(ctx,cell, 7,7, '#1a1a1a');
    pxRect(ctx,cell, 6,8, 4,1, p[0]);
    pxRect(ctx,cell, 6,9, 1,4, p[2]);
    pxRect(ctx,cell, 9,9, 1,4, p[2]);
    pxRect(ctx,cell, 4,10, 2,1, p[1]);
    pxRect(ctx,cell, 10,10, 2,1, p[1]);
    pxRect(ctx,cell, 5,12, 2,1, p[0]);
    pxRect(ctx,cell, 9,12, 2,1, p[0]);
  },
  wolf: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 3,5, 10,6, p[0]);
    pxRect(ctx,cell, 2,4, 3,3, p[1]);
    pxRect(ctx,cell, 1,5, 2,2, p[2]);
    pxRect(ctx,cell, 4,3, 2,2, p[0]);
    pxRect(ctx,cell, 9,3, 2,2, p[0]);
    pxDot(ctx,cell, 4,3, p[2]); pxDot(ctx,cell, 10,3, p[2]);
    pxDot(ctx,cell, 3,6, '#1a1a1a');
    pxRect(ctx,cell, 5,7, 2,1, '#1a1a1a');
    pxRect(ctx,cell, 12,7, 2,3, p[1]);
    pxRect(ctx,cell, 4,11, 2,2, p[2]);
    pxRect(ctx,cell, 9,11, 2,2, p[2]);
  },
  dragon: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,4, 8,7, p[0]);
    pxRect(ctx,cell, 3,3, 2,2, p[1]);
    pxRect(ctx,cell, 11,3, 2,2, p[1]);
    pxRect(ctx,cell, 6,2, 4,2, p[2]);
    pxRect(ctx,cell, 5,6, 2,1, '#1a1a1a');
    pxRect(ctx,cell, 9,6, 2,1, '#1a1a1a');
    pxRect(ctx,cell, 7,8, 2,1, '#c94a3b');
    pxRect(ctx,cell, 2,7, 2,3, p[1]);
    pxRect(ctx,cell, 12,7, 2,3, p[1]);
    pxRect(ctx,cell, 1,5, 2,2, p[2]);
    pxRect(ctx,cell, 13,5, 2,2, p[2]);
    pxDot(ctx,cell, 6,5, p[2]);
  },
  goblin: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,3, 6,6, p[0]);
    pxRect(ctx,cell, 3,4, 2,3, p[1]);
    pxRect(ctx,cell, 11,4, 2,3, p[1]);
    pxDot(ctx,cell, 3,3, p[0]); pxDot(ctx,cell, 12,3, p[0]);
    pxRect(ctx,cell, 6,5, 1,1, '#1a1a1a');
    pxRect(ctx,cell, 9,5, 1,1, '#1a1a1a');
    pxRect(ctx,cell, 6,7, 4,1, p[2]);
    pxRect(ctx,cell, 4,9, 8,4, p[1]);
    pxRect(ctx,cell, 5,10, 2,1, p[2]);
  },
  ghost: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,3, 6,8, p[1]);
    pxRect(ctx,cell, 4,4, 8,6, p[0]);
    pxRect(ctx,cell, 5,6, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 9,6, 2,2, '#1a1a1a');
    pxDot(ctx,cell, 7,8, p[2]);
    pxRect(ctx,cell, 4,11, 2,2, p[2]);
    pxRect(ctx,cell, 7,11, 2,2, p[2]);
    pxRect(ctx,cell, 10,11, 2,2, p[2]);
    if(rng()>0.4) pxDot(ctx,cell, 3,7, p[1]);
  },
  insect: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,5, 6,5, p[0]);
    pxRect(ctx,cell, 4,6, 1,2, p[1]);
    pxRect(ctx,cell, 11,6, 1,2, p[1]);
    pxRect(ctx,cell, 6,3, 1,2, p[2]);
    pxRect(ctx,cell, 9,3, 1,2, p[2]);
    pxRect(ctx,cell, 6,6, 1,1, '#1a1a1a');
    pxRect(ctx,cell, 9,6, 1,1, '#1a1a1a');
    pxRect(ctx,cell, 3,8, 2,1, p[2]);
    pxRect(ctx,cell, 11,8, 2,1, p[2]);
    pxRect(ctx,cell, 4,10, 2,1, p[1]);
    pxRect(ctx,cell, 10,10, 2,1, p[1]);
  },
  golem: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,2, 8,4, p[0]);
    pxRect(ctx,cell, 3,6, 10,6, p[1]);
    pxRect(ctx,cell, 5,4, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 9,4, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 2,7, 2,3, p[2]);
    pxRect(ctx,cell, 12,7, 2,3, p[2]);
    pxRect(ctx,cell, 6,8, 4,1, p[2]);
    pxDot(ctx,cell, 7,3, p[2]);
  },
  bat: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 1,5, 5,3, p[1]);
    pxRect(ctx,cell, 10,5, 5,3, p[1]);
    pxRect(ctx,cell, 5,6, 6,4, p[0]);
    pxRect(ctx,cell, 6,5, 4,1, p[0]);
    pxDot(ctx,cell, 6,7, '#1a1a1a');
    pxDot(ctx,cell, 9,7, '#1a1a1a');
    pxRect(ctx,cell, 7,9, 2,1, p[2]);
    pxDot(ctx,cell, 2,4, p[2]); pxDot(ctx,cell, 13,4, p[2]);
  },
  frog: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,6, 8,6, p[0]);
    pxRect(ctx,cell, 3,7, 2,3, p[1]);
    pxRect(ctx,cell, 11,7, 2,3, p[1]);
    pxRect(ctx,cell, 5,4, 2,3, p[2]);
    pxRect(ctx,cell, 9,4, 2,3, p[2]);
    pxDot(ctx,cell, 5,5, '#1a1a1a');
    pxDot(ctx,cell, 10,5, '#1a1a1a');
    pxRect(ctx,cell, 7,9, 2,1, '#3a2a1a');
    pxRect(ctx,cell, 5,12, 2,1, p[1]);
    pxRect(ctx,cell, 9,12, 2,1, p[1]);
  },
  spider: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,6, 6,5, p[0]);
    pxRect(ctx,cell, 6,5, 4,1, p[1]);
    [[2,6],[2,9],[12,6],[12,9],[3,11],[11,11],[3,4],[11,4],[1,7],[13,7]].forEach(([x,y])=>pxRect(ctx,cell,x,y,2,1,p[2]));
    pxDot(ctx,cell, 6,7, '#1a1a1a');
    pxDot(ctx,cell, 9,7, '#1a1a1a');
    pxDot(ctx,cell, 7,8, '#1a1a1a');
  },
  tree: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 7,9, 2,5, '#5a3a20');
    pxRect(ctx,cell, 6,10, 4,1, '#4a2a18');
    pxRect(ctx,cell, 4,3, 8,7, p[0]);
    pxRect(ctx,cell, 5,2, 6,2, p[1]);
    pxRect(ctx,cell, 3,5, 1,3, p[1]);
    pxRect(ctx,cell, 12,5, 1,3, p[1]);
    pxDot(ctx,cell, 6,5, '#1a1a1a');
    pxDot(ctx,cell, 9,5, '#1a1a1a');
    if(rng()>0.4) pxDot(ctx,cell, 8,7, p[2]);
  },
  fish: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 3,6, 9,4, p[0]);
    pxRect(ctx,cell, 11,5, 3,2, p[1]);
    pxRect(ctx,cell, 11,9, 3,2, p[1]);
    pxRect(ctx,cell, 2,7, 2,2, p[2]);
    pxDot(ctx,cell, 5,7, '#1a1a1a');
    pxRect(ctx,cell, 12,7, 1,2, p[2]);
    pxDot(ctx,cell, 7,8, p[2]);
    pxRect(ctx,cell, 6,5, 2,1, p[1]);
  },
  bird: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,5, 6,5, p[0]);
    pxRect(ctx,cell, 2,6, 3,2, p[1]);
    pxRect(ctx,cell, 11,6, 3,2, p[1]);
    pxRect(ctx,cell, 10,4, 3,2, p[2]);
    pxDot(ctx,cell, 6,6, '#1a1a1a');
    pxDot(ctx,cell, 11,5, '#c94a3b');
    pxRect(ctx,cell, 6,10, 1,2, p[2]);
    pxRect(ctx,cell, 9,10, 1,2, p[2]);
  },
  knight: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,2, 6,3, p[2]);
    pxRect(ctx,cell, 6,1, 4,1, p[2]);
    pxRect(ctx,cell, 4,5, 8,5, p[0]);
    pxRect(ctx,cell, 5,6, 2,1, '#1a1a1a');
    pxRect(ctx,cell, 9,6, 2,1, '#1a1a1a');
    pxRect(ctx,cell, 3,6, 1,3, p[1]);
    pxRect(ctx,cell, 12,6, 1,3, p[1]);
    pxRect(ctx,cell, 5,10, 2,3, p[2]);
    pxRect(ctx,cell, 9,10, 2,3, p[2]);
    pxRect(ctx,cell, 7,7, 2,1, p[1]);
  },
  flower: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 7,9, 2,5, '#3a6b3a');
    pxRect(ctx,cell, 5,4, 6,5, p[0]);
    pxRect(ctx,cell, 6,3, 4,1, p[1]);
    pxRect(ctx,cell, 4,5, 1,2, p[2]);
    pxRect(ctx,cell, 11,5, 1,2, p[2]);
    pxRect(ctx,cell, 7,5, 2,2, '#c9a227');
    pxDot(ctx,cell, 5,3, p[0]); pxDot(ctx,cell, 10,3, p[0]);
  },
  tentacle: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,3, 6,4, p[0]);
    pxRect(ctx,cell, 4,7, 2,6, p[1]);
    pxRect(ctx,cell, 7,7, 2,7, p[0]);
    pxRect(ctx,cell, 10,7, 2,5, p[2]);
    pxDot(ctx,cell, 5,4, '#1a1a1a');
    pxDot(ctx,cell, 10,4, '#1a1a1a');
    pxDot(ctx,cell, 5,10, p[2]);
    pxDot(ctx,cell, 11,9, p[0]);
  },
  rat: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,6, 8,5, p[0]);
    pxRect(ctx,cell, 2,5, 3,3, p[1]);
    pxDot(ctx,cell, 3,4, p[0]); pxDot(ctx,cell, 5,4, p[0]);
    pxDot(ctx,cell, 3,6, '#1a1a1a');
    pxRect(ctx,cell, 12,8, 3,1, p[2]);
    pxRect(ctx,cell, 13,9, 1,2, p[2]);
    pxRect(ctx,cell, 5,11, 2,1, p[2]);
    pxRect(ctx,cell, 9,11, 2,1, p[2]);
  },
  crab: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 4,6, 8,5, p[0]);
    pxRect(ctx,cell, 2,5, 2,3, p[1]);
    pxRect(ctx,cell, 12,5, 2,3, p[1]);
    pxDot(ctx,cell, 2,4, p[2]); pxDot(ctx,cell, 13,4, p[2]);
    pxDot(ctx,cell, 5,7, '#1a1a1a');
    pxDot(ctx,cell, 10,7, '#1a1a1a');
    pxRect(ctx,cell, 3,11, 2,1, p[2]);
    pxRect(ctx,cell, 11,11, 2,1, p[2]);
    pxRect(ctx,cell, 6,8, 4,1, p[1]);
  },
  demon: (ctx,cell,p,rng)=>{
    pxRect(ctx,cell, 5,4, 6,7, p[0]);
    pxRect(ctx,cell, 3,2, 2,3, p[2]);
    pxRect(ctx,cell, 11,2, 2,3, p[2]);
    pxRect(ctx,cell, 5,6, 2,2, '#c94a3b');
    pxRect(ctx,cell, 9,6, 2,2, '#c94a3b');
    pxRect(ctx,cell, 6,9, 4,1, p[1]);
    pxRect(ctx,cell, 2,8, 2,3, p[1]);
    pxRect(ctx,cell, 12,8, 2,3, p[1]);
    pxDot(ctx,cell, 7,5, p[2]);
  },
  default: (ctx,cell,p,rng)=>{
    const half = 8;
    for(let y=2;y<14;y++){
      for(let x=3;x<=half;x++){
        if(rng()<0.58){
          const c = p[Math.floor(rng()*p.length)];
          pxRect(ctx,cell, x,y, 1,1, c);
          pxRect(ctx,cell, 15-x,y, 1,1, c);
        }
      }
    }
    pxRect(ctx,cell, 5,6, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 9,6, 2,2, '#1a1a1a');
    pxRect(ctx,cell, 7,9, 2,1, p[2]||p[0]);
  }
};

function inferMonsterTemplate(seed, type){
  const s = String(seed||'') + '|' + String(type||'');
  const low = s.toLowerCase();
  if(/slime|泥|史萊姆|果凍|膿|囊|瘟氣/.test(low)) return 'slime';
  if(/skel|骨|骷|亡靈|undead|骸|葬儀|殉葬/.test(low)) return 'skeleton';
  if(/wolf|狼|犬|獸|獅|熊|戰奴|月蝕|狂旗/.test(low)) return 'wolf';
  if(/dragon|龍|drake|wyrm|幼龍|泰坦|熔核|灰燼龍/.test(low)) return 'dragon';
  if(/goblin|哥布|獸人|orc|半獸|盜賊|刺客|暗契/.test(low)) return 'goblin';
  if(/ghost|幽靈|魂|影|wraith|霧|虛空|夢魘|魘|沉默|偽相/.test(low)) return 'ghost';
  if(/bug|蟲|spider|蛛|insect|蠍|蜂|蜜毒/.test(low)) return 'insect';
  if(/golem|石像|元素|construct|魔像|石衛|鉚釘|岩|銅皮|鋼鐵|星隕/.test(low)) return 'golem';
  if(/bat|蝠|鴉|鳥|鷲|羽|點火鴉|終末鴉/.test(low)) return 'bat';
  if(/frog|蛙|蟾/.test(low)) return 'frog';
  if(/spider|蛛|網|織夢/.test(low)) return 'spider';
  if(/tree|樹|木|根|林|園|花|荊|蔓|古樹|花粉|腐花|荊莠|園丁/.test(low)) return 'tree';
  if(/fish|魚|海|潮|水|觸手|墨|珍珠|女皇|深壓|寄居/.test(low)) return 'fish';
  if(/bird|鳥|鴉|鷲|羽|鐘|懺悔/.test(low)) return 'bird';
  if(/knight|騎士|衛|盾|兵|親衛|祭司|侍|執法|殿守|磁鎖|骨盾/.test(low)) return 'knight';
  if(/flower|花|花粉|腐花|荊莠|孢子/.test(low)) return 'flower';
  if(/tentacle|觸手|深淵|海怪|攫奪|碎擊/.test(low)) return 'tentacle';
  if(/rat|鼠|疫鼠/.test(low)) return 'rat';
  if(/crab|蟹|甲蟲|鐵甲/.test(low)) return 'crab';
  if(/demon|魔|血|狂|獄|罪|審判|血僕|血契|斷頭/.test(low)) return 'demon';
  if(type==='undead') return 'skeleton';
  if(type==='beast') return 'wolf';
  if(type==='shadow') return 'ghost';
  if(type==='nature') return 'tree';
  if(type==='metal') return 'golem';
  if(type==='fire' || type==='ice') return 'dragon';
  if(type==='water') return 'fish';
  if(type==='blood') return 'demon';
  return 'default';
}

function drawMonsterPortrait(canvas, seed, palette, size, type){
  size = size || 16;
  const rng = mulberry32(hashStr('mon_v3_'+seed));
  const cell = Math.floor(160/size);
  canvas.width = size*cell; canvas.height = size*cell;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const bgChoices = ['#14101a','#101818','#18120e','#0e1418','#161018','#12140c'];
  pxRect(ctx, cell, 0,0, size,size, bgChoices[Math.floor(rng()*bgChoices.length)]);
  // 邊角暗角
  pxRect(ctx, cell, 0,0, 1,size, 'rgba(0,0,0,0.25)');
  pxRect(ctx, cell, 15,0, 1,size, 'rgba(0,0,0,0.25)');

  let p = palette && palette.length ? palette.slice() : ['#6b4a2f','#9a6b3f','#c9a05f'];
  while(p.length < 3) p.push(p[p.length-1]||'#888');
  // 輕微色相偏移讓同類型也有差別
  if(rng()>0.5){
    const mix = (a,b,t)=>{
      // 簡化：偶而把主色換成次色順序
      return rng()>0.5 ? [p[1],p[0],p[2]] : p;
    };
    p = mix();
  }

  const tmpl = inferMonsterTemplate(seed, type);
  const fn = MONSTER_TEMPLATES[tmpl] || MONSTER_TEMPLATES.default;
  fn(ctx, cell, p, rng);

  // 輪廓加深一點（底部陰影）
  pxRect(ctx, cell, 4,14, 8,1, 'rgba(0,0,0,0.35)');

  const seedStr = String(seed||'');
  if(/帝王|emp_minion|emperor|眷屬|boss/.test(seedStr)){
    pxRect(ctx, cell, 1,1, 2,1, '#c9a227');
    pxRect(ctx, cell, 13,1, 2,1, '#c9a227');
    pxDot(ctx, cell, 2,2, '#e8d080');
    pxDot(ctx, cell, 13,2, '#e8d080');
  } else if(rng()>0.75){
    pxDot(ctx, cell, 1,1, p[2]);
  }
  if(rng()>0.5) pxDot(ctx, cell, 4,3, 'rgba(255,255,255,0.2)');

  ctx.strokeStyle = 'rgba(0,0,0,0.55)';
  ctx.lineWidth = Math.max(1, cell/4);
  ctx.strokeRect(0.5, 0.5, canvas.width-1, canvas.height-1);
}

/** 通用入口：kind = 'human' | 'monster' | 'legacy' */
function drawSprite(canvas, seed, palette, size, opts){
  opts = opts || {};
  if(opts.kind==='human' || opts.human){
    const g = opts.gender || guessGenderFromName(extractNameFromSeed(seed));
    drawHumanPortrait(canvas, seed, size, g);
    return;
  }
  if(opts.kind==='monster' || opts.monster || opts.type){
    drawMonsterPortrait(canvas, seed, palette, size, opts.type || opts.monsterType);
    return;
  }
  // legacy 對稱雜訊（裝備／未知）
  size = size || 16;
  const rng = mulberry32(hashStr(seed));
  const cell = Math.floor(160/size);
  canvas.width = size*cell; canvas.height = size*cell;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const half = Math.ceil(size/2);
  const grid = [];
  for(let y=0;y<size;y++){
    grid.push([]);
    for(let x=0;x<half;x++){
      const edgeBias = (x < half*0.3 || y < size*0.15 || y > size*0.85) ? 0.32 : 0.58;
      grid[y].push(rng() < edgeBias ? weightedChoice(rng,[{item:0,w:6},{item:1,w:3},{item:2,w:2},{item:3,w:1}]) : 0);
    }
  }
  for(let y=0;y<size;y++){
    for(let x=0;x<size;x++){
      const srcX = x < half ? x : size-1-x;
      const v = grid[y][srcX];
      if(v===0) continue;
      const color = (palette&&palette[v-1]) || (palette&&palette[0]) || '#888';
      ctx.fillStyle = color;
      ctx.fillRect(x*cell,y*cell,cell,cell);
    }
  }
}

function drawEquipIcon(canvas, seed, kind, rarityColor){
  const size=12, cell=Math.floor(96/size); // 較小緩衝區，仍保持像素感
  canvas.width=size*cell; canvas.height=size*cell;
  // 顯示尺寸交給 CSS；順便寫 style 避免被 width/height 屬性撐破格子
  canvas.style.width = '100%';
  canvas.style.height = 'auto';
  canvas.style.maxWidth = '40px';
  canvas.style.maxHeight = '40px';
  canvas.style.objectFit = 'contain';
  canvas.style.imageRendering = 'pixelated';
  const ctx=canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const rng = mulberry32(hashStr(seed));
  const base = ['#8b7355','#c9c2b0','#5a5470'];
  const shapes = {
    weapon: [[5,1],[6,1],[5,2],[6,2],[4,3],[5,3],[6,3],[7,3],[3,4],[4,4],[5,4],[6,4],[7,4],[8,4],[5,5],[6,5],[5,6],[6,6],[5,7],[6,7],[4,8],[5,8],[6,8],[7,8],[4,9],[7,9]],
    armor: [[3,2],[4,2],[7,2],[8,2],[3,3],[4,3],[5,3],[6,3],[7,3],[8,3],[3,4],[4,4],[5,4],[6,4],[7,4],[8,4],[4,5],[5,5],[6,5],[7,5],[4,6],[5,6],[6,6],[7,6],[4,7],[7,7]],
    accessory: [[5,2],[6,2],[4,3],[7,3],[4,4],[7,4],[5,5],[6,5],[5,6],[6,6],[4,7],[7,7],[5,8],[6,8]]
  };
  const pts = shapes[kind]||shapes.weapon;
  pts.forEach(([x,y])=>{
    ctx.fillStyle = rng()<0.25 ? rarityColor : choice(rng, base);
    ctx.fillRect(x*cell,y*cell,cell,cell);
  });
}

