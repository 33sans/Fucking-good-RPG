/* ============ 資料：裝備（稀有度 12 階 + 詞條系統） ============ */
/* 由低到高：粗製→一般→順手→常用→罕見→稀有→稀罕→史詩→傳奇→神話→千古→唯一 */
const RARITIES = [
  {id:'crude',    name:'粗製', mult:0.55, variance:0.12, affixCount:0, w:18, hex:'#6b6358'},
  {id:'normal',   name:'一般', mult:0.80, variance:0.12, affixCount:0, w:22, hex:'#9c8f7c'},
  {id:'handy',    name:'順手', mult:1.05, variance:0.14, affixCount:0, w:18, hex:'#a8a090'},
  {id:'common',   name:'常用', mult:1.30, variance:0.14, affixCount:0, w:14, hex:'#b7c49a'},
  {id:'uncommon', name:'罕見', mult:1.55, variance:0.15, affixCount:1, w:11, hex:'#5b93a8'},
  {id:'rare',     name:'稀有', mult:1.90, variance:0.15, affixCount:1, w:7.5,hex:'#4a9fd8'},
  {id:'scarce',   name:'稀罕', mult:2.30, variance:0.16, affixCount:1, w:4.5,hex:'#6b8cff'},
  {id:'epic',     name:'史詩', mult:2.80, variance:0.16, affixCount:2, w:2.8,hex:'#a565d6'},
  {id:'legend',   name:'傳奇', mult:3.40, variance:0.18, affixCount:2, w:1.4,hex:'#ff6a35'},
  {id:'mythic',   name:'神話', mult:4.20, variance:0.18, affixCount:2, w:0.7,hex:'#ff4fa3'},
  {id:'ancient',  name:'千古', mult:5.20, variance:0.20, affixCount:3, w:0.28,hex:'#ffd24a'},
  {id:'unique',   name:'唯一', mult:6.50, variance:0.10, affixCount:4, w:0.12,hex:'#ff3b3b'}
];
/* 舊存檔稀有度對照 */
const RARITY_LEGACY_MAP = {common:'normal', rare:'rare', epic:'epic', legend:'legend', mythic:'mythic'};

const MATERIALS = {
  cloth:  {name:'布', roles:['mage','healer']},
  leather:{name:'皮', roles:['archer','rogue','warrior']},
  iron:   {name:'鐵', roles:['tank','warrior']},
  wood:   {name:'木', roles:['archer','mage']},
  silver: {name:'銀', roles:['healer','mage']},
  bone:   {name:'骨', roles:['mage','rogue']}
};
const ROLE_AFFIX_POOL = {
  tank:    [{stat:'con',v:3,label:'堅韌'},{stat:'def',v:5,label:'守護'},{stat:'hp',v:25,label:'厚重'},{stat:'con',v:4,label:'鐵壁'}],
  warrior: [{stat:'str',v:3,label:'勇猛'},{stat:'atk',v:5,label:'鋒利'},{stat:'str',v:4,label:'破軍'},{stat:'hp',v:15,label:'血氣'}],
  archer:  [{stat:'agi',v:3,label:'鷹眼'},{stat:'spd',v:4,label:'疾射'},{stat:'atk',v:4,label:'穿楊'},{stat:'agi',v:4,label:'游擊'}],
  rogue:   [{stat:'agi',v:4,label:'影襲'},{stat:'spd',v:5,label:'迅捷'},{stat:'atk',v:3,label:'毒刃'},{stat:'agi',v:3,label:'潛行'}],
  healer:  [{stat:'int',v:3,label:'慈悲'},{stat:'mp',v:18,label:'聖癒'},{stat:'int',v:4,label:'禱言'},{stat:'con',v:2,label:'堅心'}],
  mage:    [{stat:'int',v:4,label:'奧術'},{stat:'matk',v:6,label:'秘法'},{stat:'mp',v:20,label:'魔力'},{stat:'int',v:3,label:'元素'}]
};
const GENERIC_AFFIX_POOL = [
  {stat:'str',v:2,label:'力量'},{stat:'con',v:2,label:'體質'},{stat:'agi',v:2,label:'敏捷'},{stat:'int',v:2,label:'智力'},
  {stat:'atk',v:3,label:'攻擊'},{stat:'matk',v:3,label:'魔攻'},{stat:'def',v:3,label:'防禦'},{stat:'spd',v:2,label:'速度'},
  {stat:'hp',v:12,label:'生命'},{stat:'mp',v:10,label:'魔力'}
];


/** 裝備欄位（紙娃娃）— 飾品僅 1 格；其餘欄位保留供成長與劇情道具擴充 */
const EQUIP_SLOT_DEFS = [
  {id:'head',     label:'頭部',   area:'head',    icon:'head'},
  {id:'weapon',   label:'主手',   area:'weapon',  icon:'weapon'},
  {id:'armor',    label:'胸甲',   area:'chest',   icon:'armor'},
  {id:'offhand',  label:'副手',   area:'offhand', icon:'weapon'},
  {id:'hands',    label:'手套',   area:'hands',   icon:'armor'},
  {id:'cape',     label:'披風',   area:'cape',    icon:'armor'},
  {id:'accessory',label:'飾品',   area:'acc',     icon:'accessory'},
  {id:'feet',     label:'鞋子',   area:'feet',    icon:'armor'}
];
const EQUIP_SLOT_IDS = EQUIP_SLOT_DEFS.map(s=>s.id);
function emptyEquip(){
  const e = {};
  EQUIP_SLOT_IDS.forEach(id=> e[id]=null);
  return e;
}
function ensureMemberEquip(m){
  if(!m) return;
  if(!m.equip) m.equip = emptyEquip();
  EQUIP_SLOT_IDS.forEach(id=>{ if(m.equip[id]===undefined) m.equip[id]=null; });
  // 舊 accessory2 → 若飾品空則挪入，否則退回背包／倉庫
  if(m.equip.accessory2){
    const extra = m.equip.accessory2;
    if(!m.equip.accessory) m.equip.accessory = extra;
    else if(typeof S!=='undefined' && S){
      if(typeof backpackHasSpace==='function' && backpackHasSpace(1)) S.inventory.push(extra);
      else if(typeof overflowDispose==='function') overflowDispose(extra, true);
      else if(S.inventory) S.inventory.push(extra);
    }
    m.equip.accessory2 = null;
    delete m.equip.accessory2;
  }
}

const EQUIP_BASES = {
  weapon: [
    {n:'鐵劍',stat:'atk',v:5,mat:'iron',role:'warrior'},{n:'精鋼劍',stat:'atk',v:6,mat:'iron',role:'warrior'},
    {n:'長劍',stat:'atk',v:6,mat:'iron',role:'warrior'},{n:'闊劍',stat:'atk',v:7,mat:'iron',role:'warrior'},
    {n:'雙手巨劍',stat:'atk',v:9,mat:'iron',role:'warrior'},{n:'戰斧',stat:'atk',v:7,mat:'iron',role:'warrior'},
    {n:'雙刃斧',stat:'atk',v:8,mat:'iron',role:'warrior'},{n:'戰錘',stat:'atk',v:7,mat:'iron',role:'tank'},
    {n:'巨鎚',stat:'atk',v:9,mat:'iron',role:'tank'},{n:'長矛',stat:'atk',v:6,mat:'iron',role:'tank'},
    {n:'騎士槍',stat:'atk',v:7,mat:'iron',role:'tank'},{n:'獵弓',stat:'atk',v:5,mat:'wood',role:'archer'},
    {n:'長弓',stat:'atk',v:6,mat:'wood',role:'archer'},{n:'複合弓',stat:'atk',v:6,mat:'wood',role:'archer'},
    {n:'反曲弓',stat:'atk',v:7,mat:'wood',role:'archer'},{n:'獵殺弩',stat:'atk',v:6,mat:'wood',role:'archer'},
    {n:'匕首',stat:'atk',v:4,mat:'iron',role:'rogue'},{n:'雙持短刃',stat:'atk',v:5,mat:'iron',role:'rogue'},
    {n:'暗影匕首',stat:'atk',v:5,mat:'bone',role:'rogue'},{n:'淬毒之刃',stat:'atk',v:6,mat:'iron',role:'rogue'},
    {n:'法杖',stat:'matk',v:5,mat:'wood',role:'mage'},{n:'水晶法杖',stat:'matk',v:6,mat:'silver',role:'mage'},
    {n:'秘術權杖',stat:'matk',v:6,mat:'silver',role:'mage'},{n:'元素法杖',stat:'matk',v:7,mat:'wood',role:'mage'},
    {n:'骨杖',stat:'matk',v:5,mat:'bone',role:'mage'},{n:'亡靈權杖',stat:'matk',v:6,mat:'bone',role:'mage'},
    {n:'死靈法杖',stat:'matk',v:7,mat:'bone',role:'mage'},{n:'聖典',stat:'matk',v:5,mat:'cloth',role:'healer'},
    {n:'聖典之書',stat:'matk',v:6,mat:'cloth',role:'healer'},{n:'聖光錘',stat:'atk',v:6,mat:'silver',role:'healer'},
    {n:'晨星錘',stat:'atk',v:7,mat:'silver',role:'tank'},{n:'虎爪拳套',stat:'atk',v:5,mat:'leather',role:'warrior'},
    {n:'鋼爪',stat:'atk',v:6,mat:'iron',role:'warrior'},{n:'符文之刃',stat:'atk',v:7,mat:'silver',role:'mage'},
    {n:'遠古之刃',stat:'atk',v:8,mat:'iron',role:'warrior'},{n:'燃燒之劍',stat:'atk',v:8,mat:'iron',role:'mage'},
    {n:'冰霜巨劍',stat:'atk',v:8,mat:'iron',role:'mage'},{n:'鐮刀',stat:'atk',v:6,mat:'iron',role:'rogue'},
    {n:'巨型鐮刀',stat:'atk',v:8,mat:'iron',role:'warrior'},{n:'鞭刃',stat:'atk',v:5,mat:'leather',role:'rogue'},
    {n:'荊棘鞭',stat:'atk',v:6,mat:'wood',role:'rogue'},{n:'三叉戟',stat:'atk',v:6,mat:'iron',role:'tank'}
  ],
  armor: [
    {n:'皮甲',stat:'def',v:5,mat:'leather',role:'archer'},{n:'硬化皮甲',stat:'def',v:6,mat:'leather',role:'warrior'},
    {n:'獸皮鎧',stat:'def',v:6,mat:'leather',role:'warrior'},{n:'鱗甲',stat:'def',v:7,mat:'iron',role:'tank'},
    {n:'鎖甲',stat:'def',v:7,mat:'iron',role:'tank'},{n:'精鋼鎖甲',stat:'def',v:8,mat:'iron',role:'tank'},
    {n:'板甲',stat:'def',v:11,mat:'iron',role:'tank'},{n:'重裝鎧',stat:'def',v:13,mat:'iron',role:'tank'},
    {n:'騎士鎧',stat:'def',v:12,mat:'iron',role:'tank'},{n:'聖騎鎧',stat:'def',v:13,mat:'silver',role:'tank'},
    {n:'布袍',stat:'def',v:2,mat:'cloth',role:'mage'},{n:'學徒袍',stat:'def',v:2,mat:'cloth',role:'mage'},
    {n:'秘術長袍',stat:'def',v:3,mat:'cloth',role:'mage'},{n:'賢者長袍',stat:'def',v:3,mat:'cloth',role:'mage'},
    {n:'斗篷',stat:'def',v:2,mat:'cloth',role:'rogue'},{n:'暗影披風',stat:'def',v:3,mat:'cloth',role:'rogue'},
    {n:'夜行斗篷',stat:'def',v:3,mat:'leather',role:'rogue'},{n:'聖衣',stat:'def',v:4,mat:'cloth',role:'healer'},
    {n:'聖光戰袍',stat:'def',v:6,mat:'silver',role:'healer'},{n:'聖徒戰甲',stat:'def',v:8,mat:'silver',role:'healer'},
    {n:'僧侶束帶服',stat:'def',v:4,mat:'cloth',role:'healer'},{n:'武僧道袍',stat:'def',v:4,mat:'cloth',role:'warrior'},
    {n:'亡靈裹屍布',stat:'def',v:3,mat:'cloth',role:'mage'},{n:'骸骨鎧甲',stat:'def',v:7,mat:'bone',role:'tank'},
    {n:'荊棘藤甲',stat:'def',v:5,mat:'wood',role:'archer'},{n:'龍鱗甲',stat:'def',v:11,mat:'iron',role:'tank'},
    {n:'戰場皮衣',stat:'def',v:5,mat:'leather',role:'warrior'},{n:'遊俠輕甲',stat:'def',v:3,mat:'leather',role:'archer'}
  ],
  accessory: [
    {n:'力量護符',stat:'str',v:3,mat:'iron',role:'warrior'},{n:'狂戰士臂環',stat:'str',v:4,mat:'iron',role:'warrior'},
    {n:'鷹眼徽章',stat:'agi',v:3,mat:'wood',role:'archer'},{n:'狙擊眼鏡',stat:'agi',v:4,mat:'wood',role:'archer'},
    {n:'勇者徽章',stat:'str',v:4,mat:'iron',role:'warrior'},{n:'盜賊指環',stat:'agi',v:3,mat:'bone',role:'rogue'},
    {n:'魔力手鐲',stat:'int',v:4,mat:'silver',role:'mage'},{n:'烈焰寶石',stat:'matk',v:4,mat:'silver',role:'mage'},
    {n:'守護戒指',stat:'con',v:3,mat:'iron',role:'tank'},{n:'龜甲護盾墜',stat:'def',v:4,mat:'iron',role:'tank'},
    {n:'聖徒之戒',stat:'int',v:3,mat:'silver',role:'healer'},{n:'迅捷靴',stat:'spd',v:3,mat:'leather',role:'archer'},
    {n:'疾風之羽',stat:'spd',v:4,mat:'cloth',role:'rogue'},{n:'獵人綁腿',stat:'agi',v:3,mat:'leather',role:'archer'},
    {n:'月光耳環',stat:'int',v:3,mat:'silver',role:'mage'},{n:'生命項鍊',stat:'hp',v:20,mat:'silver',role:'tank'},
    {n:'活力寶石',stat:'hp',v:28,mat:'silver',role:'tank'},{n:'不朽之心',stat:'con',v:5,mat:'bone',role:'tank'},
    {n:'法力珠',stat:'mp',v:15,mat:'silver',role:'mage'},{n:'秘術結晶',stat:'mp',v:22,mat:'silver',role:'mage'},
    {n:'賢者水晶',stat:'int',v:5,mat:'silver',role:'mage'},{n:'毒蛇之牙',stat:'agi',v:3,mat:'bone',role:'rogue'},
    {n:'巨人腰帶',stat:'con',v:4,mat:'iron',role:'tank'},{n:'暗影戒指',stat:'agi',v:3,mat:'bone',role:'rogue'}
  ],
  offhand: [
    {n:'木盾',stat:'def',v:4,mat:'wood',role:'tank'},{n:'圓盾',stat:'def',v:5,mat:'iron',role:'tank'},
    {n:'鳶盾',stat:'def',v:6,mat:'iron',role:'tank'},{n:'塔盾',stat:'def',v:8,mat:'iron',role:'tank'},
    {n:'符文盾',stat:'def',v:5,mat:'silver',role:'mage'},{n:'典籍',stat:'matk',v:3,mat:'cloth',role:'mage'},
    {n:'神聖盾',stat:'def',v:6,mat:'silver',role:'healer'},{n:'刺客副刃',stat:'atk',v:3,mat:'iron',role:'rogue'}
  ],
  head: [
    {n:'布帽',stat:'def',v:2,mat:'cloth',role:'mage'},{n:'皮帽',stat:'def',v:3,mat:'leather',role:'archer'},
    {n:'鐵盔',stat:'def',v:5,mat:'iron',role:'tank'},{n:'騎士盔',stat:'def',v:6,mat:'iron',role:'tank'},
    {n:'法師兜帽',stat:'matk',v:3,mat:'cloth',role:'mage'},{n:'獵人帽',stat:'agi',v:3,mat:'leather',role:'archer'},
    {n:'盜賊頭巾',stat:'spd',v:3,mat:'cloth',role:'rogue'},{n:'聖冠',stat:'int',v:3,mat:'silver',role:'healer'}
  ],
  cape: [
    {n:'旅行披風',stat:'def',v:2,mat:'cloth',role:'archer'},{n:'暗影披肩',stat:'spd',v:3,mat:'cloth',role:'rogue'},
    {n:'法師披風',stat:'matk',v:3,mat:'cloth',role:'mage'},{n:'勇者之氅',stat:'str',v:3,mat:'leather',role:'warrior'},
    {n:'守護披風',stat:'def',v:4,mat:'iron',role:'tank'},{n:'聖光斗篷',stat:'int',v:3,mat:'silver',role:'healer'}
  ],
  hands: [
    {n:'布手套',stat:'def',v:1,mat:'cloth',role:'mage'},{n:'皮手套',stat:'def',v:2,mat:'leather',role:'archer'},
    {n:'鐵手套',stat:'def',v:3,mat:'iron',role:'tank'},{n:'戰拳套',stat:'atk',v:3,mat:'iron',role:'warrior'},
    {n:'射手護腕',stat:'agi',v:3,mat:'leather',role:'archer'},{n:'法師手套',stat:'matk',v:2,mat:'cloth',role:'mage'},
    {n:'盜賊手套',stat:'spd',v:3,mat:'leather',role:'rogue'}
  ],
  feet: [
    {n:'布鞋',stat:'spd',v:2,mat:'cloth',role:'mage'},{n:'皮靴',stat:'spd',v:3,mat:'leather',role:'archer'},
    {n:'鐵靴',stat:'def',v:3,mat:'iron',role:'tank'},{n:'疾風靴',stat:'spd',v:4,mat:'leather',role:'rogue'},
    {n:'重裝戰靴',stat:'def',v:4,mat:'iron',role:'tank'},{n:'旅人靴',stat:'spd',v:3,mat:'leather',role:'warrior'},
    {n:'賢者鞋',stat:'int',v:2,mat:'cloth',role:'mage'}
  ]
};

/* 50 件唯一裝備（各 4 條頂階詞綴） */
const UNIQUE_ITEMS = [
  {n:'灰燼君王劍',slot:'weapon',stat:'atk',v:14,mat:'iron',role:'warrior',aff:[
    {stat:'str',v:8,label:'君王之力'},{stat:'atk',v:12,label:'灰燼之刃'},{stat:'hp',v:40,label:'不屈'},{stat:'con',v:5,label:'王座'}]},
  {n:'虛空法杖·終焉',slot:'weapon',stat:'matk',v:14,mat:'silver',role:'mage',aff:[
    {stat:'int',v:10,label:'虛空智慧'},{stat:'matk',v:14,label:'終焉之火'},{stat:'mp',v:45,label:'魔力淵'},{stat:'spd',v:4,label:'瞬詠'}]},
  {n:'聖光救贖之書',slot:'weapon',stat:'matk',v:12,mat:'cloth',role:'healer',aff:[
    {stat:'int',v:8,label:'神恩'},{stat:'mp',v:40,label:'聖泉'},{stat:'con',v:4,label:'堅信者'},{stat:'hp',v:30,label:'庇護'}]},
  {n:'影殺·無聲',slot:'weapon',stat:'atk',v:12,mat:'bone',role:'rogue',aff:[
    {stat:'agi',v:10,label:'無影'},{stat:'spd',v:8,label:'無聲'},{stat:'atk',v:10,label:'必殺'},{stat:'str',v:4,label:'暗殺'}]},
  {n:'蒼穹長弓',slot:'weapon',stat:'atk',v:13,mat:'wood',role:'archer',aff:[
    {stat:'agi',v:9,label:'蒼穹之眼'},{stat:'atk',v:11,label:'貫日'},{stat:'spd',v:6,label:'風矢'},{stat:'str',v:3,label:'拉滿'}]},
  {n:'不朽巨盾斧',slot:'weapon',stat:'atk',v:11,mat:'iron',role:'tank',aff:[
    {stat:'con',v:10,label:'不朽'},{stat:'def',v:14,label:'鐵壁'},{stat:'hp',v:55,label:'厚甲'},{stat:'str',v:5,label:'反震'}]},
  {n:'龍骨戰錘',slot:'weapon',stat:'atk',v:13,mat:'bone',role:'tank',aff:[
    {stat:'str',v:7,label:'龍力'},{stat:'con',v:7,label:'龍骨'},{stat:'atk',v:10,label:'碎顱'},{stat:'def',v:8,label:'龍鱗'}]},
  {n:'霜噬雙刃',slot:'weapon',stat:'atk',v:12,mat:'iron',role:'rogue',aff:[
    {stat:'agi',v:8,label:'霜步'},{stat:'atk',v:11,label:'噬魂'},{stat:'spd',v:5,label:'冰裂'},{stat:'int',v:3,label:'寒咒'}]},
  {n:'烈陽權杖',slot:'weapon',stat:'matk',v:13,mat:'silver',role:'mage',aff:[
    {stat:'int',v:9,label:'烈陽'},{stat:'matk',v:13,label:'灼燒'},{stat:'mp',v:35,label:'日輪'},{stat:'str',v:3,label:'陽剛'}]},
  {n:'荆棘王鞭',slot:'weapon',stat:'atk',v:11,mat:'wood',role:'rogue',aff:[
    {stat:'agi',v:7,label:'荆棘'},{stat:'atk',v:9,label:'撕裂'},{stat:'spd',v:7,label:'抽打'},{stat:'con',v:3,label:'韌皮'}]},
  {n:'灰燼聖鎧',slot:'armor',stat:'def',v:16,mat:'iron',role:'tank',aff:[
    {stat:'con',v:10,label:'聖骸'},{stat:'def',v:16,label:'灰燼甲'},{stat:'hp',v:60,label:'不滅'},{stat:'str',v:4,label:'重壓'}]},
  {n:'虛空法袍',slot:'armor',stat:'def',v:6,mat:'cloth',role:'mage',aff:[
    {stat:'int',v:10,label:'虛空'},{stat:'matk',v:10,label:'法環'},{stat:'mp',v:50,label:'魔力池'},{stat:'spd',v:3,label:'飄逸'}]},
  {n:'遊俠風衣',slot:'armor',stat:'def',v:8,mat:'leather',role:'archer',aff:[
    {stat:'agi',v:9,label:'遊俠'},{stat:'spd',v:7,label:'疾風'},{stat:'atk',v:6,label:'獵裝'},{stat:'con',v:3,label:'野外'}]},
  {n:'暗影潛行衣',slot:'armor',stat:'def',v:7,mat:'leather',role:'rogue',aff:[
    {stat:'agi',v:10,label:'潛影'},{stat:'spd',v:8,label:'無蹤'},{stat:'atk',v:5,label:'背刺裝'},{stat:'int',v:2,label:'夜視'}]},
  {n:'聖愈祭袍',slot:'armor',stat:'def',v:7,mat:'cloth',role:'healer',aff:[
    {stat:'int',v:8,label:'聖愈'},{stat:'mp',v:40,label:'禱衣'},{stat:'con',v:5,label:'信念'},{stat:'hp',v:35,label:'恩典'}]},
  {n:'狂戰士皮甲',slot:'armor',stat:'def',v:9,mat:'leather',role:'warrior',aff:[
    {stat:'str',v:9,label:'狂怒'},{stat:'atk',v:8,label:'血戰'},{stat:'hp',v:35,label:'好戰'},{stat:'spd',v:4,label:'衝鋒'}]},
  {n:'龍騎士鎧',slot:'armor',stat:'def',v:15,mat:'iron',role:'tank',aff:[
    {stat:'con',v:9,label:'龍騎'},{stat:'def',v:14,label:'龍鎧'},{stat:'str',v:6,label:'騎槍'},{stat:'hp',v:45,label:'坐騎'}]},
  {n:'元素編織袍',slot:'armor',stat:'def',v:5,mat:'cloth',role:'mage',aff:[
    {stat:'int',v:9,label:'元素'},{stat:'matk',v:9,label:'編織'},{stat:'mp',v:38,label:'法線'},{stat:'agi',v:3,label:'流轉'}]},
  {n:'亡者裹屍甲',slot:'armor',stat:'def',v:10,mat:'bone',role:'mage',aff:[
    {stat:'int',v:7,label:'亡語'},{stat:'matk',v:8,label:'腐蝕'},{stat:'con',v:6,label:'枯骨'},{stat:'hp',v:30,label:'死寂'}]},
  {n:'黎明守衛甲',slot:'armor',stat:'def',v:14,mat:'silver',role:'healer',aff:[
    {stat:'con',v:8,label:'黎明'},{stat:'def',v:12,label:'守衛'},{stat:'int',v:5,label:'晨光'},{stat:'hp',v:40,label:'希望'}]},
  {n:'世界樹之心',slot:'accessory',stat:'hp',v:50,mat:'wood',role:'tank',aff:[
    {stat:'con',v:10,label:'樹心'},{stat:'hp',v:55,label:'生機'},{stat:'mp',v:20,label:'樹液'},{stat:'int',v:4,label:'自然'}]},
  {n:'時間沙漏墜',slot:'accessory',stat:'spd',v:8,mat:'silver',role:'archer',aff:[
    {stat:'agi',v:8,label:'時之眼'},{stat:'spd',v:10,label:'加速'},{stat:'int',v:5,label:'預知'},{stat:'mp',v:15,label:'時能'}]},
  {n:'深淵之眼',slot:'accessory',stat:'matk',v:10,mat:'bone',role:'mage',aff:[
    {stat:'int',v:10,label:'深淵'},{stat:'matk',v:12,label:'凝視'},{stat:'mp',v:35,label:'深海'},{stat:'con',v:3,label:'耐蝕'}]},
  {n:'屠龍者徽章',slot:'accessory',stat:'atk',v:10,mat:'iron',role:'warrior',aff:[
    {stat:'str',v:9,label:'屠龍'},{stat:'atk',v:11,label:'龍殺'},{stat:'hp',v:30,label:'勇者'},{stat:'con',v:4,label:'抗龍'}]},
  {n:'盜王之戒',slot:'accessory',stat:'agi',v:8,mat:'bone',role:'rogue',aff:[
    {stat:'agi',v:10,label:'盜王'},{stat:'spd',v:8,label:'神偷'},{stat:'atk',v:6,label:'竊刃'},{stat:'int',v:3,label:'慧眼'}]},
  {n:'大賢者眼鏡',slot:'accessory',stat:'int',v:8,mat:'silver',role:'mage',aff:[
    {stat:'int',v:11,label:'大賢'},{stat:'matk',v:9,label:'洞察'},{stat:'mp',v:40,label:'智泉'},{stat:'spd',v:2,label:'速讀'}]},
  {n:'守護天使羽',slot:'accessory',stat:'def',v:8,mat:'silver',role:'healer',aff:[
    {stat:'int',v:7,label:'天使'},{stat:'con',v:6,label:'守護'},{stat:'hp',v:40,label:'羽庇'},{stat:'mp',v:25,label:'聖音'}]},
  {n:'泰坦之握',slot:'accessory',stat:'str',v:8,mat:'iron',role:'warrior',aff:[
    {stat:'str',v:11,label:'泰坦'},{stat:'atk',v:10,label:'巨力'},{stat:'con',v:5,label:'沉重'},{stat:'hp',v:25,label:'巨體'}]},
  {n:'幻影斗篷扣',slot:'accessory',stat:'spd',v:7,mat:'cloth',role:'rogue',aff:[
    {stat:'agi',v:9,label:'幻影'},{stat:'spd',v:9,label:'殘像'},{stat:'atk',v:5,label:'虛擊'},{stat:'mp',v:12,label:'幻術'}]},
  {n:'永恆沙漏戒',slot:'accessory',stat:'int',v:7,mat:'silver',role:'mage',aff:[
    {stat:'int',v:8,label:'永恆'},{stat:'mp',v:45,label:'時魔'},{stat:'matk',v:8,label:'時止'},{stat:'spd',v:5,label:'時間差'}]},
  {n:'血怒戰斧·滅',slot:'weapon',stat:'atk',v:15,mat:'iron',role:'warrior',aff:[
    {stat:'str',v:10,label:'血怒'},{stat:'atk',v:14,label:'滅殺'},{stat:'hp',v:20,label:'嗜血'},{stat:'spd',v:3,label:'狂揮'}]},
  {n:'星隕法球',slot:'weapon',stat:'matk',v:15,mat:'silver',role:'mage',aff:[
    {stat:'int',v:11,label:'星隕'},{stat:'matk',v:15,label:'隕星'},{stat:'mp',v:40,label:'星河'},{stat:'agi',v:3,label:'軌道'}]},
  {n:'月神銀弓',slot:'weapon',stat:'atk',v:14,mat:'silver',role:'archer',aff:[
    {stat:'agi',v:10,label:'月神'},{stat:'atk',v:12,label:'銀矢'},{stat:'spd',v:6,label:'月光'},{stat:'int',v:4,label:'月識'}]},
  {n:'審判之錘·神',slot:'weapon',stat:'atk',v:13,mat:'silver',role:'healer',aff:[
    {stat:'int',v:8,label:'審判'},{stat:'atk',v:10,label:'神錘'},{stat:'mp',v:30,label:'神力'},{stat:'con',v:5,label:'正義'}]},
  {n:'骨龍脊刃',slot:'weapon',stat:'atk',v:14,mat:'bone',role:'warrior',aff:[
    {stat:'str',v:8,label:'骨龍'},{stat:'atk',v:13,label:'脊斬'},{stat:'con',v:6,label:'龍脊'},{stat:'hp',v:28,label:'骨血'}]},
  {n:'風暴鎖子甲',slot:'armor',stat:'def',v:12,mat:'iron',role:'tank',aff:[
    {stat:'con',v:8,label:'風暴'},{stat:'def',v:13,label:'雷甲'},{stat:'spd',v:5,label:'疾電'},{stat:'str',v:4,label:'轟鳴'}]},
  {n:'蛛網輕甲',slot:'armor',stat:'def',v:6,mat:'cloth',role:'rogue',aff:[
    {stat:'agi',v:9,label:'蛛絲'},{stat:'spd',v:8,label:'黏步'},{stat:'atk',v:5,label:'毒網'},{stat:'int',v:3,label:'蛛智'}]},
  {n:'聖堂侍從甲',slot:'armor',stat:'def',v:11,mat:'silver',role:'healer',aff:[
    {stat:'con',v:7,label:'聖堂'},{stat:'def',v:10,label:'侍從'},{stat:'int',v:6,label:'侍奉'},{stat:'hp',v:35,label:'信仰'}]},
  {n:'熔岩板甲',slot:'armor',stat:'def',v:14,mat:'iron',role:'tank',aff:[
    {stat:'con',v:9,label:'熔岩'},{stat:'def',v:15,label:'火甲'},{stat:'str',v:5,label:'熱能'},{stat:'hp',v:40,label:'岩漿'}]},
  {n:'寒冰巫袍',slot:'armor',stat:'def',v:5,mat:'cloth',role:'mage',aff:[
    {stat:'int',v:10,label:'寒冰'},{stat:'matk',v:11,label:'冰法'},{stat:'mp',v:42,label:'凍能'},{stat:'spd',v:2,label:'霜步'}]},
  {n:'獵神徽章',slot:'accessory',stat:'agi',v:9,mat:'wood',role:'archer',aff:[
    {stat:'agi',v:11,label:'獵神'},{stat:'atk',v:9,label:'神射'},{stat:'spd',v:7,label:'追蹤'},{stat:'str',v:3,label:'拉弓'}]},
  {n:'血契戒指',slot:'accessory',stat:'str',v:7,mat:'bone',role:'warrior',aff:[
    {stat:'str',v:9,label:'血契'},{stat:'atk',v:9,label:'血刃'},{stat:'hp',v:35,label:'血契生'},{stat:'con',v:4,label:'血韌'}]},
  {n:'智慧蘋果墜',slot:'accessory',stat:'int',v:9,mat:'wood',role:'mage',aff:[
    {stat:'int',v:12,label:'原罪智'},{stat:'matk',v:8,label:'禁知'},{stat:'mp',v:35,label:'果實'},{stat:'hp',v:15,label:'生命果'}]},
  {n:'鐵壁臂環',slot:'accessory',stat:'def',v:10,mat:'iron',role:'tank',aff:[
    {stat:'con',v:10,label:'鐵壁'},{stat:'def',v:12,label:'臂守'},{stat:'hp',v:45,label:'壁壘'},{stat:'str',v:4,label:'格擋'}]},
  {n:'寧靜祈禱珠',slot:'accessory',stat:'mp',v:30,mat:'silver',role:'healer',aff:[
    {stat:'int',v:8,label:'寧靜'},{stat:'mp',v:50,label:'祈禱'},{stat:'con',v:5,label:'平心'},{stat:'hp',v:25,label:'安魂'}]},
  {n:'幽靈靴',slot:'accessory',stat:'spd',v:9,mat:'cloth',role:'rogue',aff:[
    {stat:'agi',v:8,label:'幽靈'},{stat:'spd',v:11,label:'穿牆'},{stat:'atk',v:4,label:'鬼襲'},{stat:'int',v:4,label:'靈視'}]},
  {n:'泰坦之心核',slot:'accessory',stat:'con',v:9,mat:'iron',role:'tank',aff:[
    {stat:'con',v:12,label:'泰坦心'},{stat:'hp',v:60,label:'核心'},{stat:'def',v:8,label:'心甲'},{stat:'str',v:5,label:'脈動'}]},
  {n:'混沌骰子',slot:'accessory',stat:'luck',v:5,mat:'bone',role:'rogue',aff:[
    {stat:'agi',v:7,label:'混沌'},{stat:'spd',v:6,label:'機運'},{stat:'atk',v:7,label:'賭刃'},{stat:'int',v:5,label:'算計'}]},
  {n:'創世碎片',slot:'accessory',stat:'int',v:10,mat:'silver',role:'mage',aff:[
    {stat:'int',v:12,label:'創世'},{stat:'matk',v:12,label:'碎片'},{stat:'mp',v:48,label:'源初'},{stat:'con',v:4,label:'穩定'}]},
  {n:'終焉沙漏',slot:'accessory',stat:'spd',v:8,mat:'silver',role:'archer',aff:[
    {stat:'agi',v:9,label:'終焉'},{stat:'spd',v:10,label:'倒數'},{stat:'atk',v:7,label:'最後一箭'},{stat:'int',v:5,label:'預見'}]}
];

/** 唯一裝備專屬效果（裝備中生效；拉開與千古的差距） */
/** 唯一專屬效果：刻意高於千古共鳴同類型約 1.6～2 倍 */
const UNIQUE_EFFECTS = {
  '灰燼君王劍': {type:'lifesteal', v:0.18, desc:'攻擊吸血 18%'},
  '虛空法杖·終焉': {type:'mpOnHit', v:8, desc:'命中回復 8 MP'},
  '聖光救贖之書': {type:'healBonus', v:0.28, desc:'治療量 +28%'},
  '影殺·無聲': {type:'critBonus', v:0.18, desc:'爆擊率 +18%'},
  '蒼穹長弓': {type:'pierceBonus', v:0.30, desc:'額外穿甲 30%'},
  '不朽巨盾斧': {type:'thorns', v:0.22, desc:'反傷 22%'},
  '龍骨戰錘': {type:'stunChance', v:0.18, desc:'18% 機率擊暈 1 回合'},
  '烈陽權杖': {type:'burnBonus', v:0.22, desc:'魔法傷害 +22%'},
  '灰燼聖鎧': {type:'dmgReduce', v:0.15, desc:'受傷 -15%'},
  '虛空法袍': {type:'matkBonus', v:0.18, desc:'魔攻 +18%'},
  '龍騎士鎧': {type:'dmgReduce', v:0.12, desc:'受傷 -12%'},
  '深淵之眼': {type:'matkBonus', v:0.16, desc:'魔攻 +16%'},
  '屠龍者徽章': {type:'atkBonus', v:0.16, desc:'物攻 +16%'},
  '血怒戰斧·滅': {type:'lifesteal', v:0.16, desc:'攻擊吸血 16%'},
  '星隕法球': {type:'mpOnHit', v:9, desc:'命中回復 9 MP'},
  '鐵壁臂環': {type:'dmgReduce', v:0.12, desc:'受傷 -12%'},
  '泰坦之心核': {type:'hpBonus', v:0.18, desc:'最大生命 +18%'},
  '創世碎片': {type:'matkBonus', v:0.18, desc:'魔攻 +18%'},
  '終焉沙漏': {type:'spdBonus', v:0.15, desc:'速度 +15%'}
};
const ROLE_UNIQUE_FALLBACK = {
  warrior: {type:'lifesteal', v:0.14, desc:'攻擊吸血 14%'},
  tank:    {type:'thorns', v:0.16, desc:'反傷 16%'},
  archer:  {type:'pierceBonus', v:0.20, desc:'額外穿甲 20%'},
  rogue:   {type:'critBonus', v:0.15, desc:'爆擊率 +15%'},
  mage:    {type:'matkBonus', v:0.14, desc:'魔攻 +14%'},
  healer:  {type:'healBonus', v:0.20, desc:'治療量 +20%'}
};

/**
 * 唯一裝備專屬技能（裝備中可在戰鬥使用）
 * 標記 fromUnique:true，UI 可辨識
 */
const UNIQUE_SKILLS = {
  '灰燼君王劍': {name:'灰燼斬',mp:14,mult:2.6,type:'phys',desc:'【唯一】物攻×2.6；灰燼君王劍專屬'},
  '虛空法杖·終焉': {name:'終焉之火',mp:22,mult:2.8,type:'magic',desc:'【唯一】魔攻×2.8；虛空終焉'},
  '聖光救贖之書': {name:'救贖輝光',mp:20,heal:2.1,type:'heal',desc:'【唯一】強效單體治療'},
  '影殺·無聲': {name:'無聲處刑',mp:12,mult:2.55,type:'phys_crit',crit:0.55,desc:'【唯一】高爆擊背刺'},
  '蒼穹長弓': {name:'貫日一箭',mp:16,mult:2.7,type:'phys',desc:'【唯一】物攻×2.7 穿雲'},
  '不朽巨盾斧': {name:'不朽壁壘',mp:14,type:'guard',buffDefRatio:0.75,buffTurns:2,desc:'【唯一】嘲諷+自身防+75%'},
  '龍骨戰錘': {name:'碎顱轟擊',mp:15,mult:2.5,type:'phys',desc:'【唯一】物攻×2.5 重擊'},
  '霜噬雙刃': {name:'霜噬連斬',mp:13,mult:1.2,type:'phys_multi2',hits:2,desc:'【唯一】2 連擊，每段×1.2'},
  '烈陽權杖': {name:'烈陽焚天',mp:24,mult:1.5,type:'magic_aoe',desc:'【唯一】魔攻×1.5／敵'},
  '荆棘王鞭': {name:'荆棘鞭笞',mp:12,mult:2.35,type:'phys',desc:'【唯一】物攻×2.35'},
  '灰燼聖鎧': {name:'灰燼護持',mp:12,type:'buff',buffDefRatio:0.28,buffTurns:2,desc:'【唯一】全隊防禦+28%，2 回合'},
  '虛空法袍': {name:'虛空裂隙',mp:20,mult:1.55,type:'magic_aoe',desc:'【唯一】魔攻×1.55／敵'},
  '遊俠風衣': {name:'疾風步',mp:10,mult:2.2,type:'phys',desc:'【唯一】物攻×2.2 迅擊'},
  '暗影潛行衣': {name:'影襲',mp:11,mult:2.4,type:'phys_crit',crit:0.50,desc:'【唯一】爆擊伏擊'},
  '聖愈祭袍': {name:'聖域祈禱',mp:24,heal:1.15,type:'heal_aoe',desc:'【唯一】全隊強效治療'},
  '狂戰士皮甲': {name:'血戰咆哮',mp:12,mult:2.45,type:'phys',desc:'【唯一】物攻×2.45'},
  '龍騎士鎧': {name:'龍騎衝鋒',mp:14,mult:2.35,type:'phys',desc:'【唯一】物攻×2.35'},
  '元素編織袍': {name:'元素奔流',mp:22,mult:1.45,type:'magic_aoe',desc:'【唯一】魔攻×1.45／敵'},
  '亡者裹屍甲': {name:'亡語詛咒',mp:18,mult:1.35,type:'magic_dot',poisonTurns:3,desc:'【唯一】魔攻×1.35／敵+中毒'},
  '黎明守衛甲': {name:'黎明守護',mp:14,type:'guard',buffDefRatio:0.70,buffTurns:2,desc:'【唯一】嘲諷+防+70%'},
  '世界樹之心': {name:'樹心再生',mp:16,heal:0.35,mpGain:10,type:'self_heal',desc:'【唯一】自身最大HP×35%+10MP'},
  '時間沙漏墜': {name:'時之矢',mp:14,mult:2.4,type:'phys',desc:'【唯一】物攻×2.4'},
  '深淵之眼': {name:'深淵凝視',mp:20,mult:2.65,type:'magic',desc:'【唯一】魔攻×2.65'},
  '屠龍者徽章': {name:'屠龍一擊',mp:15,mult:2.75,type:'phys',desc:'【唯一】物攻×2.75'},
  '盜王之戒': {name:'神偷之手',mp:10,type:'steal',mult:1.35,stealMin:12,stealMax:28,desc:'【唯一】物傷+大額偷金'},
  '大賢者眼鏡': {name:'洞察魔彈',mp:16,mult:2.5,type:'magic',desc:'【唯一】魔攻×2.5'},
  '守護天使羽': {name:'羽翼庇護',mp:18,heal:1.9,type:'heal',desc:'【唯一】強效治療'},
  '泰坦之握': {name:'泰坦碎擊',mp:14,mult:2.55,type:'phys',desc:'【唯一】物攻×2.55'},
  '幻影斗篷扣': {name:'殘像斬',mp:12,mult:1.15,type:'phys_multi',hits:3,desc:'【唯一】3 連擊'},
  '永恆沙漏戒': {name:'時止魔光',mp:22,mult:2.7,type:'magic',desc:'【唯一】魔攻×2.7'},
  '血怒戰斧·滅': {name:'滅殺旋風',mp:16,mult:2.65,type:'phys',desc:'【唯一】物攻×2.65'},
  '星隕法球': {name:'星隕降臨',mp:26,mult:1.6,type:'magic_aoe',desc:'【唯一】魔攻×1.6／敵'},
  '月神銀弓': {name:'銀月箭雨',mp:18,mult:1.1,type:'phys_multi',hits:3,desc:'【唯一】3 連射'},
  '審判之錘·神': {name:'神罰一擊',mp:16,mult:2.0,type:'magic',holy:true,desc:'【唯一】魔攻×2.0；對邪惡×1.25'},
  '骨龍脊刃': {name:'龍脊裂斬',mp:15,mult:2.6,type:'phys',desc:'【唯一】物攻×2.6'},
  '風暴鎖子甲': {name:'雷甲震擊',mp:14,type:'buff',buffDefRatio:0.25,buffTurns:2,desc:'【唯一】全隊防+25%'},
  '蛛網輕甲': {name:'毒網纏繞',mp:13,mult:2.3,type:'phys',desc:'【唯一】物攻×2.3'},
  '聖堂侍從甲': {name:'聖堂祝福',mp:20,heal:1.05,type:'heal_aoe',desc:'【唯一】全隊治療'},
  '熔岩板甲': {name:'熔核護體',mp:12,type:'guard',buffDefRatio:0.72,buffTurns:2,desc:'【唯一】嘲諷+高防'},
  '寒冰巫袍': {name:'極寒風暴',mp:24,mult:1.5,type:'magic_aoe',desc:'【唯一】魔攻×1.5／敵'},
  '獵神徽章': {name:'獵神標記',mp:10,type:'mark',markTurns:3,markMult:1.4,desc:'【唯一】標記敵人受傷+40%'},
  '血契戒指': {name:'血契斬',mp:13,mult:2.5,type:'phys',desc:'【唯一】物攻×2.5'},
  '智慧蘋果墜': {name:'禁知衝擊',mp:18,mult:2.55,type:'magic',desc:'【唯一】魔攻×2.55'},
  '鐵壁臂環': {name:'鐵壁格擋',mp:11,type:'guard',buffDefRatio:0.68,buffTurns:2,desc:'【唯一】嘲諷+防'},
  '寧靜祈禱珠': {name:'寧靜聖歌',mp:22,heal:1.2,type:'heal_aoe',desc:'【唯一】全隊治療'},
  '幽靈靴': {name:'穿影步',mp:11,mult:2.35,type:'phys_crit',crit:0.45,desc:'【唯一】爆擊突襲'},
  '泰坦之心核': {name:'心核脈動',mp:14,heal:0.40,mpGain:8,type:'self_heal',desc:'【唯一】自身HP×40%+8MP'},
  '混沌骰子': {name:'賭命一擊',mp:12,mult:2.8,type:'phys_crit',crit:0.40,desc:'【唯一】高倍率豪賭'},
  '創世碎片': {name:'源初爆破',mp:25,mult:1.65,type:'magic_aoe',desc:'【唯一】魔攻×1.65／敵'},
  '終焉沙漏': {name:'終焉之箭',mp:16,mult:2.65,type:'phys',desc:'【唯一】物攻×2.65'}
};
const ROLE_UNIQUE_SKILL_FALLBACK = {
  warrior: {name:'唯一戰技',mp:12,mult:2.4,type:'phys',desc:'【唯一】物攻×2.4'},
  tank:    {name:'唯一守御',mp:12,type:'guard',buffDefRatio:0.65,buffTurns:2,desc:'【唯一】嘲諷+防'},
  archer:  {name:'唯一箭術',mp:12,mult:2.4,type:'phys',desc:'【唯一】物攻×2.4'},
  rogue:   {name:'唯一暗技',mp:11,mult:2.35,type:'phys_crit',crit:0.45,desc:'【唯一】爆擊'},
  mage:    {name:'唯一秘法',mp:18,mult:2.4,type:'magic',desc:'【唯一】魔攻×2.4'},
  healer:  {name:'唯一聖療',mp:16,heal:1.8,type:'heal',desc:'【唯一】強效治療'}
};
function getUniqueSkill(item){
  if(!item || !(item.isUnique || item.rarity==='unique')) return null;
  const key = String(item.baseName || item.name || '').replace(/^【唯一】/, '');
  const sk = item.uniqueSkill || UNIQUE_SKILLS[key] || ROLE_UNIQUE_SKILL_FALLBACK[item.role] || ROLE_UNIQUE_SKILL_FALLBACK.warrior;
  if(!sk) return null;
  // 回傳副本並標記來源，避免共用物件被改／舊存檔缺 fromUnique
  return Object.assign({}, sk, {fromUnique:true, uniqueName: key});
}
/** 角色已裝備的唯一專屬技能列表 */
function equippedUniqueSkills(member){
  if(!member || !member.equip) return [];
  const out = [];
  const seen = new Set();
  Object.values(member.equip).forEach(eq=>{
    if(!eq) return;
    const sk = getUniqueSkill(eq);
    if(!sk) return;
    const id = sk.name + '|' + (eq.baseName||eq.name);
    if(seen.has(id)) return;
    seen.add(id);
    out.push(Object.assign({}, sk, {fromUnique:true, sourceItem: eq.baseName||eq.name}));
  });
  return out;
}

function getUniqueEffect(item){
  if(!item || !(item.isUnique || item.rarity==='unique')) return null;
  if(item.effect && item.effect.type) return item.effect;
  const key = String(item.baseName || item.name || '').replace(/^【唯一】/, '');
  if(UNIQUE_EFFECTS[key]) return UNIQUE_EFFECTS[key];
  return ROLE_UNIQUE_FALLBACK[item.role] || ROLE_UNIQUE_FALLBACK.warrior;
}
/** 角色已裝備唯一效果列表 */
function equippedUniqueEffects(member){
  if(!member || !member.equip) return [];
  const out = [];
  Object.values(member.equip).forEach(eq=>{
    if(!eq) return;
    const eff = getUniqueEffect(eq);
    if(eff) out.push({item:eq, effect:eff});
  });
  return out;
}
function sumUniqueEffect(member, type){
  let s = 0;
  equippedUniqueEffects(member).forEach(({effect})=>{
    if(effect.type===type) s += num(effect.v, 0);
  });
  return s;
}
function uniqueEffectDesc(item){
  const eff = getUniqueEffect(item);
  return eff ? eff.desc : '';
}

/**
 * 千古共鳴詞條設計
 * ------------------------------------------------------------
 * 定位：千古 = 高數值隨機裝 + 一條「具名共鳴」（弱於唯一專屬，但可疊出風格）
 * 唯一 = 固定名稱 + 較強專屬效果
 * 共鳴只出現在 rarity=ancient，永遠標為「千古共鳴·XXX」
 * 每件千古恰好 1 條共鳴；數值隨 itemLevel／稀有倍率縮放
 */
const ANCIENT_RESONANCES = [
  // —— 防禦／坦克向 ——
  {id:'ironwall', name:'鐵壁', roles:['tank','warrior'], w:12,
    flats:[{stat:'def',v:8},{stat:'hp',v:32}],
    effect:null,
    desc:'防禦與生命強化，站得更久'},
  {id:'aegis', name:'聖盾', roles:['tank','healer'], w:10,
    flats:[{stat:'def',v:6},{stat:'con',v:5}],
    effect:{type:'dmgReduce', v:0.06},
    desc:'受傷 -6%，並提升防禦／體質'},
  {id:'thornroot', name:'荊根', roles:['tank','warrior'], w:8,
    flats:[{stat:'def',v:5},{stat:'hp',v:20}],
    effect:{type:'thorns', v:0.08},
    desc:'反傷 8%，適合反打坦克'},
  {id:'titanbone', name:'泰坦骨', roles:['tank','warrior'], w:8,
    flats:[{stat:'hp',v:45},{stat:'str',v:4}],
    effect:{type:'hpBonus', v:0.06},
    desc:'最大生命 +6%，厚血線'},
  // —— 物理輸出 ——
  {id:'bloodrage', name:'血怒', roles:['warrior','rogue'], w:11,
    flats:[{stat:'atk',v:7},{stat:'str',v:4}],
    effect:{type:'lifesteal', v:0.06},
    desc:'攻擊吸血 6%，對砍更穩'},
  {id:'sunder', name:'裂甲', roles:['warrior','archer'], w:10,
    flats:[{stat:'atk',v:6},{stat:'str',v:3}],
    effect:{type:'pierceBonus', v:0.10},
    desc:'額外穿甲 10%'},
  {id:'eagleshot', name:'鷹眼', roles:['archer','rogue'], w:10,
    flats:[{stat:'atk',v:5},{stat:'agi',v:5}],
    effect:{type:'critBonus', v:0.07},
    desc:'爆擊率 +7%'},
  {id:'gale', name:'疾風', roles:['archer','rogue','warrior'], w:9,
    flats:[{stat:'spd',v:5},{stat:'agi',v:4}],
    effect:{type:'spdBonus', v:0.06},
    desc:'速度 +6%，更容易先手'},
  {id:'shadowfang', name:'影牙', roles:['rogue'], w:9,
    flats:[{stat:'atk',v:5},{stat:'spd',v:4}],
    effect:{type:'critBonus', v:0.05},
    desc:'爆擊與速度兼顧的暗殺共鳴'},
  // —— 魔法／治療 ——
  {id:'arcane', name:'奧術', roles:['mage'], w:12,
    flats:[{stat:'matk',v:7},{stat:'int',v:5}],
    effect:{type:'matkBonus', v:0.07},
    desc:'魔攻 +7%'},
  {id:'manaspring', name:'法泉', roles:['mage','healer'], w:10,
    flats:[{stat:'mp',v:28},{stat:'int',v:4}],
    effect:{type:'mpOnHit', v:3},
    desc:'命中回復 3 MP'},
  {id:'sunfire', name:'日炎', roles:['mage','healer'], w:9,
    flats:[{stat:'matk',v:6},{stat:'mp',v:16}],
    effect:{type:'burnBonus', v:0.08},
    desc:'魔法傷害 +8%'},
  {id:'mercy', name:'慈恩', roles:['healer'], w:12,
    flats:[{stat:'int',v:5},{stat:'mp',v:24}],
    effect:{type:'healBonus', v:0.10},
    desc:'治療量 +10%'},
  {id:'dawn', name:'破曉', roles:['healer','tank'], w:8,
    flats:[{stat:'con',v:4},{stat:'mp',v:18}],
    effect:{type:'healBonus', v:0.06},
    desc:'偏生存的治療共鳴'},
  // —— 萬用／成長 ——
  {id:'eternity', name:'永恆', roles:['tank','warrior','archer','rogue','mage','healer'], w:6,
    flats:[{stat:'hp',v:24},{stat:'mp',v:16}],
    effect:null,
    desc:'生命與魔力雙成長'},
  {id:'harmony', name:'調和', roles:['tank','warrior','archer','rogue','mage','healer'], w:5,
    flats:[{stat:'str',v:3},{stat:'con',v:3},{stat:'agi',v:3},{stat:'int',v:3}],
    effect:null,
    desc:'四維各少量提升'},
  {id:'apex', name:'極致', roles:['warrior','archer','rogue','mage'], w:5,
    flats:[{stat:'atk',v:4},{stat:'matk',v:4}],
    effect:{type:'critBonus', v:0.04},
    desc:'物魔皆可、附帶一點爆擊'}
];

function pickAncientResonance(rng, role, slot){
  rng = rng || Math.random;
  role = role || 'warrior';
  // 依角色權重過濾；若無命中則退回全池
  let pool = ANCIENT_RESONANCES.filter(r=> (r.roles||[]).includes(role));
  if(!pool.length) pool = ANCIENT_RESONANCES.slice();
  // 防具略偏防禦向、武器略偏輸出向（權重微調）
  const weighted = pool.map(r=>{
    let w = r.w || 5;
    if(slot==='armor' && (r.effect&& (r.effect.type==='dmgReduce'||r.effect.type==='thorns') || r.id==='ironwall'||r.id==='titanbone')) w *= 1.4;
    if(slot==='weapon' && (r.effect&& (r.effect.type==='lifesteal'||r.effect.type==='pierceBonus'||r.effect.type==='burnBonus'))) w *= 1.3;
    if(slot==='accessory' && (r.id==='eternity'||r.id==='harmony'||r.id==='manaspring')) w *= 1.25;
    return {item:r, w};
  });
  return weightedChoice(rng, weighted);
}

/** 把共鳴寫進 affixes + item.resonance（戰鬥用） */
function applyAncientResonance(item, rng, rarity, itemLevel){
  if(!item) return item;
  rng = rng || Math.random;
  const res = pickAncientResonance(rng, item.role, item.slot);
  if(!res) return item;
  const lvlFactor = 1 + Math.max(0, (itemLevel||1)-1) * 0.05;
  // 扁平數值：吃千古倍率，略高於普通附加
  (res.flats||[]).forEach((f, idx)=>{
    const baseV = f.v;
    const value = Math.max(1, Math.round(baseV * (rarity?.mult||5.2) * 0.55 * lvlFactor * (0.92 + rng()*0.16)));
    item.affixes = item.affixes || [];
    item.affixes.push({
      stat: f.stat,
      value,
      label: idx===0 ? ('千古共鳴·'+res.name) : ('共鳴·'+res.name)
    });
  });
  item.resonance = {
    id: res.id,
    name: res.name,
    desc: res.desc,
    type: res.effect ? res.effect.type : null,
    v: res.effect ? res.effect.v : 0
  };
  return item;
}

function resonanceDesc(item){
  if(!item || !item.resonance) return '';
  const r = item.resonance;
  return r.name ? (r.name+'：'+(r.desc||'')) : '';
}

/** 唯一 + 千古共鳴 的特殊效果加總 */
function sumEquipSpecial(member, type){
  let s = 0;
  if(typeof sumUniqueEffect === 'function') s += sumUniqueEffect(member, type);
  if(!member || !member.equip) return s;
  Object.values(member.equip).forEach(eq=>{
    if(eq && eq.resonance && eq.resonance.type===type) s += num(eq.resonance.v, 0);
  });
  return s;
}

function avgPartyLevel(s){
  s = s || S;
  if(!s || !s.party || !s.party.length) return 1;
  const sum = s.party.reduce((a,m)=> a + num(m.level, 1), 0);
  const avg = Math.round(sum / s.party.length);
  return clamp(avg, 1, MAX_PLAYER_LEVEL);
}

/** 法杖／法器／書／球 等 → 主屬應為魔攻 */
function isMagicWeaponName(name){
  if(!name) return false;
  const n = String(name);
  return /法杖|權杖|魔杖|法球|法器|魔導|聖典|法典|魔導書|法書|奧術|水晶球|星隕|法袍|巫袍/.test(n);
}

/** 主詞條可否為 matk：法器武器，或法師／治療向裝備（含頭／披風／飾品等） */
function canMainBeMatk(item){
  if(!item) return false;
  const nm = item.baseName || item.name || '';
  if(item.slot==='weapon') return isMagicWeaponName(nm);
  // 胸甲主屬仍應為防（即使 role=mage）
  if(item.slot==='armor') return false;
  // 法師／治療向的頭、披風、手、鞋、飾品、副手可主魔攻
  if(item.role==='mage' || item.role==='healer'){
    return item.stat==='matk' || item.stat==='int' || isMagicWeaponName(nm);
  }
  return false;
}

/** 依槽位／角色推一個合理的主詞條（當錯誤 matk 被擋下時用） */
function fallbackMainStat(item){
  if(!item) return 'atk';
  if(item.slot==='armor') return 'def';
  if(item.slot==='accessory'){
    if(item.role==='tank') return 'con';
    if(item.role==='mage' || item.role==='healer') return 'int';
    if(item.role==='archer' || item.role==='rogue') return 'agi';
    return 'str';
  }
  // weapon
  if(item.role==='mage' || item.role==='healer'){
    return isMagicWeaponName(item.baseName||item.name||'') ? 'matk' : 'atk';
  }
  return 'atk';
}

/** 法器主屬強制魔攻；非法器若主屬誤為 matk 則改回合理物攻／防／屬性 */
function forceMagicMainStat(item){
  if(!item || item.slot==='potion') return item;
  const nm = item.baseName || item.name || '';
  const main = (item.affixes && item.affixes.length)
    ? (item.affixes.find(a=>a.label==='主屬性') || item.affixes[0])
    : null;

  // 1) 法器武器 → 主屬必須 matk
  if(item.slot==='weapon' && isMagicWeaponName(nm)){
    if(item.stat==='atk') item.stat = 'matk';
    if(main && main.stat==='atk') main.stat = 'matk';
    return item;
  }

  // 2) 非合法魔攻主詞條 → 改掉（坦克甲、物攻武器等不可主魔攻）
  const mainStatNow = main ? main.stat : item.stat;
  if(mainStatNow==='matk' && !canMainBeMatk(item)){
    const fb = fallbackMainStat(item);
    item.stat = fb;
    if(main) main.stat = fb;
  }
  return item;
}
function itemStatSum(item, st){
  if(!item) return 0;
  if(item.affixes && item.affixes.length)
    return item.affixes.filter(a=>a.stat===st).reduce((s,a)=>s+(num(a.value,0)),0);
  let v=0;
  if(item.stat===st) v+=num(item.value,0);
  if(item.extraStat===st) v+=num(item.extraValue,0);
  return v;
}
function itemPowerScore(item){
  if(!item || item.slot==='potion') return 0;
  const weights = {atk:1.2,matk:1.2,def:1.0,spd:0.9,hp:0.08,mp:0.06,str:1.1,con:1.0,agi:1.0,int:1.1};
  let s = 0;
  Object.keys(weights).forEach(st=>{ s += itemStatSum(item, st) * weights[st]; });
  s += (item.itemLevel||1) * 0.5;
  if(item.rarity==='unique' || item.isUnique) s += 45;
  return s;
}
/** 全隊（含背包）是否已有同名唯一 */
/** 全隊裝備欄是否已有同名唯一（倉庫／背包可收藏，但不能再穿第二件） */
function uniqueAlreadyEquipped(item, ignoreUid){
  if(!item || !(item.isUnique || item.rarity==='unique')) return false;
  const st = (typeof S!=='undefined' && S) ? S : (typeof globalThis!=='undefined' ? globalThis.S : null);
  if(!st) return false;
  const key = item.baseName || item.name;
  const match = (eq)=> eq && (eq.isUnique || eq.rarity==='unique') && (eq.baseName===key || eq.name===item.name || eq.name===key);
  for(const p of (st.party||[])){
    if(!p || !p.equip) continue;
    for(const eq of Object.values(p.equip)){
      if(match(eq) && eq.uid!==ignoreUid) return true;
    }
  }
  return false;
}
function uniqueAlreadyHeld(item, ignoreUid){
  return uniqueAlreadyEquipped(item, ignoreUid);
}

function rarityById(id){
  if(RARITY_LEGACY_MAP[id]) id = RARITY_LEGACY_MAP[id];
  return RARITIES.find(r=>r.id===id) || RARITIES[1];
}

function scaleAffixValue(baseV, rarity, itemLevel, rng){
  const lvlFactor = 1 + Math.max(0, (itemLevel||1)-1) * 0.05;
  const variance = 1 + ((rng() * 2 - 1) * (rarity.variance||0.1));
  return Math.max(1, Math.round(baseV * rarity.mult * lvlFactor * variance));
}

function pickRoleAffixes(rng, role, count, rarity, itemLevel, usedStats){
  // 附加詞條：以角色池為主，約 25% 抽通用池（可出現魔攻等異屬）——僅附加，不影響主詞條
  const pool = (ROLE_AFFIX_POOL[role] || GENERIC_AFFIX_POOL).slice();
  const gen = GENERIC_AFFIX_POOL.slice();
  const result = [];
  usedStats = usedStats || new Set();
  for(let i=0;i<count;i++){
    let src;
    if(pool.length && rng() >= 0.25) src = pool;
    else if(gen.length) src = gen;
    else src = pool.length ? pool : GENERIC_AFFIX_POOL.slice();
    if(!src.length) src = GENERIC_AFFIX_POOL.slice();
    const idx = Math.floor(rng()*src.length);
    const template = src.splice(idx,1)[0] || choice(rng, GENERIC_AFFIX_POOL);
    result.push({
      stat: template.stat,
      value: scaleAffixValue(template.v, rarity, itemLevel, rng),
      label: template.label
    });
  }
  return result;
}

function rollEquip(rng, minRarity, itemLevel){
  itemLevel = itemLevel || 1;
  rng = rng || Math.random;

  // 極低機率掉唯一
  if(rng() < 0.006 && (!minRarity || RARITIES.findIndex(r=>r.id===(RARITY_LEGACY_MAP[minRarity]||minRarity)) <= 11)){
    return rollUniqueEquip(rng, itemLevel);
  }

  // 欄位權重：武器/胸甲常見，新欄位較少
  const slot = weightedChoice(rng, [
    {item:'weapon',w:28},{item:'armor',w:22},{item:'accessory',w:14},
    {item:'offhand',w:10},{item:'head',w:9},{item:'cape',w:6},{item:'hands',w:6},{item:'feet',w:5}
  ]);
  const basePool = EQUIP_BASES[slot] || EQUIP_BASES.weapon;
  const base = choice(rng, basePool);
  const minId = minRarity ? (RARITY_LEGACY_MAP[minRarity]||minRarity) : null;
  const minIdx = minId ? RARITIES.findIndex(r=>r.id===minId) : -1;
  const pool = RARITIES.filter((r,i)=> i>=Math.max(0,minIdx) && r.id!=='unique');
  const rarity = weightedChoice(rng, pool.map(r=>({item:r, w:r.w})));
  const lvlFactor = 1 + Math.max(0, itemLevel-1) * 0.05;
  const variance = 1 + ((rng()*2-1) * rarity.variance);
  // 主詞條：法器→matk；防具→def；其餘用基底。附加詞條可跨屬（含魔攻）
  let mainStat = base.stat;
  if(slot==='armor') mainStat = 'def';
  else if(slot==='weapon' && isMagicWeaponName(base.n)) mainStat = 'matk';
  // 安全網：非魔攻合法件若基底誤標 matk，改回
  if(mainStat==='matk'){
    const tmp = {slot, baseName: base.n, name: base.n, role: base.role, stat: mainStat};
    if(!canMainBeMatk(tmp)) mainStat = (slot==='armor' ? 'def' : 'atk');
  }
  let mainValue = Math.max(1, Math.round(base.v * rarity.mult * lvlFactor * variance));

  const affixes = [{stat: mainStat, value: mainValue, label: '主屬性'}];
  if(rarity.affixCount > 0){
    // 附加詞條：主池仍依角色；法器偏向法師池。附加允許出現異屬（含魔攻）
    const affRole = (slot==='weapon' && isMagicWeaponName(base.n)) ? 'mage' : base.role;
    const extras = pickRoleAffixes(rng, affRole, rarity.affixCount, rarity, itemLevel, new Set([mainStat]));
    affixes.push(...extras);
  }

  // 千古：主屬再強化；共鳴在物件組好後套用（具名詞條 + 可選戰鬥效果）
  if(rarity.id === 'ancient'){
    const boost = Math.max(1, Math.round(mainValue * 0.12));
    mainValue += boost;
    affixes[0].value = mainValue;
  }

  const item = {
    uid: 'eq_'+Math.floor(rng()*1e9),
    slot,
    name: rarity.name + base.n,
    baseName: base.n,
    material: base.mat,
    role: base.role,
    stat: mainStat,
    value: mainValue,
    affixes,
    // 相容舊欄位
    extraStat: affixes[1] ? affixes[1].stat : null,
    extraValue: affixes[1] ? affixes[1].value : 0,
    rarity: rarity.id,
    rarityName: rarity.name,
    rarityHex: rarity.hex,
    itemLevel,
    locked: false,
    seed: base.n + rarity.id + Math.floor(rng()*999)
  };
  if(rarity.id === 'ancient') applyAncientResonance(item, rng, rarity, itemLevel);
  return item;
}

function rollUniqueEquip(rng, itemLevel){
  const template = choice(rng, UNIQUE_ITEMS);
  const rarity = RARITIES.find(r=>r.id==='unique');
  // 唯一數值檔：等級係數略優於千古、主屬與專屬詞條再乘一檔
  const lvlFactor = 1 + Math.max(0, (itemLevel||1)-1) * 0.055;
  let mainStat = template.stat;
  // 唯一裝也套用主詞條規則：非法器不可主魔攻
  const probe = {slot: template.slot, baseName: template.n, name: template.n, role: template.role, stat: mainStat};
  if(mainStat==='matk' && !canMainBeMatk(probe)){
    mainStat = template.slot==='armor' ? 'def' : (template.slot==='accessory' ? fallbackMainStat(probe) : 'atk');
  }
  if(template.slot==='weapon' && isMagicWeaponName(template.n)) mainStat = 'matk';
  if(template.slot==='armor') mainStat = 'def';
  const UNIQUE_MAIN_BONUS = 1.20;   // 主屬比純倍率再高一檔
  const UNIQUE_AFFIX_BONUS = 1.30;  // 專屬四詞條再高一檔
  const mainValue = Math.max(1, Math.round(template.v * rarity.mult * lvlFactor * UNIQUE_MAIN_BONUS));
  const affixes = [{stat: mainStat, value: mainValue, label: '主屬性'}];
  template.aff.forEach(a=>{
    affixes.push({
      stat: a.stat,
      value: Math.max(1, Math.round(a.v * (1.05 + rng()*0.15) * lvlFactor * UNIQUE_AFFIX_BONUS)),
      label: a.label
    });
  });
  // 唯一以 baseName 判斷持有；uid 仍唯一避免 DOM/filter 衝突
  return {
    uid: 'unique_'+template.n+'_'+Math.floor(rng()*1e6),
    slot: template.slot,
    name: '【唯一】'+template.n,
    baseName: template.n,
    material: template.mat,
    role: template.role,
    stat: mainStat,
    value: mainValue,
    affixes,
    extraStat: affixes[1]?affixes[1].stat:null,
    extraValue: affixes[1]?affixes[1].value:0,
    rarity: 'unique',
    rarityName: '唯一',
    rarityHex: rarity.hex,
    itemLevel: itemLevel||1,
    isUnique: true,
    locked: false,
    effect: getUniqueEffect({baseName:template.n, role:template.role, isUnique:true, rarity:'unique'}),
    uniqueSkill: getUniqueSkill({baseName:template.n, role:template.role, isUnique:true, rarity:'unique'}),
    seed: 'unique_'+template.n
  };
}

function equipPrice(item){
  if(!item) return 0;
  const r = rarityById(item.rarity);
  const affixSum = (item.affixes||[]).reduce((s,a)=>s+(a.value||0),0);
  const base = item.value || 0;
  return Math.max(8, Math.round((base*8 + affixSum*6) * (r.mult||1) + (item.itemLevel||1)*3));
}

/** 把舊裝備資料升級成新 affixes 格式；修正法器主屬、唯一旗標 */
function normalizeItem(item){
  if(!item || item.slot==='potion') return item;
  const isLegacy = !item.affixes || !item.affixes.length;
  if(isLegacy && RARITY_LEGACY_MAP[item.rarity]){
    item.rarity = RARITY_LEGACY_MAP[item.rarity];
    const r = rarityById(item.rarity);
    item.rarityName = r.name;
    item.rarityHex = r.hex;
  } else if(item.rarity){
    const r = rarityById(item.rarity);
    if(!item.rarityName) item.rarityName = r.name;
    if(!item.rarityHex) item.rarityHex = r.hex;
  }
  if(item.rarity==='unique') item.isUnique = true;
  if(isLegacy){
    item.affixes = [];
    if(item.stat && item.value) item.affixes.push({stat:item.stat, value:item.value, label:'主屬性'});
    if(item.extraStat && item.extraValue) item.affixes.push({stat:item.extraStat, value:item.extraValue, label:'附加'});
  }
  // 法杖類主屬強制魔攻（修正舊存檔／錯誤 roll）
  forceMagicMainStat(item);
  // 保證主屬性與 item.stat/value 同步（equipBonus 以 affixes 為準）
  if(item.affixes && item.affixes.length){
    const main = item.affixes.find(a=>a.label==='主屬性') || item.affixes[0];
    if(main){
      item.stat = main.stat;
      item.value = main.value;
    }
  }
  // 唯一：補齊專屬技能／被動（舊存檔可能沒有）
  if(item.isUnique || item.rarity==='unique'){
    if(!item.baseName && item.name){
      item.baseName = String(item.name).replace(/^【唯一】/, '');
    }
    if(!item.uniqueSkill && typeof getUniqueSkill === 'function'){
      const sk = getUniqueSkill(item);
      if(sk) item.uniqueSkill = sk;
    }
    if(!item.effect && typeof getUniqueEffect === 'function'){
      const eff = getUniqueEffect(item);
      if(eff) item.effect = eff;
    }
  }
  return item;
}

/** 安全加入背包：正規化 + 唯一不重複 + 滿包自動進倉庫 */
function addToInventory(item){
  if(!item) return false;
  if(!S) return false;
  if(!S.inventory) S.inventory = [];
  ensureWarehouse();
  if(item.slot==='potion'){
    addPotion(item.kind, item.value, item.name);
    return true;
  }
  normalizeItem(item);
  if(item.isUnique || item.rarity==='unique'){
    if(uniqueAlreadyEquipped(item, item.uid)){
      if(S.log) S.log.unshift('【唯一】'+(item.baseName||item.name)+' 已擁有，無法再取得。');
      return false;
    }
  }
  // 背包未滿 → 進背包；已滿 → 倉庫／折價
  if(backpackHasSpace(1)){
    S.inventory.push(item);
    return true;
  }
  const fate = overflowDispose(item, false);
  return fate === 'warehouse' || fate === 'sold';
}

