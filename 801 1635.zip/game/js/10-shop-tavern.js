/* ============ 商店系統 ============ */
const SHOP_SIZE = 6;
const SHOP_REROLL_COST = 25;
function potionPrice(kind){ return kind==='mp' ? 25 : 30; }
function generateShopStock(){
  const lvl = avgPartyLevel();
  const stock = [];
  for(let i=0;i<SHOP_SIZE;i++){
    if(Math.random() < 0.35){
      const kind = Math.random()<0.5 ? 'hp' : 'mp';
      const item = {
        uid:'pot_shop_'+Math.floor(Math.random()*1e9), slot:'potion', kind,
        name: kind==='mp' ? '魔力藥水' : '治療藥水', value: kind==='mp' ? 40 : 60
      };
      stock.push({item, price: potionPrice(kind), sold:false});
    } else {
      const item = rollEquip(Math.random, null, lvl);
      stock.push({item, price: equipPrice(item), sold:false});
    }
  }
  S.shopStock = stock;
}
function renderShop(){
  if(!S.shopStock) generateShopStock();
  const hero = S.hero;
  const tab = S.shopTab || 'buy';
  let body = '';
  if(tab==='buy'){
    const rows = S.shopStock.map((entry,i)=>{
      const it = entry.item;
      const isPotion = it.slot==='potion';
      if(entry.sold){
        return `<div class="item-row" style="opacity:.4;">
          <div><span class="${isPotion?'':'rarity-'+it.rarity}">${esc(it.name)}</span> <span class="meta">已售出</span></div>
        </div>`;
      }
      const canAfford = hero.gold >= entry.price;
      if(isPotion){
        const icon = it.kind==='mp' ? '💧' : '🧪';
        const statName = it.kind==='mp' ? 'MP' : 'HP';
        return `<div class="item-row">
          <div><span>${icon} ${esc(it.name)}</span> <span class="meta">恢復 ${it.value} ${statName}</span></div>
          <button class="btn ${canAfford?'gold':''}" data-buy="${i}" ${canAfford?'':'disabled'}>💰 ${entry.price}</button>
        </div>`;
      }
      const label = slotLabelOf(it.slot);
      return `<div class="item-row">
        <div style="display:flex;align-items:center;gap:8px;">
          <canvas class="sprite" id="shop-${i}" width="40" height="40"></canvas>
          <div><div class="rarity-${it.rarity}">${esc(it.name)}</div><div class="meta">${label} ${equipAffixText(it)} · Lv.${it.itemLevel}</div></div>
        </div>
        <button class="btn ${canAfford?'gold':''}" data-buy="${i}" ${canAfford?'':'disabled'}>💰 ${entry.price}</button>
      </div>`;
    }).join('');
    body = rows;
  } else {
    const equipItems = S.inventory.filter(i=>i.slot!=='potion');
    body = equipItems.map(it=>{
      const label = slotLabelOf(it.slot);
      const sellPrice = Math.round(equipPrice(it)*0.4);
      const lockNote = it.locked ? ' · 🔒已鎖定' : '';
      return `<div class="item-row">
        <div><div class="rarity-${it.rarity}">${esc(it.name)}</div><div class="meta">${label} ${equipAffixText(it)} · Lv.${it.itemLevel||1}${lockNote}</div></div>
        <button class="btn danger" data-sell="${it.uid}" ${it.locked?'disabled':''}>${it.locked?'已鎖定':'賣出 💰'+sellPrice}</button>
      </div>`;
    }).join('') || '<p class="small">背包裡沒有可以出售的裝備。</p>';
  }
  const rerollAfford = hero.gold >= SHOP_REROLL_COST;
  const sellCount = S.inventory.filter(i=>i.slot!=='potion' && !i.locked).length;
  return `
  <div class="panel">
    <div class="topbar">
      <span class="pixel-font" style="font-size:11px;color:var(--gold);">💰 ${hero.gold} 金幣</span>
    </div>
    <div class="segmented">
      <button class="btn ${tab==='buy'?'active':''}" data-tab="buy">🛒 購買</button>
      <button class="btn ${tab==='sell'?'active':''}" data-tab="sell">💸 販賣</button>
    </div>
    ${body}
    <hr class="divider">
    <div class="action-row" style="justify-content:center;">
      ${tab==='buy'?`<button class="btn ${rerollAfford?'':'danger'}" id="reroll-btn" ${rerollAfford?'':'disabled'}>🔄 更新商品（${SHOP_REROLL_COST} 金幣）</button>`:''}
      ${tab==='sell' && sellCount>0?`<button class="btn danger" id="sell-all-btn">💸 一鍵賣出全部（${sellCount}件）</button>`:''}
      <button class="btn" id="back-hub4">返回營地</button>
    </div>
  </div>`;
}
function bindShop(){
  const tab = S.shopTab || 'buy';
  if(tab==='buy'){
    S.shopStock.forEach((entry,i)=>{ if(!entry.sold && entry.item.slot!=='potion') queueEquipIcon('shop-'+i, entry.item.seed, entry.item.slot, entry.item.rarityHex); });
  }
  document.querySelectorAll('[data-tab]').forEach(btn=> btn.addEventListener('click', ()=>{
    S.shopTab = btn.dataset.tab;
    render();
  }));
  document.querySelectorAll('[data-buy]').forEach(btn=> btn.addEventListener('click', ()=>{
    const idx = parseInt(btn.dataset.buy);
    const entry = S.shopStock[idx];
    if(!entry || entry.sold) return;
    if(S.hero.gold < entry.price) return;
    if(entry.item.slot==='potion'){
      S.hero.gold -= entry.price;
      addPotion(entry.item.kind, entry.item.value, entry.item.name);
      entry.sold = true;
      S.log.unshift('花費 '+entry.price+' 金幣，從商店購入了 '+entry.item.name+'。');
    } else {
      if(!addToInventory(entry.item)){
        S.log.unshift('無法購入：'+entry.item.name+'（唯一裝備已擁有）。');
        render();
        return;
      }
      S.hero.gold -= entry.price;
      entry.sold = true;
      S.log.unshift('花費 '+entry.price+' 金幣，從商店購入了 '+entry.item.name+'。');
    }
    render();
  }));
  document.querySelectorAll('[data-sell]').forEach(btn=> btn.addEventListener('click', ()=>{
    const item = S.inventory.find(i=>i.uid===btn.dataset.sell);
    if(!item) return;
    if(item.locked){ S.log.unshift('無法賣出：'+item.name+' 已鎖定。'); render(); return; }
    const sellPrice = Math.round(equipPrice(item)*0.4);
    S.inventory = S.inventory.filter(i=>i.uid!==item.uid);
    S.hero.gold += sellPrice;
    S.log.unshift('賣出了 '+item.name+'，獲得 '+sellPrice+' 金幣。');
    render();
  }));
  const rerollBtn = document.getElementById('reroll-btn');
  if(rerollBtn) rerollBtn.addEventListener('click', ()=>{
    if(S.hero.gold < SHOP_REROLL_COST) return;
    S.hero.gold -= SHOP_REROLL_COST;
    generateShopStock();
    S.log.unshift('花費 '+SHOP_REROLL_COST+' 金幣，更新了商店的商品。');
    render();
  });
  const sellAllBtn = document.getElementById('sell-all-btn');
  if(sellAllBtn) sellAllBtn.addEventListener('click', ()=>{
    const items = S.inventory.filter(i=>i.slot!=='potion' && !i.locked);
    if(items.length===0){ S.log.unshift('沒有可賣出的裝備（鎖定中的不會被賣）。'); render(); return; }
    let total = 0;
    const ids = new Set(items.map(it=>it.uid));
    items.forEach(it=> total += Math.round(equipPrice(it)*0.4));
    S.inventory = S.inventory.filter(i=>i.slot==='potion' || i.locked || !ids.has(i.uid));
    S.hero.gold += total;
    S.log.unshift('一鍵賣出了 '+items.length+' 件裝備，獲得 '+total+' 金幣。');
    render();
  });
  const back = document.getElementById('back-hub4');
  if(back) back.addEventListener('click', ()=>{ routeHome(); render(); });
}

/* ============ 酒館招募系統 ============ */
const TAVERN_SIZE = 4;
const TAVERN_REROLL_COST = 15;
function recruitCost(){
  return Math.round(40 + avgPartyLevel()*3);
}
function generateTavernStock(){
  const stock = [];
  for(let i=0;i<TAVERN_SIZE;i++){
    stock.push({npc: makeRandomAlly(), price: recruitCost(), recruited:false});
  }
  S.tavernStock = stock;
}
function renderTavern(){
  if(!S.tavernStock) generateTavernStock();
  const hero = S.hero;
  const full = S.party.length>=4;
  const rows = S.tavernStock.map((entry,i)=>{
    const npc = entry.npc;
    if(entry.recruited){
      return `<div class="item-row" style="opacity:.4;">
        <div><span>${esc(npc.name)}</span> <span class="meta">已加入隊伍</span></div>
      </div>`;
    }
    const canAfford = hero.gold >= entry.price;
    const disabled = full || !canAfford;
    return `<div class="item-row">
      <div style="display:flex;align-items:center;gap:8px;">
        <canvas class="sprite" id="tavern-${i}" width="44" height="44"></canvas>
        <div><b>${esc(npc.name)}</b><div class="meta">普通人 · 待覺醒 · Lv.${npc.level}</div></div>
      </div>
      <button class="btn ${disabled?'':'gold'}" data-recruit="${i}" ${disabled?'disabled':''}>💰 ${entry.price}</button>
    </div>`;
  }).join('');
  const rerollAfford = hero.gold >= TAVERN_REROLL_COST;
  return `
  <div class="panel">
    <div class="topbar">
      <span class="pixel-font" style="font-size:11px;color:var(--gold);">💰 ${hero.gold} 金幣</span>
      <span class="small">隊伍 ${S.party.length}/4 人</span>
    </div>
    <p class="section-title">🍺 酒館 — 可招募的旅人</p>
    ${full ? '<p class="event-text">隊伍已經滿員了，無法再招募新的夥伴。</p>' : ''}
    ${rows}
    <hr class="divider">
    <div class="action-row" style="justify-content:center;">
      <button class="btn ${rerollAfford?'':'danger'}" id="tavern-reroll-btn" ${rerollAfford?'':'disabled'}>🔄 更換旅人（${TAVERN_REROLL_COST} 金幣）</button>
      <button class="btn" id="back-hub5">返回營地</button>
    </div>
  </div>`;
}
function bindTavern(){
  S.tavernStock.forEach((entry,i)=>{ if(!entry.recruited) queueSprite('tavern-'+i, (entry.npc.name||'npc')+'_'+entry.npc.uid, memberPalette(entry.npc), 14, {kind:'human'}); });
  document.querySelectorAll('[data-recruit]').forEach(btn=> btn.addEventListener('click', ()=>{
    const idx = parseInt(btn.dataset.recruit);
    const entry = S.tavernStock[idx];
    if(!entry || entry.recruited) return;
    if(S.party.length>=4){ S.log.unshift('隊伍已滿員，無法招募更多夥伴。'); render(); return; }
    if(S.hero.gold < entry.price) return;
    S.hero.gold -= entry.price;
    S.party.push(entry.npc);
    entry.recruited = true;
    S.log.unshift('花費 '+entry.price+' 金幣，'+entry.npc.name+' 加入了你的隊伍！');
    render();
  }));
  const rerollBtn = document.getElementById('tavern-reroll-btn');
  if(rerollBtn) rerollBtn.addEventListener('click', ()=>{
    if(S.hero.gold < TAVERN_REROLL_COST) return;
    S.hero.gold -= TAVERN_REROLL_COST;
    generateTavernStock();
    S.log.unshift('花費 '+TAVERN_REROLL_COST+' 金幣，酒館換了一批新旅人。');
    render();
  });
  const back = document.getElementById('back-hub5');
  if(back) back.addEventListener('click', ()=>{ routeHome(); render(); });
}

function renderParty(){
  const cards = S.party.map((m,i)=>{
    const canDismiss = !m.isHero && S.party.length>1;
    return `<div class="hero-slot">
      <canvas class="sprite" id="pty-${i}" width="52" height="52"></canvas>
      <div style="flex:1;">
        <b>${esc(m.name)}${m.isHero?' (你)':''}</b> · ${esc(displayClassName(m))} · Lv.${m.level}
        <div class="small">HP ${m.hp}/${m.maxHp} ・ MP ${m.mp}/${m.maxMp} ・ EXP ${m.exp}/${m.nextExp}</div>
        <div class="small">物攻 ${statTotal(m,'atk')} / 魔攻 ${statTotal(m,'matk')} / 防 ${statTotal(m,'def')} / 速 ${statTotal(m,'spd')}</div>
        <div class="small">力${m.str||0} 體${m.con||0} 敏${m.agi||0} 智${m.int||0}</div>
      </div>
      ${canDismiss?`<button class="btn danger" data-dismiss="${m.uid}">遣散</button>`:''}
    </div>`;
  }).join('');
  return `
  <div class="panel">
    <p class="section-title">隊伍管理（最多4人）</p>
    ${cards}
    <div style="text-align:center;margin-top:10px;"><button class="btn" id="back-hub3">返回營地</button></div>
    <hr class="divider">
    <div class="inv-bonus-line" style="text-align:center;margin:8px 0 4px;">存檔 · 上次：<b id="save-time-label">${formatSavedAt(S.savedAt)}</b></div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-bottom:6px;">
      <button class="btn" id="manual-save-btn">💾 手動存檔</button>
      <button class="btn" id="export-save-btn">📤 匯出</button>
      <button class="btn" id="import-save-btn">📥 匯入</button>
    </div>
    <input type="file" id="import-save-file" accept="application/json,.json" style="display:none"/>
    <div style="text-align:center;"><button class="flee-link" id="restart-game-btn">🗑️ 放棄進度，重新開始遊戲</button></div>
  </div>`;
}
function bindParty(){
  S.party.forEach((m,i)=> queueSprite('pty-'+i, (m.name||'hero')+'_'+m.uid, memberPalette(m), 14, {kind:'human'}));
  document.querySelectorAll('[data-dismiss]').forEach(btn=> btn.addEventListener('click', ()=>{
    S.party = S.party.filter(m=>m.uid!==btn.dataset.dismiss);
    render();
  }));
  const back = document.getElementById('back-hub3');
  if(back) back.addEventListener('click', ()=>{ routeHome(); render(); });
  const restartBtn = document.getElementById('restart-game-btn');
  if(restartBtn) restartBtn.addEventListener('click', restartGame);
  const manSave = document.getElementById('manual-save-btn');
  if(manSave) manSave.addEventListener('click', ()=>{ saveGame(true); render(); });
  const expBtn = document.getElementById('export-save-btn');
  if(expBtn) expBtn.addEventListener('click', ()=>{ exportSave(); render(); });
  const impBtn = document.getElementById('import-save-btn');
  const impFile = document.getElementById('import-save-file');
  if(impBtn && impFile){
    impBtn.addEventListener('click', ()=> impFile.click());
    impFile.addEventListener('change', ()=>{
      const f = impFile.files && impFile.files[0];
      if(!f) return;
      const reader = new FileReader();
      reader.onload = ()=> importSaveFromText(String(reader.result||''));
      reader.readAsText(f);
      impFile.value = '';
    });
  }
}

function bonusSummary(b){
  const parts=[];
  if(b.hp) parts.push('HP'+(b.hp>0?'+':'')+b.hp);
  if(b.mp) parts.push('MP'+(b.mp>0?'+':'')+b.mp);
  if(b.atk) parts.push('ATK'+(b.atk>0?'+':'')+b.atk);
  if(b.def) parts.push('DEF'+(b.def>0?'+':'')+b.def);
  if(b.spd) parts.push('SPD'+(b.spd>0?'+':'')+b.spd);
  return parts.join(' · ');
}

/* --- 第1階：生活職業選擇 --- */
function renderEvolveProfession(){
  const hero = S.hero;
  const cards = PROFESSIONS.map((p,i)=>`
    <div class="class-card" data-prof="${p.id}">
      <canvas class="sprite" id="prof-${i}" width="64" height="64"></canvas>
      <h3>${esc(p.name)}</h3>
      <p>${esc(p.tag)}</p>
      <div class="small" style="color:var(--gold);margin-top:4px;">${esc(bonusSummary(p.statBonus))}</div>
      <hr class="divider">
      <div class="small"><b style="color:var(--text)">新技能：${esc(p.skill.name)}</b><br>${esc(p.skill.desc)}</div>
    </div>`).join('');
  return `
  <div class="panel">
    <p class="section-title pixel-font" style="font-size:12px;">🌱 生活覺醒 — Lv.${hero.level}</p>
    <p class="event-text">${esc(hero.name)} 已成長到足以選擇人生方向的年紀！請從 4 種生活職業中選擇一個，這將決定你未來能踏上哪些冒險職業之路。</p>
    <div class="grid class-grid">${cards}</div>
  </div>`;
}
function bindEvolveProfession(){
  PROFESSIONS.forEach((p,i)=> queueSprite('prof-'+i, 'prof_'+p.id+'_face', p.palette, 14, {kind:'human'}));
  document.querySelectorAll('[data-prof]').forEach(card=>{
    card.addEventListener('click', ()=>{
      const hero = S.hero;
      setProfession(hero, card.dataset.prof);
      S.log.unshift(esc(hero.name)+' 踏上了 ['+displayClassName(hero)+'] 之路！');
      S.pendingStage = null;
      evaluateEvolution(hero);
      routeHome();
      render();
    });
  });
}

/* --- 第2階：冒險職業選擇（依生活職業篩選2個選項） --- */
function renderEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  if(!prof || !prof.leadsTo){
    setTimeout(()=>{ S.pendingStage=null; S.screen='hub'; render(); }, 0);
    return `<div class="panel"><p class="event-text">職業資料異常，正在返回營地…</p></div>`;
  }
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
  if(!opts.length){
    setTimeout(()=>{ S.pendingStage=null; S.screen='hub'; render(); }, 0);
    return `<div class="panel"><p class="event-text">無可用職業路線，正在返回營地…</p></div>`;
  }
  const cards = opts.map((c,i)=>`
    <div class="class-card" data-cls="${c.id}">
      <canvas class="sprite" id="clschoice-${i}" width="64" height="64"></canvas>
      <h3>${esc(c.name)}</h3>
      <p>${esc(c.tag)}</p>
      <div class="small" style="color:var(--gold);margin-top:4px;">${esc(bonusSummary(c.statBonus))}</div>
      <hr class="divider">
      <div class="small"><b style="color:var(--text)">被動：${esc(c.passive.name)}</b><br>${esc(c.passive.desc)}</div>
      <div class="small" style="margin-top:4px;">技能：${c.skills.map(s=>esc(s.name)).join('、')}</div>
    </div>`).join('');
  return `
  <div class="panel">
    <p class="section-title pixel-font" style="font-size:12px;">⚔️ 職業覺醒 — Lv.${hero.level}</p>
    <p class="event-text">身為 ${esc(prof.name)} 的 ${esc(hero.name)}，已經達到正式踏上冒險職業的等級！請從以下 2 條道路中選擇一個，永久決定你的戰鬥風格與專屬被動能力。</p>
    <div class="grid class-grid">${cards}</div>
  </div>`;
}
function bindEvolveClass(){
  const hero = S.hero;
  const prof = PROFESSIONS.find(p=>p.id===hero.professionId);
  if(!prof || !prof.leadsTo) return;
  const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
  opts.forEach((c,i)=> queueSprite('clschoice-'+i, 'class_'+c.id+'_face', c.palette, 14, {kind:'human'}));
  document.querySelectorAll('[data-cls]').forEach(card=>{
    card.addEventListener('click', ()=>{
      setClass(hero, card.dataset.cls);
      S.log.unshift(esc(hero.name)+' 覺醒為 ['+displayClassName(hero)+']！');
      S.pendingStage = null;
      evaluateEvolution(hero);
      routeHome();
      render();
    });
  });
}

/* --- 第3階：職業分支選擇（3選1） --- */
function renderEvolveBranch(){
  const hero = S.hero;
  const cls = CLASSES.find(c=>c.id===hero.classId);
  if(!cls || !cls.advancements){
    setTimeout(()=>{ S.pendingStage=null; S.screen='hub'; render(); }, 0);
    return `<div class="panel"><p class="event-text">職業資料異常，正在返回營地…</p></div>`;
  }
  const cards = cls.advancements.map((adv,i)=>`
    <div class="class-card" data-adv="${adv.id}">
      <canvas class="sprite" id="adv-${i}" width="64" height="64"></canvas>
      <h3>${esc(adv.name)}</h3>
      <p>${esc(adv.desc)}</p>
      <div class="small" style="color:var(--gold);margin-top:4px;">${esc(bonusSummary(adv.statBonus))}</div>
      <hr class="divider">
      <div class="small"><b style="color:var(--text)">新技能：${esc(adv.skill.name)}</b><br>${esc(adv.skill.desc)}</div>
    </div>`).join('');
  return `
  <div class="panel">
    <p class="section-title pixel-font" style="font-size:12px;">✨ 終極覺醒 — Lv.${hero.level}</p>
    <p class="event-text">${esc(hero.name)} 已達到覺醒等級！請從 ${esc(cls.name)} 的三條道路中選擇一個，永久決定未來的成長方向與新技能。</p>
    <div class="grid class-grid">${cards}</div>
  </div>`;
}
function bindEvolveBranch(){
  const hero = S.hero;
  const cls = CLASSES.find(c=>c.id===hero.classId);
  if(!cls || !cls.advancements) return;
  cls.advancements.forEach((adv,i)=> queueSprite('adv-'+i, 'adv_'+adv.id+'_face', cls.palette, 14, {kind:'human'}));
  document.querySelectorAll('[data-adv]').forEach(card=>{
    card.addEventListener('click', ()=>{
      setAdvancement(hero, card.dataset.adv);
      S.log.unshift(esc(hero.name)+' 覺醒為 ['+displayClassName(hero)+']！習得新技能「'+getSkills(hero)[getSkills(hero).length-1].name+'」。');
      S.pendingStage = null;
      routeHome();
      render();
    });
  });
}

loadGame();
render();
