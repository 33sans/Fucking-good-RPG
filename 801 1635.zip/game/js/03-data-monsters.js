/* ============ 資料：怪物（C 系統） ============ */
const MAX_PLAYER_LEVEL = 120;
const MAX_MONSTER_PARTY = 12;

const MONSTER_TYPES = [
  /* Tier 1 雜兵 */
  {n:'史萊姆',type:'nature',tier:1},{n:'哥布林',type:'beast',tier:1},{n:'野狼',type:'beast',tier:1},
  {n:'巨蝠',type:'shadow',tier:1},{n:'骷髏兵',type:'undead',tier:1},{n:'毒蜘蛛',type:'nature',tier:1},
  {n:'盜賊鼠人',type:'beast',tier:1},{n:'沼地蛙',type:'water',tier:1},{n:'炭火小鬼',type:'fire',tier:1},
  {n:'碎石怪',type:'metal',tier:1},{n:'迷霧幽魂',type:'shadow',tier:1},{n:'鐵銹械',type:'metal',tier:1},
  /* Tier 2 */
  {n:'沼澤鱷',type:'water',tier:2},{n:'火蜥蜴',type:'fire',tier:2},{n:'冰霜狼',type:'ice',tier:2},
  {n:'食屍鬼',type:'undead',tier:2},{n:'暗影刺客',type:'shadow',tier:2},{n:'鐵甲蟲',type:'metal',tier:2},
  {n:'毒囊蠍',type:'nature',tier:2},{n:'血蝠群',type:'blood',tier:2},{n:'符文守衛',type:'metal',tier:2},
  {n:'凍土熊',type:'ice',tier:2},{n:'腐木樹人',type:'nature',tier:2},{n:'鹽沼巫妖雛',type:'undead',tier:2},
  /* Tier 3 */
  {n:'半獸人戰士',type:'blood',tier:3},{n:'幽靈法師',type:'shadow',tier:3},{n:'石像鬼',type:'metal',tier:3},
  {n:'血刃狂戰士',type:'blood',tier:3},{n:'深淵觸手',type:'shadow',tier:3},{n:'冰霜巨魔',type:'ice',tier:3},
  {n:'熔核犬',type:'fire',tier:3},{n:'荊棘騎士',type:'nature',tier:3},{n:'深海祭司',type:'water',tier:3},
  {n:'銅皮魔像',type:'metal',tier:3},{n:'骸骨弓手',type:'undead',tier:3},{n:'影刃雙生',type:'shadow',tier:3},
  /* Tier 4 精英原型 */
  {n:'骸骨法王',type:'undead',tier:4},{n:'熔岩魔像',type:'fire',tier:4},{n:'劇毒女王',type:'nature',tier:4},
  {n:'暗夜領主',type:'shadow',tier:4},{n:'風暴獅鷲',type:'beast',tier:4},{n:'寒晶巨人',type:'ice',tier:4},
  {n:'血潮督軍',type:'blood',tier:4},{n:'遠古石衛',type:'metal',tier:4},{n:'深淵海妖',type:'water',tier:4},
  {n:'灰燼巫妖',type:'undead',tier:4},
  /* Tier 5 Boss（僅 50 等後遭遇） */
  {n:'灰燼龍王',type:'fire',tier:5,boss:true,mech:'inferno'},
  {n:'虛空吞噬者',type:'shadow',tier:5,boss:true,mech:'void'},
  {n:'永眠死神',type:'undead',tier:5,boss:true,mech:'reaper'},
  {n:'潮汐女皇',type:'water',tier:5,boss:true,mech:'tide'},
  {n:'荊棘古樹',type:'nature',tier:5,boss:true,mech:'roots'},
  {n:'鋼鐵巨像',type:'metal',tier:5,boss:true,mech:'colossus'},
  {n:'血月魔王',type:'blood',tier:5,boss:true,mech:'bloodmoon'},
  {n:'永凍君王',type:'ice',tier:5,boss:true,mech:'frost'},
  {n:'瘟疫之主',type:'nature',tier:5,boss:true,mech:'plague'},
  {n:'影殿主宰',type:'shadow',tier:5,boss:true,mech:'shadowcourt'},
  {n:'熔核泰坦',type:'fire',tier:5,boss:true,mech:'titan'},
  {n:'深淵海怪',type:'water',tier:5,boss:true,mech:'kraken'},
  {n:'骸骨帝皇',type:'undead',tier:5,boss:true,mech:'boneking'},
  {n:'狂戰魔神',type:'blood',tier:5,boss:true,mech:'berserk'},
  {n:'星隕看守者',type:'metal',tier:5,boss:true,mech:'starseal'},
  {n:'夢魘織者',type:'shadow',tier:5,boss:true,mech:'nightmare'},
  {n:'聖焰審判官',type:'fire',tier:5,boss:true,mech:'judgment'},
  {n:'腐朽花園主',type:'nature',tier:5,boss:true,mech:'garden'}
];

/* 50 種怪物詞綴（質變為主） */
const MONSTER_AFFIXES = [
  {id:'armored', name:'堅甲', desc:'防禦×1.5', apply:(m)=>{ m.def=Math.round(m.def*1.5); }},
  {id:'bloodrage', name:'血怒', desc:'攻擊×1.5，防禦×0.7', apply:(m)=>{ m.atk=Math.round(m.atk*1.5); m.def=Math.round(m.def*0.7); }},
  {id:'giant', name:'巨體', desc:'生命×1.45', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.45); m.hp=m.maxHp; }},
  {id:'swift', name:'疾速', desc:'速度×1.55', apply:(m)=>{ m.spd=Math.round(m.spd*1.55); }},
  {id:'regenerating', name:'再生', desc:'每回合回 5% 生命', apply:(m)=>{ m.hasRegen=true; m.regenRate=0.05; }},
  {id:'thorns', name:'荊棘', desc:'受擊反傷 20%', apply:(m)=>{ m.thorns=0.20; }},
  {id:'vampiric', name:'吸血', desc:'攻擊回復造成傷害 25%', apply:(m)=>{ m.vampiric=0.25; }},
  {id:'poisonous', name:'劇毒', desc:'攻擊使目標中毒', apply:(m)=>{ m.poisonTouch=true; }},
  {id:'frenzied', name:'狂亂', desc:'生命＜40% 時攻擊×1.6', apply:(m)=>{ m.enrageAt=0.4; m.enrageMult=1.6; }},
  {id:'evasive', name:'飄忽', desc:'25% 閃避物理', apply:(m)=>{ m.evade=0.25; }},
  {id:'stoneSkin', name:'岩膚', desc:'防禦×1.35，速度×0.85', apply:(m)=>{ m.def=Math.round(m.def*1.35); m.spd=Math.round(m.spd*0.85); }},
  {id:'berserk', name:'狂暴', desc:'攻擊×1.4，生命×0.85', apply:(m)=>{ m.atk=Math.round(m.atk*1.4); m.maxHp=Math.round(m.maxHp*0.85); m.hp=m.maxHp; }},
  {id:'shielded', name:'護盾', desc:'前 2 次受傷減半', apply:(m)=>{ m.shieldCharges=2; }},
  {id:'multiStrike', name:'連擊', desc:'35% 機率攻擊兩次', apply:(m)=>{ m.doubleAtk=0.35; }},
  {id:'cleave', name:'橫掃', desc:'攻擊有機會波及全隊', apply:(m)=>{ m.aoeAtk=0.30; }},
  {id:'manaBurn', name:'灼魔', desc:'攻擊額外扣 MP', apply:(m)=>{ m.manaBurn=true; }},
  {id:'chilling', name:'寒凍', desc:'攻擊降低目標速度', apply:(m)=>{ m.chillTouch=true; }},
  {id:'burning', name:'燃燒', desc:'每回合造成持續火傷', apply:(m)=>{ m.auraBurn=0.03; }},
  {id:'fortified', name:'固守', desc:'生命×1.25，防禦×1.25', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.25); m.hp=m.maxHp; m.def=Math.round(m.def*1.25); }},
  {id:'glassCannon', name:'玻璃炮', desc:'攻擊×1.8，生命×0.6', apply:(m)=>{ m.atk=Math.round(m.atk*1.8); m.maxHp=Math.round(m.maxHp*0.6); m.hp=m.maxHp; }},
  {id:'nimble', name:'輕盈', desc:'速度×1.35，閃避+10%', apply:(m)=>{ m.spd=Math.round(m.spd*1.35); m.evade=(m.evade||0)+0.10; }},
  {id:'thickHide', name:'厚皮', desc:'受到物理傷害 −20%', apply:(m)=>{ m.physResist=0.20; }},
  {id:'magicWard', name:'魔抗', desc:'受到魔法傷害 −25%', apply:(m)=>{ m.magResist=0.25; }},
  {id:'undying', name:'不死', desc:'首次瀕死時以 20% 血復活一次', apply:(m)=>{ m.undying=true; }},
  {id:'packLeader', name:'頭領', desc:'經驗與金幣×1.3', apply:(m)=>{ m.exp=Math.round(m.exp*1.3); m.gold=Math.round(m.gold*1.3); }},
  {id:'wealthy', name:'富有', desc:'金幣×1.8', apply:(m)=>{ m.gold=Math.round(m.gold*1.8); }},
  {id:'experienced', name:'老練', desc:'經驗×1.5', apply:(m)=>{ m.exp=Math.round(m.exp*1.5); }},
  {id:'brutal', name:'殘暴', desc:'攻擊×1.3', apply:(m)=>{ m.atk=Math.round(m.atk*1.3); }},
  {id:'ironWill', name:'鐵志', desc:'免疫嘲諷優先（較難被拉）', apply:(m)=>{ m.ignoreTaunt=0.5; }},
  {id:'stunning', name:'震擊', desc:'攻擊 15% 機率讓目標跳過下回合', apply:(m)=>{ m.stunChance=0.15; }},
  {id:'lifeLink', name:'命鏈', desc:'每回合回 3% 生命', apply:(m)=>{ m.hasRegen=true; m.regenRate=0.03; }},
  {id:'barbed', name:'倒刺', desc:'反傷 30%', apply:(m)=>{ m.thorns=0.30; }},
  {id:'shadowstep', name:'影步', desc:'閃避 35%', apply:(m)=>{ m.evade=0.35; }},
  {id:'overgrowth', name:'增生', desc:'生命×1.6，速度×0.8', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.6); m.hp=m.maxHp; m.spd=Math.round(m.spd*0.8); }},
  {id:'sparking', name:'電弧', desc:'攻擊附加魔法傷害', apply:(m)=>{ m.arcBonus=0.25; }},
  {id:'plagued', name:'瘟疫', desc:'攻擊必中毒，毒傷較重', apply:(m)=>{ m.poisonTouch=true; m.poisonHeavy=true; }},
  {id:'colossal', name:'魁梧', desc:'生命×1.7，防禦×1.2', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.7); m.hp=m.maxHp; m.def=Math.round(m.def*1.2); }},
  {id:'ruthless', name:'無情', desc:'對生命＜50% 的目標傷害×1.4', apply:(m)=>{ m.execute=1.4; }},
  {id:'warded', name:'結界', desc:'前 3 次受傷 −40%', apply:(m)=>{ m.shieldCharges=3; m.shieldReduce=0.4; }},
  {id:'haste', name:'加速', desc:'速度×1.7', apply:(m)=>{ m.spd=Math.round(m.spd*1.7); }},
  {id:'savagery', name:'蠻力', desc:'攻擊×1.25，生命×1.15', apply:(m)=>{ m.atk=Math.round(m.atk*1.25); m.maxHp=Math.round(m.maxHp*1.15); m.hp=m.maxHp; }},
  {id:'reflective', name:'反射', desc:'反傷 15% 且魔抗+15%', apply:(m)=>{ m.thorns=0.15; m.magResist=(m.magResist||0)+0.15; }},
  {id:'bloodlust', name:'嗜血', desc:'吸血 40%', apply:(m)=>{ m.vampiric=0.40; }},
  {id:'tenacious', name:'韌性', desc:'生命×1.3，再生 4%', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.3); m.hp=m.maxHp; m.hasRegen=true; m.regenRate=0.04; }},
  {id:'crippling', name:'致殘', desc:'攻擊降低目標攻擊', apply:(m)=>{ m.crippleTouch=true; }},
  {id:'arcane', name:'奧能', desc:'攻擊偏魔法、魔抗高', apply:(m)=>{ m.arcBonus=0.4; m.magResist=(m.magResist||0)+0.2; }},
  {id:'phalanx', name:'方陣', desc:'防禦×1.6，攻擊×0.9', apply:(m)=>{ m.def=Math.round(m.def*1.6); m.atk=Math.round(m.atk*0.9); }},
  {id:'unstable', name:'不穩', desc:'生命×0.75，攻擊×1.55，死亡爆炸', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*0.75); m.hp=m.maxHp; m.atk=Math.round(m.atk*1.55); m.deathBurst=0.15; }},
  {id:'hunterMark', name:'獵物', desc:'受到標記類傷害額外 +15%', apply:(m)=>{ m.markVulnerable=1.15; }},
  {id:'rare', name:'稀有', desc:'全數值 +20%（精英專屬）', apply:(m)=>{ m.atk=Math.round(m.atk*1.2); m.def=Math.round(m.def*1.2); m.maxHp=Math.round(m.maxHp*1.2); m.hp=m.maxHp; m.spd=Math.round(m.spd*1.2); m.exp=Math.round(m.exp*1.2); m.gold=Math.round(m.gold*1.2); }}
];

/** 詞綴數量：30 等起 1 條，之後每 10 等 +1（最高 8）；Boss／精英同樣遵循 */
function rollAffixCount(tier, boss, playerLevel, isElite){
  const rng = Math.random;
  let count = 0;
  // 統一規律：30 等 → 1，40 → 2，50 → 3 … 100 → 8
  if(playerLevel >= 30){
    count = 1 + Math.floor((playerLevel - 30) / 10);
    count = Math.min(count, 8);
  } else if(tier >= 3 && rng() < 0.45){
    count = 1;
  } else if(tier >= 4 && rng() < 0.70){
    count = 1;
  } else if(tier >= 2 && rng() < 0.22){
    count = 1;
  }
  // Boss：同樣走每 10 等 +1；因 50 等才會出現，保底至少等同該等級公式（不再另隨機加）
  if(boss){
    if(playerLevel >= 30){
      count = Math.min(8, 1 + Math.floor((playerLevel - 30) / 10));
    } else {
      count = Math.max(count, 2);
    }
  }
  // 精英：在同一規律上再 +1（仍受最高 8 限制）
  if(isElite) count = Math.min(8, Math.max(count, 1) + 1);
  return Math.min(count, MONSTER_AFFIXES.length - 1); // 預留 rare
}

function applyMonsterAffixes(mon, count, rng, forceRare){
  const pool = MONSTER_AFFIXES.filter(a=>a.id!=='rare');
  const shuffled = pool.slice().sort(()=>rng()-0.5);
  const chosen = shuffled.slice(0, Math.min(count, shuffled.length));
  chosen.forEach(aff=>{
    aff.apply(mon);
    mon.affixes.push(aff.id);
    mon.affixNames = mon.affixNames || [];
    mon.affixNames.push(aff.name);
  });
  if(forceRare){
    const rare = MONSTER_AFFIXES.find(a=>a.id==='rare');
    if(rare){ rare.apply(mon); mon.affixes.push('rare'); mon.affixNames.push('稀有'); }
  }
}

/**
 * 怪物數值總表（與玩家成長對齊）
 * ------------------------------------------------------------
 * 目標手感（同級）：
 *   普通怪：約 4~7 回合，對砍有壓力
 *   精英：約 8~14 回合，需認真打
 *   Boss：耐力戰，失誤會倒，獎勵豐厚
 * 曲線高於裸裝玩家期望，靠裝備／職業／操作拉開差距
 */

const MONSTER_RANKS = {
  normal:   {id:'normal',   prefix:'',     name:'普通', multHp:1,    multAtk:1,    multDef:1,    multRew:1,    extraAffix:0},
  elite:    {id:'elite',    prefix:'精英·', name:'精英', multHp:1.65, multAtk:1.32, multDef:1.20, multRew:1.80, extraAffix:0},
  veteran:  {id:'veteran',  prefix:'百戰·', name:'百戰', multHp:1.95, multAtk:1.45, multDef:1.30, multRew:2.20, extraAffix:1},
  refined:  {id:'refined',  prefix:'千煉·', name:'千煉', multHp:2.35, multAtk:1.60, multDef:1.42, multRew:2.70, extraAffix:2},
  king:     {id:'king',     prefix:'王者·', name:'王者', multHp:2.90, multAtk:1.78, multDef:1.55, multRew:3.40, extraAffix:3},
  emperor:  {id:'emperor',  prefix:'帝王·', name:'帝王', multHp:3.60, multAtk:2.00, multDef:1.70, multRew:4.20, extraAffix:4}
};
const EMPEROR_TRAITS_BY_NAME = {
  '史萊姆': {id:'emp_史萊姆', name:'黏帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.18);m.hp=m.maxHp;m.physResist=Math.min(0.25,(m.physResist||0)+0.08); }},
  '哥布林': {id:'emp_哥布林', name:'狡帝', apply:(m)=>{ m.spd=Math.round(m.spd*1.2);m.atk=Math.round(m.atk*1.08);m.evade=Math.min(0.28,(m.evade||0)+0.08); }},
  '野狼': {id:'emp_野狼', name:'血帝', apply:(m)=>{ m.vampiric=true;m._vampRate=0.70;m.atk=Math.round(m.atk*1.1); }},
  '巨蝠': {id:'emp_巨蝠', name:'夜帝', apply:(m)=>{ m.evade=Math.min(0.32,(m.evade||0)+0.12);m.spd=Math.round(m.spd*1.12); }},
  '骷髏兵': {id:'emp_骷髏兵', name:'骨帝', apply:(m)=>{ m.def=Math.round(m.def*1.25);m.maxHp=Math.round(m.maxHp*1.1);m.hp=m.maxHp; }},
  '毒蜘蛛': {id:'emp_毒蜘蛛', name:'毒帝', apply:(m)=>{ m._poisonOnHit=true;m.atk=Math.round(m.atk*1.08); }},
  '盜賊鼠人': {id:'emp_盜賊鼠人', name:'竊帝', apply:(m)=>{ m.spd=Math.round(m.spd*1.18);m._goldSteal=true; }},
  '沼地蛙': {id:'emp_沼地蛙', name:'沼帝', apply:(m)=>{ m.hasRegen=true;m.regenRate=0.07;m.maxHp=Math.round(m.maxHp*1.12);m.hp=m.maxHp; }},
  '炭火小鬼': {id:'emp_炭火小鬼', name:'燼帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.15);m._burnAura=true; }},
  '碎石怪': {id:'emp_碎石怪', name:'岩帝', apply:(m)=>{ m.def=Math.round(m.def*1.3);m.physResist=Math.min(0.3,(m.physResist||0)+0.1); }},
  '迷霧幽魂': {id:'emp_迷霧幽魂', name:'霧帝', apply:(m)=>{ m.evade=Math.min(0.35,(m.evade||0)+0.15);m.magResist=Math.min(0.25,(m.magResist||0)+0.1); }},
  '鐵銹械': {id:'emp_鐵銹械', name:'銹帝', apply:(m)=>{ m.def=Math.round(m.def*1.22);m._thorns=0.15; }},
  '沼澤鱷': {id:'emp_沼澤鱷', name:'淵鱷帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.2);m.hp=m.maxHp;m.atk=Math.round(m.atk*1.1); }},
  '火蜥蜴': {id:'emp_火蜥蜴', name:'焰蜥帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.14);m._burnAura=true; }},
  '冰霜狼': {id:'emp_冰霜狼', name:'霜狼帝', apply:(m)=>{ m._frostAura=true;m.spd=Math.round(m.spd*1.1);m.atk=Math.round(m.atk*1.08); }},
  '食屍鬼': {id:'emp_食屍鬼', name:'腐帝', apply:(m)=>{ m.vampiric=true;m._vampRate=0.55;m.maxHp=Math.round(m.maxHp*1.12);m.hp=m.maxHp; }},
  '暗影刺客': {id:'emp_暗影刺客', name:'刃帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.2);m.spd=Math.round(m.spd*1.15);m.evade=Math.min(0.3,(m.evade||0)+0.08); }},
  '鐵甲蟲': {id:'emp_鐵甲蟲', name:'甲帝', apply:(m)=>{ m.def=Math.round(m.def*1.35);m.physResist=Math.min(0.28,(m.physResist||0)+0.12); }},
  '毒囊蠍': {id:'emp_毒囊蠍', name:'蠍帝', apply:(m)=>{ m._poisonOnHit=true;m.atk=Math.round(m.atk*1.12); }},
  '血蝠群': {id:'emp_血蝠群', name:'血翼帝', apply:(m)=>{ m.vampiric=true;m._vampRate=0.65;m.spd=Math.round(m.spd*1.1); }},
  '符文守衛': {id:'emp_符文守衛', name:'符帝', apply:(m)=>{ m.magResist=Math.min(0.3,(m.magResist||0)+0.15);m.def=Math.round(m.def*1.15); }},
  '凍土熊': {id:'emp_凍土熊', name:'凍熊帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.22);m.hp=m.maxHp;m._frostAura=true; }},
  '腐木樹人': {id:'emp_腐木樹人', name:'朽帝', apply:(m)=>{ m.hasRegen=true;m.regenRate=0.08;m.def=Math.round(m.def*1.15); }},
  '鹽沼巫妖雛': {id:'emp_鹽沼巫妖雛', name:'沼巫帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.15);m.hp=m.maxHp;m._lifeTap=true; }},
  '半獸人戰士': {id:'emp_半獸人戰士', name:'戰牙帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.18);m.maxHp=Math.round(m.maxHp*1.1);m.hp=m.maxHp; }},
  '幽靈法師': {id:'emp_幽靈法師', name:'靈法帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.16);m.magResist=Math.min(0.28,(m.magResist||0)+0.12); }},
  '石像鬼': {id:'emp_石像鬼', name:'石翼帝', apply:(m)=>{ m.def=Math.round(m.def*1.28);m.spd=Math.round(m.spd*1.08); }},
  '血刃狂戰士': {id:'emp_血刃狂戰士', name:'狂刃帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.22);m.vampiric=true;m._vampRate=0.4; }},
  '深淵觸手': {id:'emp_深淵觸手', name:'觸帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.12);m._rootOnHit=true; }},
  '冰霜巨魔': {id:'emp_冰霜巨魔', name:'霜魔帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.2);m.hp=m.maxHp;m._frostAura=true;m.def=Math.round(m.def*1.1); }},
  '熔核犬': {id:'emp_熔核犬', name:'熔犬帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.18);m.spd=Math.round(m.spd*1.12);m._burnAura=true; }},
  '荊棘騎士': {id:'emp_荊棘騎士', name:'棘騎帝', apply:(m)=>{ m.def=Math.round(m.def*1.2);m._thorns=0.2;m.atk=Math.round(m.atk*1.08); }},
  '深海祭司': {id:'emp_深海祭司', name:'海祭帝', apply:(m)=>{ m.hasRegen=true;m.regenRate=0.09;m.maxHp=Math.round(m.maxHp*1.12);m.hp=m.maxHp; }},
  '銅皮魔像': {id:'emp_銅皮魔像', name:'銅帝', apply:(m)=>{ m.def=Math.round(m.def*1.4);m.physResist=Math.min(0.32,(m.physResist||0)+0.12); }},
  '骸骨弓手': {id:'emp_骸骨弓手', name:'骨弓帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.15);m.spd=Math.round(m.spd*1.1); }},
  '影刃雙生': {id:'emp_影刃雙生', name:'雙影帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.14);m.evade=Math.min(0.3,(m.evade||0)+0.1);m.spd=Math.round(m.spd*1.12); }},
  '骸骨法王': {id:'emp_骸骨法王', name:'骨法帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.18);m.maxHp=Math.round(m.maxHp*1.15);m.hp=m.maxHp;m._lifeTap=true; }},
  '熔岩魔像': {id:'emp_熔岩魔像', name:'熔像帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.15);m.def=Math.round(m.def*1.2);m._burnAura=true; }},
  '劇毒女王': {id:'emp_劇毒女王', name:'毒后帝', apply:(m)=>{ m._poisonOnHit=true;m.atk=Math.round(m.atk*1.16);m.spd=Math.round(m.spd*1.08); }},
  '暗夜領主': {id:'emp_暗夜領主', name:'夜領帝', apply:(m)=>{ m.evade=Math.min(0.33,(m.evade||0)+0.12);m.atk=Math.round(m.atk*1.14); }},
  '風暴獅鷲': {id:'emp_風暴獅鷲', name:'嵐鷲帝', apply:(m)=>{ m.spd=Math.round(m.spd*1.2);m.atk=Math.round(m.atk*1.12); }},
  '寒晶巨人': {id:'emp_寒晶巨人', name:'晶巨帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.25);m.hp=m.maxHp;m.def=Math.round(m.def*1.15);m._frostAura=true; }},
  '血潮督軍': {id:'emp_血潮督軍', name:'血督帝', apply:(m)=>{ m.vampiric=true;m._vampRate=0.7;m.atk=Math.round(m.atk*1.15); }},
  '遠古石衛': {id:'emp_遠古石衛', name:'古衛帝', apply:(m)=>{ m.def=Math.round(m.def*1.38);m.maxHp=Math.round(m.maxHp*1.15);m.hp=m.maxHp; }},
  '深淵海妖': {id:'emp_深淵海妖', name:'海妖帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.14);m.hasRegen=true;m.regenRate=0.07; }},
  '灰燼巫妖': {id:'emp_灰燼巫妖', name:'燼巫帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.16);m.maxHp=Math.round(m.maxHp*1.12);m.hp=m.maxHp;m._burnAura=true; }},
};
const EMPEROR_TRAITS = {
  fire:    {id:'emp_fire',    name:'炎帝', apply:(m)=>{ m.atk=Math.round(m.atk*1.12); m._burnAura=true; }},
  water:   {id:'emp_water',   name:'潮帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.15); m.hp=m.maxHp; m.hasRegen=true; m.regenRate=0.06; }},
  nature:  {id:'emp_nature',  name:'蔓帝', apply:(m)=>{ m.def=Math.round(m.def*1.2); m._poisonOnHit=true; }},
  shadow:  {id:'emp_shadow',  name:'影帝', apply:(m)=>{ m.evade=Math.min(0.35,(m.evade||0)+0.12); m.spd=Math.round(m.spd*1.1); }},
  undead:  {id:'emp_undead',  name:'骸帝', apply:(m)=>{ m.maxHp=Math.round(m.maxHp*1.2); m.hp=m.maxHp; m._lifeTap=true; }},
  beast:   {id:'emp_beast',   name:'血帝', apply:(m)=>{ m.vampiric=true; m._vampRate=0.70; }},
  metal:   {id:'emp_metal',   name:'鋼帝', apply:(m)=>{ m.def=Math.round(m.def*1.35); m.physResist=Math.min(0.35,(m.physResist||0)+0.12); }},
  blood:   {id:'emp_blood',   name:'血帝', apply:(m)=>{ m.vampiric=true; m._vampRate=0.70; m.atk=Math.round(m.atk*1.08); }},
  ice:     {id:'emp_ice',     name:'霜帝', apply:(m)=>{ m._frostAura=true; m.def=Math.round(m.def*1.1); }},
  holy:    {id:'emp_holy',    name:'聖帝', apply:(m)=>{ m.magResist=Math.min(0.3,(m.magResist||0)+0.15); m.maxHp=Math.round(m.maxHp*1.1); m.hp=m.maxHp; }}
};
function getEmperorTrait(mon){
  const base = (mon && (mon.baseName || mon.name)) ? String(mon.baseName || mon.name).replace(/^(精英|百戰|千煉|王者|帝王)·/g,'') : '';
  if(typeof EMPEROR_TRAITS_BY_NAME !== 'undefined' && EMPEROR_TRAITS_BY_NAME[base]) return EMPEROR_TRAITS_BY_NAME[base];
  const ty = (mon && mon.type) || 'beast';
  return (EMPEROR_TRAITS && EMPEROR_TRAITS[ty]) || EMPEROR_TRAITS.beast;
}

function shortMonsterBaseName(n){
  let s = String(n||'怪').replace(/^(精英|百戰|千煉|王者|帝王)·/g,'');
  if(s.length > 6) s = s.slice(0, 5) + '…';
  return s;
}
function formatMonsterName(rank, baseName){
  const r = MONSTER_RANKS[rank] || MONSTER_RANKS.normal;
  return (r.prefix||'') + shortMonsterBaseName(baseName);
}
function rollMonsterRank(avgLevel, rng){
  rng = rng || Math.random;
  const lv = num(avgLevel, 1);
  const w = [
    {id:'normal', w: 52},
    {id:'elite',  w: lv>=8  ? 20 : 10},
    {id:'veteran',w: lv>=14 ? 12 : 0},
    {id:'refined',w: lv>=22 ? 9  : 0},
    {id:'king',   w: lv>=32 ? 4.5: 0},
    {id:'emperor',w: lv>=42 ? 2.2: 0}
  ].filter(x=>x.w>0);
  return weightedChoice(rng, w.map(x=>({item:x.id, w:x.w})));
}

function makeMonster(tmpl, playerLevel, rng, opts){
  opts = opts || {};
  rng = rng || Math.random;
  const tier = clamp(num(tmpl && tmpl.tier, 1), 1, 5);
  const pl = clamp(num(playerLevel, 1), 1, MAX_PLAYER_LEVEL);
  const lvl = clamp(pl + rint(rng, -1, 2), 1, MAX_PLAYER_LEVEL);
  const boss = !!(tmpl && tmpl.boss);
  let rank = opts.rank || (opts.elite ? 'elite' : 'normal');
  if(boss) rank = 'normal';
  if(typeof MONSTER_RANKS === 'undefined' || !MONSTER_RANKS[rank]) rank = 'normal';
  const rankDef = (typeof MONSTER_RANKS !== 'undefined' && MONSTER_RANKS[rank]) ? MONSTER_RANKS[rank] : {multHp:1,multAtk:1,multDef:1,multRew:1,extraAffix:0,prefix:'',name:'普通'};
  const elite = rank === 'elite' || (!!opts.elite && rank==='normal');

  // 階級倍率：同等級也要有壓力，高階更耐打、更疼
  const tierHp = [1, 1, 1.28, 1.62, 2.05, 2.55][tier];
  const tierAtk = [1, 1, 1.22, 1.45, 1.72, 2.05][tier];
  const tierDef = [1, 1, 1.15, 1.32, 1.50, 1.70][tier];
  const tierRew = [1, 1, 1.25, 1.55, 1.90, 2.40][tier];

  let mon = {
    name: (typeof formatMonsterName==='function' ? formatMonsterName(rank, (tmpl && tmpl.n) || '未知生物') : ((elite ? '精英·' : '') + ((tmpl && tmpl.n) || '未知生物'))),
    baseName: (tmpl && tmpl.n) || '未知生物',
    type: (tmpl && tmpl.type) || 'beast',
    tier, boss, elite, rank, rankName: rankDef.name,
    level: lvl,
    hp: 0, maxHp: 0, atk: 0, def: 0, spd: 0,
    exp: 0, gold: 0,
    seed: ((tmpl && tmpl.n) || 'm') + '_' + lvl + '_' + Math.floor(rng()*9999),
    status:null, statusTurns:0, rewarded:false,
    hasRegen:false, regenRate:0.05,
    affixes:[], affixNames:[],
    mech: boss ? ((tmpl && tmpl.mech) || null) : null,
    bossTurns: 0
  };

  // 基礎曲線：刻意高於「裸裝玩家同級期望」，裝備／職業優勢才能壓制
  // 目標：普通 4~7 回合、精英 8~14 回合、Boss 需策略與消耗
  let maxHp = (48 + lvl * 10.5 + lvl * lvl * 0.055) * tierHp;
  let atk   = (14 + lvl * 1.55 + tier * 2.4) * tierAtk;
  let def   = (4.5 + lvl * 0.72 + tier * 1.5) * tierDef;
  let spd   = rint(rng, 6 + tier, 11 + tier * 2);
  let exp   = (30 + lvl * 5.5 + tier * 8) * tierRew;
  let gold  = (18 + lvl * 3.2 + tier * 5) * tierRew * (0.75 + rng() * 0.5);

  if(rank !== 'normal' && !boss){
    maxHp *= rankDef.multHp;
    atk   *= rankDef.multAtk;
    def   *= rankDef.multDef;
    exp   *= rankDef.multRew;
    gold  *= rankDef.multRew * 0.95;
    spd    = Math.round(spd * (1 + (rankDef.extraAffix||0) * 0.03));
  }
  if(boss){
    // Boss：血厚、攻高但不秒殺；靠機制+持續壓力取勝
    maxHp *= 3.20;
    atk   *= 1.38;
    def   *= 1.35;
    exp   *= 4.20;
    gold  *= 3.60;
    spd    = Math.round(spd * 1.08);
  }

  mon.maxHp = Math.max(12, Math.round(maxHp));
  mon.hp = mon.maxHp;
  mon.atk = Math.max(1, Math.round(atk));
  mon.def = Math.max(0, Math.round(def));
  mon.spd = Math.max(1, spd);
  mon.exp = Math.max(1, Math.round(exp));
  mon.gold = Math.max(0, Math.round(gold));

  let wantAffix = rollAffixCount(tier, boss, pl, elite);
  wantAffix += (rankDef.extraAffix || 0);
  applyMonsterAffixes(mon, wantAffix, rng, elite || rank==='veteran');
  if(rank === 'emperor'){
    const trait = typeof getEmperorTrait === 'function' ? getEmperorTrait(mon) : null;
    if(trait){
      trait.apply(mon);
      mon.affixes.push(trait.id);
      mon.affixNames = mon.affixNames || [];
      if(!mon.affixNames.includes(trait.name)) mon.affixNames.unshift(trait.name);
      mon.emperorTrait = trait.name;
    }
  }

  // 數值淨化
  mon.maxHp = Math.max(12, num(mon.maxHp, 12));
  mon.hp = clamp(num(mon.hp, mon.maxHp), 0, mon.maxHp);
  mon.atk = Math.max(1, num(mon.atk, 1));
  mon.def = Math.max(0, num(mon.def, 0));
  mon.spd = Math.max(1, num(mon.spd, 1));
  mon.exp = Math.max(1, num(mon.exp, 1));
  mon.gold = Math.max(0, num(mon.gold, 0));

  // 軟上限放寬：允許詞綴強化，但仍避免無限疊防
  const atkCap = Math.round((18 + lvl * 2.20 + tier * 5) * (elite ? 1.40 : 1) * (boss ? 1.55 : 1));
  const defCap = Math.round((8 + lvl * 1.10 + tier * 3) * (elite ? 1.30 : 1) * (boss ? 1.55 : 1));
  if(mon.atk > atkCap) mon.atk = atkCap;
  if(mon.def > defCap) mon.def = defCap;

  // 血量軟上限（一般怪／精英）；Boss 不套此上限
  if(!boss){
    const hpCap = Math.round((70 + lvl * 18 + lvl * lvl * 0.12) * tierHp * (elite ? 1.85 : 1));
    if(mon.maxHp > hpCap){
      mon.maxHp = hpCap;
      mon.hp = Math.min(mon.hp, mon.maxHp);
    }
  } else {
    // 魔王血量：至少 30000，並隨等級再拉高
    const bossFloor = 30000 + Math.max(0, lvl - 50) * 400;
    const boosted = Math.max(bossFloor, Math.round(num(mon.maxHp, 1) * 6.5));
    mon.maxHp = boosted;
    mon.hp = mon.maxHp;
    mon.baseAtk = num(mon.atk, 1);
    mon.baseDef = num(mon.def, 0);
    mon.baseSpd = num(mon.spd, 1);
  }

  if(boss && mon.mech){
    mon.exp = Math.max(1, Math.round(mon.exp * 1.15));
    mon.gold = Math.max(0, Math.round(mon.gold * 1.15));
  }
  return mon;
}

/** Boss 專屬小怪：弱於 Boss，攻擊會為 Boss 吸血 */

/** 各 Boss（依 mech）的 5 眷屬編成：強化戰力／續戰，彼此不同 */
const BOSS_MINION_ROSTERS = {
  inferno: [
    {id:'ember_whelp', n:'餘燼幼龍', hp:0.11, atk:0.34, def:0.28, spd:1.05, role:'burn_hit', note:'灼燒'},
    {id:'scale_guard', n:'熔鱗護衛', hp:0.16, atk:0.22, def:0.45, spd:0.85, role:'atk_link', note:'傷轉攻'},
    {id:'flame_priest', n:'焰心祭司', hp:0.10, atk:0.20, def:0.25, spd:0.95, role:'breath_charge', note:'強化吐息'},
    {id:'scorch_walker', n:'焦土行者', hp:0.12, atk:0.26, def:0.30, spd:0.90, role:'scorch_field', note:'焦土'},
    {id:'ignite_crows', n:'點火鴉群', hp:0.09, atk:0.36, def:0.20, spd:1.15, role:'focus_burn', note:'點燃'}
  ],
  void: [
    {id:'void_worm', n:'虛蝕蟲', hp:0.10, atk:0.30, def:0.22, spd:1.05, role:'mp_drain', note:'吸魔'},
    {id:'rift_guard', n:'裂隙守衛', hp:0.15, atk:0.22, def:0.42, spd:0.88, role:'boss_guard', note:'護主'},
    {id:'silent_shade', n:'沉默影', hp:0.10, atk:0.28, def:0.24, spd:1.10, role:'skill_jam', note:'干擾技能'},
    {id:'void_mirror', n:'虛空鏡像', hp:0.11, atk:0.27, def:0.26, spd:1.00, role:'echo_void', note:'連汲'},
    {id:'entropy_acolyte', n:'熵增使徒', hp:0.10, atk:0.25, def:0.24, spd:0.98, role:'entropy_aura', note:'空乏光環'}
  ],
  reaper: [
    {id:'funeral_skel', n:'葬儀骷兵', hp:0.16, atk:0.24, def:0.40, spd:0.85, role:'funeral_stack', note:'葬儀'},
    {id:'death_bell', n:'喪鐘', hp:0.10, atk:0.33, def:0.22, spd:1.08, role:'hunt_low', note:'追殘'},
    {id:'ash_guide', n:'灰袍引路人', hp:0.11, atk:0.22, def:0.28, spd:0.95, role:'lowhp_vamp', note:'低血吸血'},
    {id:'martyr_doll', n:'殉葬偶', hp:0.09, atk:0.18, def:0.20, spd:0.90, role:'sacrifice_heal', note:'犧牲回血'},
    {id:'end_crow', n:'終末鴉', hp:0.10, atk:0.30, def:0.22, spd:1.12, role:'on_ko_buff', note:'倒地強化'}
  ],
  tide: [
    {id:'tide_maid', n:'潮汐侍女', hp:0.11, atk:0.22, def:0.28, spd:0.95, role:'tide_echo', note:'回血連攜'},
    {id:'vortex_guard', n:'漩渦盾衛', hp:0.15, atk:0.20, def:0.42, spd:0.85, role:'share_dmg', note:'分攤'},
    {id:'foam_mage', n:'泡沫法師', hp:0.10, atk:0.28, def:0.22, spd:1.00, role:'wet', note:'潮濕'},
    {id:'deep_singer', n:'深海歌者', hp:0.11, atk:0.20, def:0.26, spd:0.92, role:'tide_amp', note:'潮汐增幅'},
    {id:'pearl_box', n:'珍珠匣', hp:0.13, atk:0.18, def:0.38, spd:0.80, role:'pearl_shield', note:'珍珠盾'}
  ],
  roots: [
    {id:'root_worm', n:'根須蠕蟲', hp:0.11, atk:0.30, def:0.26, spd:0.95, role:'extra_root', note:'補控'},
    {id:'spore_sac', n:'孢子囊', hp:0.10, atk:0.20, def:0.22, spd:0.90, role:'death_spore', note:'死爆毒'},
    {id:'parasite_vine', n:'寄生藤', hp:0.10, atk:0.26, def:0.24, spd:1.00, role:'leech_cc', note:'控場吸血'},
    {id:'wood_warden', n:'林衛木人', hp:0.16, atk:0.22, def:0.40, spd:0.82, role:'root_up', note:'控場強化'},
    {id:'pollen_fae', n:'花粉妖', hp:0.09, atk:0.24, def:0.20, spd:1.05, role:'anti_heal', note:'抑治'}
  ],
  colossus: [
    {id:'rivet_bot', n:'鉚釘修復體', hp:0.12, atk:0.18, def:0.35, spd:0.90, role:'repair_shield', note:'修盾'},
    {id:'magnet_guard', n:'磁鎖衛士', hp:0.15, atk:0.26, def:0.40, spd:0.85, role:'taunt', note:'嘲諷'},
    {id:'overload_turret', n:'過載砲台', hp:0.10, atk:0.38, def:0.20, spd:0.95, role:'shield_dps', note:'結界炮'},
    {id:'alloy_tech', n:'合金技師', hp:0.11, atk:0.20, def:0.30, spd:0.92, role:'def_link', note:'轉防'},
    {id:'scrap_storm', n:'碎屑風暴', hp:0.10, atk:0.28, def:0.22, spd:1.00, role:'shield_break_nova', note:'破盾爆'}
  ],
  bloodmoon: [
    {id:'blood_thrall', n:'血僕', hp:0.11, atk:0.32, def:0.24, spd:1.00, role:'bleed_hit', note:'流血'},
    {id:'blood_priest', n:'血契祭司', hp:0.10, atk:0.20, def:0.22, spd:0.95, role:'self_buff_boss', note:'血契'},
    {id:'eclipse_wolf', n:'月蝕狼', hp:0.11, atk:0.36, def:0.20, spd:1.15, role:'bleed_crit', note:'血暴'},
    {id:'clot_shield', n:'凝血盾', hp:0.14, atk:0.18, def:0.40, spd:0.85, role:'bleed_shield', note:'凝血'},
    {id:'blood_mirror', n:'鮮血鏡', hp:0.10, atk:0.24, def:0.28, spd:0.95, role:'reflect_bleed', note:'反血'}
  ],
  frost: [
    {id:'frost_stele', n:'霜碑', hp:0.14, atk:0.16, def:0.38, spd:0.70, role:'spd_aura', note:'減速光環'},
    {id:'ice_archer', n:'冰棘射手', hp:0.10, atk:0.34, def:0.20, spd:1.05, role:'slow_crit', note:'寒暴'},
    {id:'snow_mage', n:'雪葬法師', hp:0.10, atk:0.28, def:0.22, spd:0.95, role:'freeze_chance', note:'冰封'},
    {id:'cold_core', n:'寒核', hp:0.13, atk:0.18, def:0.36, spd:0.80, role:'frost_shield', note:'寒盾'},
    {id:'blizzard_wisp', n:'暴風雪靈', hp:0.09, atk:0.26, def:0.18, spd:1.10, role:'blizzard', note:'暴風雪'}
  ],
  plague: [
    {id:'plague_rat', n:'疫鼠群', hp:0.10, atk:0.30, def:0.20, spd:1.10, role:'poison_hit', note:'上毒'},
    {id:'miasma_sac', n:'瘟氣囊', hp:0.11, atk:0.18, def:0.22, spd:0.90, role:'death_poison', note:'死延毒'},
    {id:'rot_medic', n:'腐醫', hp:0.10, atk:0.22, def:0.24, spd:0.95, role:'anti_heal', note:'抑治'},
    {id:'pustule_guard', n:'膿皰守衛', hp:0.15, atk:0.24, def:0.38, spd:0.85, role:'poison_thorns', note:'反毒'},
    {id:'plague_flag', n:'疫旗手', hp:0.11, atk:0.26, def:0.26, spd:0.98, role:'plague_flag', note:'疫爆'}
  ],
  shadowcourt: [
    {id:'shadow_squire', n:'影侍', hp:0.14, atk:0.22, def:0.36, spd:0.95, role:'boss_guard', note:'替傷'},
    {id:'false_visage', n:'偽相', hp:0.12, atk:0.24, def:0.28, spd:1.00, role:'fake_death', note:'偽死'},
    {id:'dark_assassin', n:'暗契刺客', hp:0.10, atk:0.38, def:0.18, spd:1.18, role:'hunt_healer', note:'斬療'},
    {id:'veil', n:'影帷', hp:0.11, atk:0.20, def:0.26, spd:0.95, role:'miss_aura', note:'命中↓'},
    {id:'court_guard', n:'殿守衛', hp:0.13, atk:0.26, def:0.34, spd:0.90, role:'shadow_scale', note:'殘影'}
  ],
  titan: [
    {id:'cool_valve', n:'冷卻閥', hp:0.12, atk:0.16, def:0.32, spd:0.88, role:'heat_valve', note:'穩熔核'},
    {id:'slag_golem', n:'熔渣巨人', hp:0.16, atk:0.28, def:0.40, spd:0.80, role:'death_magma', note:'熔池'},
    {id:'spark_wright', n:'火花工', hp:0.10, atk:0.30, def:0.22, spd:1.05, role:'heat_charge', note:'充能'},
    {id:'rock_shell', n:'岩殼', hp:0.14, atk:0.18, def:0.42, spd:0.75, role:'anti_crit', note:'抗暴'},
    {id:'geo_vein', n:'地熱脈', hp:0.11, atk:0.24, def:0.26, spd:0.90, role:'geothermal', note:'地熱'}
  ],
  kraken: [
    {id:'tentacle_a', n:'攫奪觸手', hp:0.12, atk:0.30, def:0.28, spd:0.95, role:'root_hit', note:'抓取'},
    {id:'tentacle_b', n:'碎擊觸手', hp:0.12, atk:0.34, def:0.26, spd:0.95, role:'cleave', note:'掃擊'},
    {id:'ink_fiend', n:'墨囊妖', hp:0.10, atk:0.24, def:0.22, spd:1.05, role:'miss_aura', note:'墨盲'},
    {id:'deep_pressure', n:'深壓', hp:0.13, atk:0.20, def:0.30, spd:0.85, role:'pressure', note:'深壓'},
    {id:'shell_crab', n:'寄居鎧', hp:0.15, atk:0.18, def:0.45, spd:0.80, role:'shell', note:'甲殼'}
  ],
  boneking: [
    {id:'bone_shield', n:'骨盾兵', hp:0.16, atk:0.22, def:0.42, spd:0.85, role:'taunt', note:'盾牆'},
    {id:'bone_archer', n:'骨弓手', hp:0.10, atk:0.34, def:0.20, spd:1.08, role:'hunt_healer', note:'射療'},
    {id:'bone_witch', n:'骸巫', hp:0.11, atk:0.24, def:0.24, spd:0.95, role:'mini_rez', note:'再起'},
    {id:'bone_altar', n:'碎骨祭壇', hp:0.14, atk:0.10, def:0.40, spd:0.50, role:'bone_aura', note:'骨祭'},
    {id:'royal_guard', n:'帝皇親衛', hp:0.13, atk:0.28, def:0.36, spd:0.95, role:'bodyguard_low', note:'親衛'}
  ],
  berserk: [
    {id:'war_slave', n:'戰奴', hp:0.11, atk:0.32, def:0.22, spd:1.05, role:'rage_feed', note:'餵狂'},
    {id:'blood_drummer', n:'血鼓手', hp:0.10, atk:0.22, def:0.22, spd:1.10, role:'haste_boss', note:'戰鼓'},
    {id:'guillotine', n:'斷頭台', hp:0.11, atk:0.36, def:0.20, spd:1.00, role:'execute', note:'處刑'},
    {id:'mad_flag', n:'狂旗', hp:0.10, atk:0.24, def:0.24, spd:0.95, role:'mutual_vuln', note:'互傷'},
    {id:'chain_jailer', n:'鎖鏈獄卒', hp:0.14, atk:0.26, def:0.34, spd:0.90, role:'taunt', note:'鎖鏈'}
  ],
  starseal: [
    {id:'star_priest', n:'星印祭司', hp:0.11, atk:0.26, def:0.24, spd:0.98, role:'star_mark', note:'星印'},
    {id:'orbit_mirror', n:'軌道鏡', hp:0.12, atk:0.18, def:0.36, spd:0.90, role:'reflect_magic', note:'反魔'},
    {id:'meteor_caller', n:'隕石招呼使', hp:0.10, atk:0.32, def:0.22, spd:0.95, role:'meteor', note:'隕石'},
    {id:'star_drone', n:'星屑無人機', hp:0.09, atk:0.28, def:0.18, spd:1.15, role:'death_charge', note:'充能'},
    {id:'seal_anchor', n:'封印錨', hp:0.14, atk:0.16, def:0.40, spd:0.70, role:'skill_dampen', note:'封印'}
  ],
  nightmare: [
    {id:'nightmare_horse', n:'夢魘馬', hp:0.11, atk:0.28, def:0.24, spd:1.05, role:'fear', note:'恐懼'},
    {id:'liar_mirror', n:'謊言鏡', hp:0.11, atk:0.22, def:0.28, spd:0.95, role:'threat_heal', note:'誤導'},
    {id:'sleep_demon', n:'睡魔', hp:0.10, atk:0.24, def:0.22, spd:0.95, role:'delay', note:'遲緩'},
    {id:'dream_spider', n:'織夢蛛', hp:0.12, atk:0.20, def:0.34, spd:0.90, role:'dream_cocoon', note:'夢繭'},
    {id:'horror_shade', n:'魘影', hp:0.10, atk:0.30, def:0.22, spd:1.08, role:'echo_hit', note:'魘擊'}
  ],
  judgment: [
    {id:'flame_warden', n:'執法焰衛', hp:0.12, atk:0.32, def:0.28, spd:0.95, role:'sin_hunter', note:'討罪'},
    {id:'penance_bell', n:'懺悔鐘', hp:0.11, atk:0.24, def:0.26, spd:0.90, role:'judgment_bell', note:'懺悔'},
    {id:'sin_scribe', n:'聖焰書記', hp:0.10, atk:0.22, def:0.24, spd:1.00, role:'sin_scribe', note:'記罪'},
    {id:'atonement_altar', n:'贖罪祭壇', hp:0.14, atk:0.12, def:0.38, spd:0.60, role:'sin_altar', note:'祭壇'},
    {id:'radiant_plume', n:'白熾羽', hp:0.10, atk:0.26, def:0.22, spd:1.05, role:'cleanse_boss', note:'淨化'}
  ],
  garden: [
    {id:'rot_flower', n:'腐花', hp:0.10, atk:0.22, def:0.20, spd:0.85, role:'flower', note:'盤根'},
    {id:'briar_weed', n:'荊莠', hp:0.11, atk:0.28, def:0.24, spd:0.95, role:'flower_thorn', note:'護花'},
    {id:'gardener', n:'園丁骸', hp:0.12, atk:0.20, def:0.28, spd:0.90, role:'plant', note:'栽種'},
    {id:'venom_bee', n:'蜜毒蜂', hp:0.09, atk:0.34, def:0.18, spd:1.15, role:'bee', note:'蜂群'},
    {id:'root_tumor', n:'枯根巨瘤', hp:0.17, atk:0.18, def:0.42, spd:0.70, role:'tumor', note:'巨瘤'}
  ]
};

function getBossMinionRoster(boss){
  const mech = (boss && boss.mech) || '';
  if(BOSS_MINION_ROSTERS[mech]) return BOSS_MINION_ROSTERS[mech];
  // fallback: generic 5
  return [
    {id:'g1', n:'護衛', hp:0.14, atk:0.25, def:0.35, spd:0.90, role:'taunt', note:'護衛'},
    {id:'g2', n:'先鋒', hp:0.11, atk:0.32, def:0.24, spd:1.05, role:'burn_hit', note:'先鋒'},
    {id:'g3', n:'咒師', hp:0.10, atk:0.28, def:0.22, spd:0.98, role:'poison_hit', note:'咒師'},
    {id:'g4', n:'祭司', hp:0.11, atk:0.20, def:0.26, spd:0.95, role:'tide_echo', note:'祭司'},
    {id:'g5', n:'刺客', hp:0.09, atk:0.36, def:0.18, spd:1.12, role:'hunt_healer', note:'刺客'}
  ];
}

function makeBossMinion(boss, playerLevel, rng, idx){
  rng = rng || Math.random;
  const pl = clamp(num(playerLevel, boss && boss.level || 1), 1, MAX_PLAYER_LEVEL);
  const roster = getBossMinionRoster(boss) || [];
  const def = roster[num(idx, 0) % Math.max(1, roster.length)] || {id:'g'+(idx||0), n:'眷屬'+(num(idx,0)+1), hp:0.12, atk:0.28, def:0.3, spd:1, role:'taunt', note:'護衛'};
  // 外觀底：同屬性怪；數值階固定「帝王」
  const typePool = MONSTER_TYPES.filter(m=>!m.boss && m.type===(boss && boss.type) && m.tier<=3);
  const anyPool = MONSTER_TYPES.filter(m=>!m.boss && m.tier<=3);
  const tmpl = choice(rng, typePool.length ? typePool : (anyPool.length ? anyPool : MONSTER_TYPES.filter(m=>!m.boss)));
  const baseTmpl = Object.assign({}, tmpl || {n:'小怪',type:'beast',tier:2}, { n: def.n || '眷屬' });
  // 以帝王階生成：詞條數＋數值倍率走帝王
  const mon = makeMonster(baseTmpl, Math.max(1, pl), rng, { rank:'emperor' });
  mon.name = '帝王·' + (def.n || ('眷屬'+(num(idx,0)+1)));
  mon.baseName = def.n || mon.baseName;
  mon.isBossMinion = true;
  mon.minionId = def.id || ('minion_'+idx);
  mon.minionRole = def.role || 'taunt';
  mon.minionNote = def.note || '';
  mon.bossUid = boss ? boss.seed : null;
  mon.bossLink = true;
  mon.bossMech = boss ? boss.mech : null;
  mon.boss = false;
  mon.elite = false;
  mon.mech = null;
  mon.rank = 'emperor';
  mon.rankName = '帝王';
  // 數值：帝王底 × 眷屬角色倍率，並與魔王血量掛鉤（約 12%~22%）
  const rankDef = (typeof MONSTER_RANKS!=='undefined' && MONSTER_RANKS.emperor) ? MONSTER_RANKS.emperor : {multHp:3.6,multAtk:2,multDef:1.7};
  const bHp = Math.max(30000, num(boss && boss.maxHp, 30000));
  const roleHp = num(def.hp, 0.12);
  mon.maxHp = Math.max(2500, Math.round(Math.max(mon.maxHp, bHp * roleHp * 1.35)));
  mon.hp = mon.maxHp;
  mon.atk = Math.max(1, Math.round(Math.max(mon.atk, num(boss&&boss.atk,20) * num(def.atk,0.28) * 1.15)));
  mon.def = Math.max(0, Math.round(Math.max(mon.def, num(boss&&boss.def,8) * num(def.def,0.35) * 1.1)));
  mon.spd = Math.max(1, Math.round(num(mon.spd,8) * num(def.spd,1)));
  mon.exp = Math.max(1, Math.round(num(mon.exp,30) * 1.4));
  mon.gold = Math.max(0, Math.round(num(mon.gold,20) * 1.2));
  // 詞條：保留帝王詞＋隨機詞，並標註眷屬職能
  mon.affixNames = mon.affixNames || [];
  const jobTag = '眷屬·'+(def.note||def.role||'');
  if(!mon.affixNames.includes(jobTag)) mon.affixNames.unshift(jobTag);
  if(mon.emperorTrait && !mon.affixNames.includes(mon.emperorTrait)) mon.affixNames.unshift(mon.emperorTrait);
  mon.seed = 'emp_minion_' + (boss && boss.seed || 'b') + '_' + def.id + '_' + (def.n||idx);
  // 鎖定 Boss 基底屬性，避免光環每回合複利暴衝
  if(boss){
    if(boss.baseAtk == null) boss.baseAtk = num(boss.atk, 1);
    if(boss.baseDef == null) boss.baseDef = num(boss.def, 0);
    if(boss.baseSpd == null) boss.baseSpd = num(boss.spd, 1);
  }
  // 角色特殊起始狀態
  if(def.role==='pearl_shield' || def.role==='frost_shield' || def.role==='shell'){
    mon.shieldCharges = (mon.shieldCharges||0) + 2;
    mon.shieldReduce = 0.35;
  }
  if(def.role==='flower') mon.flower = true;
  return mon;
}


/** 眷屬光環／回合效果（每回合開始掃一次） */
function tickBossMinionAuras(b){
  if(!b || !b.monsters) return;
  if(typeof S === 'undefined' || !S || !Array.isArray(S.party)) return;
  const boss = getBattleBoss(b);
  if(!boss || boss.hp<=0) return;
  if(boss.baseAtk == null) boss.baseAtk = num(boss.atk, 1);
  if(boss.baseDef == null) boss.baseDef = num(boss.def, 0);
  if(boss.baseSpd == null) boss.baseSpd = num(boss.spd, 1);
  const party = S.party.filter(p=>p && p.hp>0);
  if(!party.length) return;
  const minions = b.monsters.filter(m=>m.isBossMinion && m.hp>0);
  let breathCharge = 0, funeral = 0, flowers = 0, entropy = 0, rootUp = 0;
  let pearl = 0, frostShield = 0, shell = 0, bodyguard = 0, tumor = 0;
  minions.forEach(m=>{
    const role = m.minionRole;
    if(role==='breath_charge') breathCharge++;
    if(role==='funeral_stack') funeral++;
    if(role==='flower' || m.flower) flowers++;
    if(role==='entropy_aura') entropy++;
    if(role==='root_up') rootUp++;
    if(role==='pearl_shield') pearl++;
    if(role==='frost_shield') frostShield++;
    if(role==='shell') shell++;
    if(role==='bodyguard_low') bodyguard++;
    if(role==='tumor') tumor++;

    if(role==='scorch_field'){
      party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(p.maxHp * 0.02)), 0, p.maxHp); });
      b.turnLog.unshift(m.name+' 的焦土灼燒了隊伍！');
      boss._scorchActive = true;
    }
    if(role==='spd_aura'){
      party.forEach(p=>{ p.spdDebuff = (p.spdDebuff||0) + 1; });
    }
    if(role==='anti_heal'){
      b._antiHeal = Math.min(0.55, (b._antiHeal||0) + 0.1);
    }
    if(role==='miss_aura'){
      b._missAura = Math.min(0.35, (b._missAura||0) + 0.07);
    }
    if(role==='pressure'){
      party.forEach(p=>{ p._pressure = true; });
      b._pressureAura = true;
    }
    if(role==='geothermal'){
      party.forEach(p=>{
        p.hp = clamp(p.hp - Math.max(1, Math.round(num(boss.atk,20) * 0.12)), 0, p.maxHp);
      });
      b.turnLog.unshift(m.name+' 釋出地熱！');
    }
    if(role==='mutual_vuln'){ b._mutualVuln = true; }
    if(role==='skill_dampen'){
      b._skillDampen = Math.min(0.45, (b._skillDampen||0) + 0.12);
    }
    if(role==='bone_aura'){
      boss.def = Math.round(num(boss.baseDef, boss.def) * (1 + 0.04 * minions.filter(x=>x.minionRole==='bone_aura').length));
    }
    if(role==='repair_shield' && (boss.shieldCharges||0) < 6 && Math.random() < 0.45){
      boss.shieldCharges = (boss.shieldCharges||0) + 1;
      boss.shieldReduce = boss.shieldReduce || 0.35;
      b.turnLog.unshift(m.name+' 修復了 '+boss.name+' 的結界！');
    }
    if(role==='plant'){
      boss.hp = clamp(boss.hp + Math.round(boss.maxHp * 0.015), 0, boss.maxHp);
      if(flowers < 5 && Math.random() < 0.3){
        b.turnLog.unshift(m.name+' 正在栽種腐花……（盤根加深）');
        boss._gardenStacks = (boss._gardenStacks||0) + 1;
      }
    }
    if(role==='tide_amp'){ boss._tideAmp = (boss._tideAmp||0) + 0.04; }
    if(role==='lowhp_vamp' && boss.hp < boss.maxHp * 0.5){ boss._bonusLifesteal = 0.12; }
    if(role==='haste_boss'){
      if(boss.baseSpd == null) boss.baseSpd = num(boss.spd, 1);
      boss.spd = Math.round(num(boss.baseSpd, boss.spd) * 1.08);
    }
    if(role==='rage_feed' && Math.random() < 0.3){
      const cut = Math.max(1, Math.round(boss.maxHp * 0.012));
      boss.hp = clamp(boss.hp - cut, 1, boss.maxHp);
      boss.atk = Math.round(num(boss.baseAtk, boss.atk) * 1.05);
      b.turnLog.unshift(m.name+' 以血餵養，'+boss.name+' 攻擊上升！');
    }
    if(role==='self_buff_boss' && Math.random() < 0.35){
      const cut = Math.max(1, Math.round(m.maxHp * 0.08));
      m.hp = clamp(m.hp - cut, 1, m.maxHp);
      if(boss.baseAtk == null) boss.baseAtk = num(boss.atk, 1);
      boss._bloodPact = (boss._bloodPact||0) + 1;
      boss.atk = Math.round(num(boss.baseAtk, boss.atk) * (1 + 0.03 * Math.min(8, boss._bloodPact)));
      b.turnLog.unshift(m.name+' 締下血契，'+boss.name+' 攻擊提升！');
    }
    if(role==='shadow_scale' && boss.hp < boss.maxHp * 0.4){
      boss.evade = Math.min(0.5, (boss.evade||0) + 0.04);
    }
    if(role==='dream_cocoon' && !boss._cocoon){
      boss._cocoon = 3;
      boss.shieldCharges = Math.max(boss.shieldCharges||0, 2);
      boss.shieldReduce = Math.max(boss.shieldReduce||0, 0.3);
      b.turnLog.unshift(m.name+' 為 '+boss.name+' 織上夢繭！');
    }
    if(role==='heat_valve'){ boss._heatStable = true; }
    if(role==='heat_charge'){
      boss._heat = (boss._heat||0) + 1;
      if(boss._heat >= 5){
        boss._heat = 0;
        party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(boss.atk * 0.45)), 0, p.maxHp); });
        b.turnLog.unshift(m.name+' 填滿熔核！'+boss.name+' 爆發熱浪！');
      }
    }
    if(role==='blizzard' && b.roundNum % 3 === 0){
      party.forEach(p=>{
        p.hp = clamp(p.hp - Math.max(1, Math.round(num(m.atk,10)*0.7)), 0, p.maxHp);
        p.spdDebuff = (p.spdDebuff||0) + 1;
      });
      b.turnLog.unshift(m.name+' 掀起暴風雪！');
    }
    if(role==='meteor' && b.roundNum % 4 === 0){
      const p = choice(Math.random, party);
      const d = Math.max(1, Math.round(num(m.atk,10) * 1.8));
      p.hp = clamp(p.hp - d, 0, p.maxHp);
      b.turnLog.unshift(m.name+' 召來隕石，砸向 '+p.name+'（'+d+'）！');
    }
    if(role==='judgment_bell' && b.roundNum % 3 === 0){
      const p = choice(Math.random, party);
      if(!(p.buffDef > 0)){
        const d = Math.max(1, Math.round(num(boss.atk,20) * 0.85));
        p.hp = clamp(p.hp - d, 0, p.maxHp);
        b.turnLog.unshift(m.name+' 敲響懺悔鐘！'+p.name+' 未防禦，受到 '+d+' 傷害！');
      } else {
        b.turnLog.unshift(m.name+' 敲響懺悔鐘，'+p.name+' 以防禦撐過審判。');
      }
    }
    if(role==='echo_void' && b.roundNum % 4 === 0){
      const p = choice(Math.random, party);
      p.mp = clamp((p.mp||0) - Math.round((p.maxMp||10)*0.12), 0, p.maxMp||0);
      b.turnLog.unshift(m.name+' 鏡映虛空，再抽走 '+p.name+' 的魔力！');
    }
    if(role==='delay' && Math.random() < 0.12){
      const p = choice(Math.random, party);
      p.skipTurn = true;
      b.turnLog.unshift(m.name+' 讓 '+p.name+' 的行動遲緩了一拍！');
    }
    if(role==='taunt'){
      b._hasTauntMinion = true;
    }
    if(role==='shield_dps' && (boss.shieldCharges||0) > 0){
      m.atk = Math.round(num(m.atk,1) * 1.15);
    }
    if(role==='bee' && (flowers + (boss._gardenStacks||0)) > 0){
      m.atk = Math.round(num(m.atk,1) * (1 + 0.06 * Math.min(5, flowers + (boss._gardenStacks||0))));
    }
    if(role==='plague_flag'){
      const poisoned = party.filter(p=>p.status==='poison').length;
      if(poisoned >= 2){
        boss._plagueBurst = true;
      }
    }
    if(role==='bleed_shield'){
      const bleeds = party.reduce((s,p)=>s+(p._bleed||0),0);
      if(bleeds > 0){
        boss.shieldCharges = Math.max(boss.shieldCharges||0, Math.min(3, bleeds));
        boss.shieldReduce = Math.max(boss.shieldReduce||0, 0.25);
      }
    }
    if(role==='sin_altar'){
      b._sinAltar = true;
    }
    if(role==='threat_heal'){
      b._focusHealer = true;
    }
  });
  if(breathCharge > 0) boss._breathBonus = 0.3 * breathCharge;
  if(funeral > 0) boss._funeral = funeral;
  if(rootUp > 0) boss._rootUp = rootUp;
  if(pearl + frostShield + shell > 0 && (boss.shieldCharges||0) < 1){
    boss.shieldCharges = (boss.shieldCharges||0) + 1;
    boss.shieldReduce = Math.max(boss.shieldReduce||0, 0.3);
  }
  if(flowers > 0 || (boss._gardenStacks||0) > 0){
    const g = flowers + Math.min(5, boss._gardenStacks||0);
    boss.hp = clamp(boss.hp + Math.round(boss.maxHp * 0.006 * g), 0, boss.maxHp);
    boss.atk = Math.round(num(boss.baseAtk, boss.atk) * (1 + 0.015 * g));
  }
  if(entropy > 0){
    const mpGone = party.reduce((s,p)=> s + Math.max(0, (p.maxMp||0) - (p.mp||0)), 0);
    boss._entropyBonus = Math.min(0.4, mpGone * 0.0025 * entropy);
  }
  if(bodyguard && boss.hp < boss.maxHp * 0.3){
    if(boss.baseDef == null) boss.baseDef = num(boss.def, 0);
    boss.def = Math.round(num(boss.baseDef, boss.def) * 1.25);
    boss._bodyguard = true;
  } else if(boss._bodyguard && boss.hp >= boss.maxHp * 0.3){
    boss._bodyguard = false;
    if(boss.baseDef != null) boss.def = num(boss.baseDef, boss.def);
  }
  if(tumor){ boss._tumor = true; }
  // 過載砲台：結界在則更疼（上面 shield_dps）；結界破則自傷換爆在攻擊時處理
}

/** 眷屬死亡時觸發 */
function onBossMinionDeath(mon, b){
  if(!mon || !mon.isBossMinion) return;
  const boss = getBattleBoss(b);
  const party = (S && Array.isArray(S.party)) ? S.party.filter(p=>p && p.hp>0) : [];
  const role = mon.minionRole;
  if(mon.minionId==='ember_whelp' && party.length){
    party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(num(mon.atk,10)*0.85)), 0, p.maxHp); });
    b.turnLog.unshift(mon.name+' 爆成餘燼，灼傷全隊！');
  }
  if(role==='death_spore' || role==='death_poison'){
    party.forEach(p=>{ p.status='poison'; p.statusTurns=Math.max(num(p.statusTurns,0), 2); });
    b.turnLog.unshift(mon.name+' 破裂，毒霧擴散！');
  }
  if(role==='sacrifice_heal' && boss && boss.hp>0){
    const heal = Math.round(boss.maxHp * 0.12);
    boss.hp = clamp(boss.hp + heal, 0, boss.maxHp);
    if(boss._funeral) boss.atk = Math.round(num(boss.atk,1) * (1 + 0.03 * boss._funeral));
    b.turnLog.unshift(mon.name+' 殉葬，'+boss.name+' 回復 '+heal+' HP！');
  }
  if(role==='death_magma' && party.length){
    party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(num(mon.atk,10)*0.65)), 0, p.maxHp); });
    b.turnLog.unshift(mon.name+' 化作熔池！');
  }
  if(role==='death_charge' && boss){
    boss._starCharge = (boss._starCharge||0) + 2;
    b.turnLog.unshift(mon.name+' 為 '+boss.name+' 注入星屑充能！');
  }
  if(role==='fake_death' && boss){
    boss.evade = Math.min(0.55, (boss.evade||0) + 0.2);
    b.turnLog.unshift(mon.name+' 消散，'+boss.name+' 隱入影中！');
  }
  if(role==='cleanse_boss' && boss){
    boss.status = null; boss.statusTurns = 0;
    b.turnLog.unshift(mon.name+' 淨化了 '+boss.name+' 的異常！');
  }
  if(role==='shield_break_nova' && party.length){
    party.forEach(p=>{ p.hp = clamp(p.hp - Math.max(1, Math.round(num(mon.atk,10)*0.75)), 0, p.maxHp); });
    b.turnLog.unshift(mon.name+' 引發碎屑風暴！');
  }
  if(role==='mini_rez' && boss && boss.hp>0 && !mon._rezzed){
    if(!boss._minionRezUsed){
      boss._minionRezUsed = true;
      mon.hp = Math.max(1, Math.round(mon.maxHp * 0.35));
      mon._rezzed = true;
      b.turnLog.unshift('骸巫之力讓眷屬再起！');
      return;
    }
  }
  // 骸巫死亡時嘗試復活其他已死眷屬位：用 flag 讓下次 refill 多一隻
  if(mon.minionId==='bone_witch' && boss && !boss._witchRez){
    boss._witchRez = true;
    if(typeof refillBossMinions === 'function'){
      // 不強制滿編，只標記
    }
  }
}

/** 眷屬攻擊命中後的特殊效果 */
function applyMinionOnHit(mon, target, dmg, b){
  if(!mon || !mon.isBossMinion || !target || dmg<=0) return;
  const boss = getBattleBoss(b);
  const role = mon.minionRole;
  if(role==='burn_hit' || role==='focus_burn'){
    target.status = 'poison';
    target.statusTurns = Math.max(num(target.statusTurns,0), 2);
    target._burn = (target._burn||0) + 1;
    if(role==='focus_burn' && (target._burn||0) >= 3){
      target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.4)), 0, target.maxHp);
      target._burn = 0;
      b.turnLog.unshift(mon.name+' 點燃爆發！');
    }
  }
  if(role==='mp_drain'){
    const drain = Math.max(1, Math.round((target.maxMp||10) * 0.1));
    target.mp = clamp((target.mp||0) - drain, 0, target.maxMp||0);
    if((target.mp||0) <= 0){
      target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.25)), 0, target.maxHp);
    }
  }
  if(role==='bleed_hit' || role==='bleed_crit'){
    target._bleed = (target._bleed||0) + 1;
    if(role==='bleed_crit' && (target._bleed||0) >= 2){
      target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.3)), 0, target.maxHp);
    }
  }
  if(role==='poison_hit' || role==='flower_thorn'){
    target.status = 'poison';
    target.statusTurns = Math.max(num(target.statusTurns,0), 3);
  }
  if(role==='wet'){ target._wet = true; target.spdDebuff = (target.spdDebuff||0) + 1; }
  if(role==='star_mark'){ target._starMark = (target._starMark||0) + 1; }
  if(role==='sin_scribe' || role==='sin_hunter'){
    target._sin = (target._sin||0) + 1;
    if(role==='sin_hunter' && (target._sin||0) >= 2){
      target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.2)), 0, target.maxHp);
    }
  }
  if(role==='fear' && Math.random() < 0.22){
    target.skipTurn = true;
    b.turnLog.unshift(mon.name+' 使 '+target.name+' 陷入恐懼！');
  }
  if(role==='freeze_chance' && Math.random() < (0.12 + ((target.spdDebuff||0) > 0 ? 0.1 : 0))){
    target.skipTurn = true;
    b.turnLog.unshift(mon.name+' 冰封了 '+target.name+'！');
  }
  if((role==='extra_root' || role==='root_hit') && Math.random() < (0.16 + 0.05 * num(boss && boss._rootUp, 0))){
    target.skipTurn = true;
    b.turnLog.unshift(mon.name+' 纏住了 '+target.name+'！');
  }
  if(role==='skill_jam' && Math.random() < 0.18){
    target._skillJam = 1;
    b.turnLog.unshift(mon.name+' 干擾了 '+target.name+' 的施法！');
  }
  if(role==='execute' && target.hp < target.maxHp * 0.25){
    target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.55)), 0, target.maxHp);
  }
  if(role==='hunt_low' && target.hp < target.maxHp * 0.4){
    target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.22)), 0, target.maxHp);
  }
  if(role==='hunt_healer'){
    const isHealer = target.classId==='cleric' || target.classId==='paladin' || num(target.matk,0) > num(target.atk,0) * 1.1;
    if(isHealer || (b && b._focusHealer)){
      target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.2)), 0, target.maxHp);
    }
  }
  if(role==='slow_crit' && (target.spdDebuff||0) > 0){
    target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.25)), 0, target.maxHp);
  }
  if(role==='cleave'){
    // 額外掃到另一個存活隊員
    const others = (S && S.party) ? S.party.filter(p=>p.hp>0 && p.uid !== target.uid) : [];
    if(others.length){
      const o = choice(Math.random, others);
      o.hp = clamp(o.hp - Math.max(1, Math.round(dmg * 0.4)), 0, o.maxHp);
    }
  }
  if(role==='echo_hit'){
    target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.35)), 0, target.maxHp);
  }
  if(role==='atk_link' && boss){ boss.atk = Math.round(num(boss.atk,1) * 1.02); }
  if(role==='def_link' && boss){ boss.def = Math.round(num(boss.def,1) + 1); }
  if(role==='leech_cc' && target.skipTurn && boss){
    boss.hp = clamp(boss.hp + Math.max(1, Math.round(dmg * 0.35)), 0, boss.maxHp);
  }
  if(boss && (target._bleed||0) > 0) boss._vsBleed = true;
  if(boss && (target._starMark||0) > 0){
    target.hp = clamp(target.hp - Math.max(1, Math.round(dmg * 0.1 * Math.min(3, target._starMark))), 0, target.maxHp);
  }
  // 過載：無結界時自傷換高傷已在傷害算出前難處理；命中後小幅自傷
  if(role==='shield_dps' && boss && !(boss.shieldCharges > 0)){
    mon.hp = clamp(mon.hp - Math.max(1, Math.round(mon.maxHp * 0.05)), 0, mon.maxHp);
  }
}

/** 玩家打 Boss／眷屬時：護衛、反傷、甲殼等 */
function applyBossMinionDefenseHooks(attacker, mon, dmg, isMagic, b){
  if(!b || !mon || dmg <= 0) return dmg;
  let out = dmg;
  const boss = getBattleBoss(b);
  const guards = b.monsters.filter(m=>m.isBossMinion && m.hp>0 && (m.minionRole==='boss_guard' || m.minionRole==='bodyguard_low'));
  // 打 Boss 時可被影侍／親衛分擔
  if(mon.boss && guards.length){
    const g = guards[0];
    const share = Math.round(out * 0.4);
    if(share > 0){
      g.hp = clamp(g.hp - share, 0, g.maxHp);
      out = Math.max(1, out - share);
      b.turnLog.unshift(g.name+' 替 '+mon.name+' 擋下 '+share+' 點傷害！');
      if(g.hp <= 0 && !g.rewarded) checkKillReward(g, b);
    }
  }
  // 互傷旗
  if(b._mutualVuln){ out = Math.round(out * 1.1); }
  // 抗暴：簡化為對玩家高傷砍一點（近似）
  if(mon.boss && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='anti_crit') && out > mon.maxHp * 0.12){
    out = Math.round(out * 0.85);
  }
  // 膿皰反毒
  if(mon.isBossMinion && mon.minionRole==='poison_thorns' && attacker){
    attacker.status = 'poison';
    attacker.statusTurns = Math.max(num(attacker.statusTurns,0), 2);
  }
  // 荊莠：打花相關
  if(mon.isBossMinion && (mon.minionRole==='flower' || mon.flower) && attacker){
    attacker.status = 'poison';
    attacker.statusTurns = Math.max(num(attacker.statusTurns,0), 2);
  }
  // 反魔
  if(mon.boss && isMagic && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='reflect_magic')){
    const ref = Math.max(1, Math.round(out * 0.15));
    if(attacker) attacker.hp = clamp(attacker.hp - ref, 0, attacker.maxHp);
    b.turnLog.unshift('軌道鏡反射了 '+ref+' 點魔法傷害！');
  }
  // 鮮血鏡：打 Boss 反流血
  if(mon.boss && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='reflect_bleed') && attacker){
    attacker._bleed = (attacker._bleed||0) + 1;
  }
  // 分攤：漩渦盾衛
  if(mon.boss){
    const sharers = b.monsters.filter(m=>m.isBossMinion && m.hp>0 && m.minionRole==='share_dmg');
    if(sharers.length){
      const each = Math.round(out * 0.2 / sharers.length);
      sharers.forEach(s=>{
        s.hp = clamp(s.hp - each, 0, s.maxHp);
        if(s.hp <= 0) checkKillReward(s, b);
      });
      out = Math.max(1, out - each * sharers.length);
    }
  }
  // 巨瘤：保護花，減傷
  if(mon.isBossMinion && (mon.flower || mon.minionRole==='flower') && b.monsters.some(m=>m.isBossMinion && m.hp>0 && m.minionRole==='tumor')){
    out = Math.round(out * 0.7);
  }
  // 技能壓制
  if(isMagic && b._skillDampen){ out = Math.round(out * (1 - b._skillDampen)); }
  return Math.max(1, out);
}

function getBattleBoss(b){
  if(!b || !b.monsters) return null;
  return b.monsters.find(m=>m.boss && m.hp>0) || b.monsters.find(m=>m.boss) || null;
}

/** 補滿 Boss 眷屬至目標數量（僅 Boss 仍存活時） */
function refillBossMinions(b, force){
  if(!b || b.over) return;
  const boss = getBattleBoss(b);
  if(!boss || boss.hp<=0) return;
  const targetCount = b.bossMinionCount || 2;
  const aliveMinions = b.monsters.filter(m=>m.isBossMinion && m.hp>0);
  const need = targetCount - aliveMinions.length;
  if(need <= 0 && !force) return;
  // 移除已死眷屬欄位，再補新的
  b.monsters = b.monsters.filter(m=> !(m.isBossMinion && m.hp<=0));
  const stillAlive = b.monsters.filter(m=>m.isBossMinion && m.hp>0).length;
  const toAdd = Math.max(0, targetCount - stillAlive);
  if(toAdd <= 0) return;
  const rng = Math.random;
  const pl = avgPartyLevel();
  const roster = getBossMinionRoster(boss);
  const aliveIds = new Set(b.monsters.filter(m=>m.isBossMinion && m.hp>0).map(m=>m.minionId));
  let addIdx = 0;
  for(let i=0;i<roster.length && addIdx<toAdd;i++){
    if(aliveIds.has(roster[i].id)) continue;
    b.monsters.push(makeBossMinion(boss, pl, rng, i));
    aliveIds.add(roster[i].id);
    addIdx++;
  }
  while(addIdx < toAdd){
    b.monsters.push(makeBossMinion(boss, pl, rng, addIdx));
    addIdx++;
  }
  // 補完後重建回合順序，讓新眷屬盡快插入行動
  if(typeof buildTurnOrder==='function'){
    const prevRef = b.order && b.order[b.turnIndex] ? b.order[b.turnIndex].ref : null;
    b.order = buildTurnOrder(b.monsters);
    if(prevRef){
      const idx = b.order.findIndex(c=>c.ref===prevRef);
      if(idx>=0) b.turnIndex = idx;
    }
  }
  b.turnLog.unshift('⚠ '+boss.name+' 召喚眷屬補滿戰場！（'+toAdd+' 隻）');
}


