
/* ============ 工具 / PRNG ============ */
function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashStr(str){
  let h = 0x811c9dc5;
  for(let i=0;i<str.length;i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function rint(rng,min,max){
  const a = Number(min), b = Number(max);
  if(!Number.isFinite(a) || !Number.isFinite(b)) return 0;
  return Math.floor(rng()*(b-a+1))+a;
}
/** 把值轉成有限數字，失敗則回 fallback（防 NaN 污染） */
function num(v, fallback){
  const n = Number(v);
  return Number.isFinite(n) ? n : (fallback != null ? fallback : 0);
}
function choice(rng, arr){ return arr[Math.floor(rng()*arr.length)]; }
function weightedChoice(rng, entries){ // entries: [{item,w}]
  const total = entries.reduce((s,e)=>s+e.w,0);
  let r = rng()*total;
  for(const e of entries){ if(r < e.w) return e.item; r -= e.w; }
  return entries[entries.length-1].item;
}
function clamp(v,a,b){
  const x = num(v, a), lo = num(a, 0), hi = num(b, lo);
  return Math.max(lo, Math.min(hi, x));
}
function esc(s){ return (s+'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }

