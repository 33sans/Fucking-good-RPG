/* ============ 資料：隨機事件 ============ */
const EVENTS = [
  {id:'well', title:'神秘的許願井', text:'你在林間發現一口佈滿符文的古井，井水泛著微光。',
    choices:[
      {label:'投入金幣許願',act:(s)=>{ if(s.hero.gold>=15){ s.hero.gold-=15; if(Math.random()<0.6){ const heal=Math.round(s.hero.maxHp*0.4); healParty(s,heal); return '井水湧出溫暖的光，隊伍恢復了 '+heal+' 點HP。'; } else { return '井水泛起漣漪，卻什麼都沒發生……或許只是傳說。'; } } return '你的金幣不夠支付許願的代價。'; }},
      {label:'直接飲用井水',act:(s)=>{ if(Math.random()<0.5){ const heal=Math.round(s.hero.maxHp*0.25); s.hero.hp=clamp(s.hero.hp+heal,0,s.hero.maxHp); return '井水清涼甘甜，你恢復了 '+heal+' 點HP。'; } else { const dmg=Math.round(s.hero.maxHp*0.15); s.hero.hp=clamp(s.hero.hp-dmg,1,s.hero.maxHp); return '井水竟是詛咒之泉！你損失了 '+dmg+' 點HP。'; } }},
      {label:'離開',act:()=> '你選擇不理會這口古井，繼續趕路。'}
    ]},
  {id:'trap', title:'隱藏的陷阱', text:'地面突然塌陷，一張佈滿尖刺的陷阱網彈起！',
    choices:[
      {label:'向後翻滾閃避',act:(s)=>{ if(Math.random()<0.55){ return '你身手矯健地避開了陷阱，毫髮無傷。'; } else { const dmg=rint(Math.random,8,20); return dealTrapDamage(s,dmg); } }},
      {label:'硬扛過去',act:(s)=>{ const dmg=rint(Math.random,15,28); return dealTrapDamage(s,dmg); }}
    ]},
  {id:'chest', title:'廢棄的寶箱', text:'你發現一個佈滿灰塵的寶箱，鎖已經鏽蝕。',
    choices:[
      {label:'開啟寶箱',act:(s)=>{ const rng=Math.random; if(rng()<0.15){ const dmg=rint(Math.random,5,15); s.hero.hp=clamp(s.hero.hp-dmg,1,s.hero.maxHp); return '寶箱是陷阱！你中了毒針，損失 '+dmg+' HP。'; } const gold=rint(Math.random,20,60); s.hero.gold+=gold; let msg='寶箱裡有 '+gold+' 金幣。'; if(rng()<0.4){ const item=rollEquip(Math.random,null,avgPartyLevel(s)); if(addToInventory(item)) msg+=' 還發現了一件裝備：'+item.name+'！'; else msg+=' 寶箱裡有件唯一裝備，但你已擁有。'; } return msg; }},
      {label:'謹慎離開',act:()=>'你懷疑這是個陷阱，決定不冒險。'}
    ]},
  {id:'merchant', title:'流浪商人', text:'一位神秘商人推著小車，車上擺滿了奇怪的物品。',
    choices:[
      {label:'花30金購買HP藥水',act:(s)=>{ if(s.hero.gold>=30){ s.hero.gold-=30; const existing=s.inventory.find(i=>i.slot==='potion'&&i.kind==='hp'&&i.value===60); if(existing) existing.count=(existing.count||1)+1; else s.inventory.push({uid:'pot_'+Math.floor(Math.random()*1e9),slot:'potion',kind:'hp',name:'治療藥水',value:60,count:1}); return '你買到了一瓶治療藥水。'; } return '你的金幣不夠。'; }},
      {label:'花25金購買MP藥水',act:(s)=>{ if(s.hero.gold>=25){ s.hero.gold-=25; const existing=s.inventory.find(i=>i.slot==='potion'&&i.kind==='mp'&&i.value===40); if(existing) existing.count=(existing.count||1)+1; else s.inventory.push({uid:'pot_'+Math.floor(Math.random()*1e9),slot:'potion',kind:'mp',name:'魔力藥水',value:40,count:1}); return '你買到了一瓶魔力藥水。'; } return '你的金幣不夠。'; }},
      {label:'花50金購買神秘裝備',act:(s)=>{ if(s.hero.gold>=50){ const item=rollEquip(Math.random,'rare',avgPartyLevel(s)); if(addToInventory(item)){ s.hero.gold-=50; return '商人賣給你一件 '+item.name+'！'; } return '商人拿出唯一裝備，但你已擁有同款，沒有成交。'; } return '你的金幣不夠。'; }},
      {label:'不買，離開',act:()=>'商人聳聳肩，推車離去。'}
    ]},
  {id:'shrine', title:'古老的祝福神龕', text:'一座斑駁的神龕靜靜矗立，散發著淡淡的聖光。',
    choices:[
      {label:'獻上祈禱',act:(s)=>{ const heal=Math.round(s.hero.maxHp*0.3); healParty(s,heal); return '神龕的光芒籠罩隊伍，全體恢復 '+heal+' 點HP。'; }},
      {label:'略過',act:()=>'你雙手合十致意，繼續前行。'}
    ]},
  {id:'wanderer', title:'受傷的流浪者', text:'路邊倒著一位衣衫襤褸的旅人，看起來身懷絕技。',
    choices:[
      {label:'上前搭救',act:(s)=>{ if(s.party.length>=4){ return '旅人感激地道謝，但你的隊伍已經滿員，無法收留他。'; } const npc=makeRandomAlly(); s.party.push(npc); return npc.name+'（'+displayClassName(npc)+'）加入了你的隊伍！'; }},
      {label:'保持警惕，離開',act:()=>'你決定不冒險，悄悄繞道離開。'}
    ]},
  {id:'storm', title:'突如其來的沙塵暴', text:'狂風夾雜著沙石襲來，能見度瞬間降到極低。',
    choices:[
      {label:'尋找掩護',act:(s)=>{ if(Math.random()<0.6){ return '你們及時躲入岩縫，安然無恙。'; } const gold=Math.min(s.hero.gold, rint(Math.random,5,20)); s.hero.gold-=gold; return '風暴中你的行囊被吹散了一些，損失 '+gold+' 金幣。'; }}
    ]},
  {id:'campfire', title:'廢棄的營地', text:'一個尚有餘溫的營地，旁邊散落著補給品。',
    choices:[
      {label:'搜索補給',act:(s)=>{ const gold=rint(Math.random,10,35); s.hero.gold+=gold; return '你找到了 '+gold+' 金幣的補給品。'; }},
      {label:'原地休息',act:(s)=>{ const heal=Math.round(s.hero.maxHp*0.2); healParty(s,heal); return '短暫的休息讓隊伍恢復了 '+heal+' 點HP。'; }}
    ]},
  {id:'crossroad', title:'岔路口', text:'前方出現三條岔路，各自通往未知的方向。',
    choices:[
      {label:'走左邊小徑',act:(s)=>{
        if(Math.random()<0.5) return '小徑平淡無奇，你順利通過。';
        const gold=rint(Math.random,5,15); s.hero.gold+=gold;
        return '你在小徑上撿到了一些散落的金幣（+'+gold+'）。';
      }},
      {label:'走中間大路',act:(s)=>{ const dmg=rint(Math.random,0,10); if(dmg>0){ s.hero.hp=clamp(s.hero.hp-dmg,1,s.hero.maxHp); return '大路上遭遇小規模落石，損失 '+dmg+' HP。'; } return '大路暢通無阻。'; }},
      {label:'走右邊密林',act:(s)=>{ const item=rollEquip(Math.random,null,avgPartyLevel(s)); if(addToInventory(item)) return '密林深處你發現了一件裝備：'+item.name+'。'; return '密林深處似乎有什麼，但你已擁有那件唯一之物。'; }}
    ]},
  {id:'fairy', title:'森林精靈的祝福', text:'一隻微小的光之精靈繞著你飛舞，似乎想幫助你。',
    choices:[
      {label:'接受祝福',act:(s)=>{
        s.party.forEach(m=>{ m.hp=m.maxHp; m.mp=m.maxMp; });
        return '精靈的祝福讓全隊HP與MP完全恢復！';
      }}
    ]}
];
function dealTrapDamage(s,dmg){ s.hero.hp=clamp(s.hero.hp-dmg,1,s.hero.maxHp); return '陷阱造成了 '+dmg+' 點傷害！'; }
/** 對存活隊友治療；倒地可選復活（回復量＝治療量×reviveRatio，預設 0.25） */
function applyHealToMember(m, amt, opts){
  opts = opts || {};
  amt = Math.max(0, num(amt, 0));
  if(!m) return {healed:0, revived:false};
  if(m.hp > 0){
    const before = m.hp;
    m.hp = clamp(m.hp + amt, 0, m.maxHp);
    return {healed: m.hp - before, revived:false};
  }
  // 倒地
  if(!opts.canRevive) return {healed:0, revived:false};
  const ratio = opts.reviveRatio != null ? opts.reviveRatio : 0.25;
  const reviveHp = Math.max(1, Math.round(amt * ratio));
  m.hp = clamp(reviveHp, 1, m.maxHp);
  return {healed: m.hp, revived:true};
}
function healParty(s, amt, opts){
  opts = opts || {};
  (s.party||[]).forEach(m=> applyHealToMember(m, amt, opts));
}
// 全隊滿血滿魔（含倒地隊友，用於休息／特殊事件）
function restorePartyFull(s){ s.party.forEach(m=>{ m.hp=m.maxHp; m.mp=m.maxMp; }); }

/* ============ NPC 隊友池 ============ */
const NPC_NAMES = [
  '艾莉絲','凱因','露娜','托爾加','薇拉','布蘭登','希兒','葛瑞姆',
  '喬治','史丹利','喬','羅傑','惡魔貓','比利','西薩','熊信寬','Toyz','謝欣達',
  'jay chou','陳美蘭','BR','謝金燕','山豬','蝦味先','蛋頭','禁藥王','陳老師','潮州土狗',
  'godone','majin','栗子','玉麟','天峰','葉玫瑰','王希銘','迪拉胖','YOUND LEE','潤少',
  'gummy B','趙翊帆','春艷','李權哲','YB','有錢人','前人','不公們','沒人能殺死的鬼','費玉清',
  '阿兄喬治','小卡比','QUANZO','O.DKIZZYA','REX','macdella','eyeballray','SheATH','yappy','drew',
  '呂士軒','ANBA','林聖夫','約翰','rgry','吳卓源','Barry chen','熱狗','大隻','小人','陳星翰',
  'KITCAT','朱軒羊','公園','凡尼師男孩','馬英九','蔡英文','消防隊的楊先生','水哥DJDIDILONG',
  'DIE4REALLL','NGKE配菜','KAPPERKIRA','LOKI LU','芋比','JIMMY','玫','33','厚片女孩','女拳主義者',
  '死肥胖哥','修斗','林萌','駱楓','林俊傑','6YI7'
];
function makeRandomAlly(){
  const name = choice(Math.random, NPC_NAMES);
  const m = buildMember(name, 1);
  m.isNpc = true;
  if(typeof guessGenderFromName==='function') m.gender = guessGenderFromName(name);
  return m;
}

/* ============ 角色成員建構 / 升級 / 職業成長 ============ */
/** 從裝備加總某一屬性（affixes 為準；無則回退舊欄位） */
function equipBonus(m, stat){
  let v = 0;
  if(!m || !m.equip) return 0;
  const slots = EQUIP_SLOT_IDS;
  slots.forEach(slot=>{
    const eq = m.equip[slot];
    if(!eq) return;
    // 讀取時再保險正規化一次，避免舊資料沒詞綴
    if(!eq.affixes || !eq.affixes.length) normalizeItem(eq);
    if(eq.affixes && eq.affixes.length){
      eq.affixes.forEach(a=>{
        if(a && a.stat===stat) v += num(a.value, 0);
      });
    } else {
      if(eq.stat===stat) v += num(eq.value, 0);
      if(eq.extraStat===stat) v += num(eq.extraValue, 0);
    }
  });
  return v;
}

/**
 * 主屬性加成公式（明確可見）
 * 力量 STR → 物理攻擊
 * 體質 CON → 生命上限、少量防禦
 * 敏捷 AGI → 速度
 * 智力 INT → 魔力上限、魔法攻擊
 */
const ATTR_FORMULA = {
  strToAtk: 1.2,
  conToHp: 5,
  conToDef: 0.4,
  agiToSpd: 1.1,
  intToMp: 3,
  intToMatk: 1.4
};

function computeStats(m){
  const lv = clamp(num(m.level, 1), 1, MAX_PLAYER_LEVEL);
  if(!Number.isFinite(Number(m.level)) || Number(m.level) < 1) m.level = lv;
  // 基礎戰鬥屬性（職業層）
  let maxHp = COMMONER.base.hp + COMMONER.grow.hp*(lv-1);
  let maxMp = COMMONER.base.mp + COMMONER.grow.mp*(lv-1);
  let atk = COMMONER.base.atk + COMMONER.grow.atk*(lv-1);
  let def = COMMONER.base.def + COMMONER.grow.def*(lv-1);
  let spd = COMMONER.base.spd + COMMONER.grow.spd*(lv-1);
  let matk = 5 + lv * 0.6; // 基礎魔攻

  // 主屬性基礎：每人都有，隨等級成長
  let str = 5 + Math.floor((lv-1)*0.4);
  let con = 5 + Math.floor((lv-1)*0.4);
  let agi = 5 + Math.floor((lv-1)*0.4);
  let intel = 5 + Math.floor((lv-1)*0.4); // int 是保留字，用 intel

  const layers = [];
  if(m.professionId){
    const p = PROFESSIONS.find(x=>x.id===m.professionId);
    if(p) layers.push({def:p, atLevel:m.professionLevel||lv});
  }
  if(m.classId){
    const c = CLASSES.find(x=>x.id===m.classId);
    if(c) layers.push({def:c, atLevel:m.classLevel||lv});
    if(c && m.advId){
      const a = c.advancements.find(x=>x.id===m.advId);
      if(a) layers.push({def:a, atLevel:m.advLevel||lv});
    }
  }
  layers.forEach(({def:d, atLevel})=>{
    if(!d || !d.statBonus || !d.growBonus) return;
    const since = Math.max(0, lv-atLevel);
    maxHp += d.statBonus.hp + d.growBonus.hp*since;
    maxMp += d.statBonus.mp + d.growBonus.mp*since;
    atk += d.statBonus.atk + d.growBonus.atk*since;
    def += d.statBonus.def + d.growBonus.def*since;
    spd += d.statBonus.spd + d.growBonus.spd*since;
    // 依職業偏向主屬性
    if(d.statBonus.atk > d.statBonus.mp) str += Math.floor((d.statBonus.atk + d.growBonus.atk*since)*0.3);
    if(d.statBonus.hp > 10) con += Math.floor((d.statBonus.hp + d.growBonus.hp*since)*0.08);
    if(d.statBonus.spd > 0) agi += Math.floor((d.statBonus.spd + d.growBonus.spd*since)*0.4);
    if(d.statBonus.mp > 5) intel += Math.floor((d.statBonus.mp + d.growBonus.mp*since)*0.15);
  });

  // 裝備主屬性
  str += equipBonus(m, 'str');
  con += equipBonus(m, 'con');
  agi += equipBonus(m, 'agi');
  intel += equipBonus(m, 'int');

  // 主屬性 → 戰鬥屬性
  atk += str * ATTR_FORMULA.strToAtk;
  maxHp += con * ATTR_FORMULA.conToHp;
  def += con * ATTR_FORMULA.conToDef;
  spd += agi * ATTR_FORMULA.agiToSpd;
  maxMp += intel * ATTR_FORMULA.intToMp;
  matk += intel * ATTR_FORMULA.intToMatk;

  // 裝備直接戰鬥屬性
  maxHp += equipBonus(m, 'hp');
  maxMp += equipBonus(m, 'mp');
  atk += equipBonus(m, 'atk');
  matk += equipBonus(m, 'matk');
  def += equipBonus(m, 'def');
  spd += equipBonus(m, 'spd');

  return {
    maxHp:Math.max(1,Math.round(maxHp)), maxMp:Math.max(0,Math.round(maxMp)),
    atk:Math.max(1,Math.round(atk)), matk:Math.max(1,Math.round(matk)),
    def:Math.max(0,Math.round(def)), spd:Math.max(1,Math.round(spd)),
    str:Math.max(1,Math.round(str)), con:Math.max(1,Math.round(con)),
    agi:Math.max(1,Math.round(agi)), int:Math.max(1,Math.round(intel))
  };
}
function applyComputedStats(m){
  const s = computeStats(m);
  let maxHp = s.maxHp;
  // 唯一／共鳴：最大生命% 寫入實際 maxHp（避免只在 statTotal 顯示）
  if(typeof sumEquipSpecial === 'function'){
    const hpB = sumEquipSpecial(m, 'hpBonus');
    if(hpB > 0) maxHp = Math.max(1, Math.round(maxHp * (1 + hpB)));
  }
  const dHp = maxHp - num(m.maxHp, 0);
  const dMp = s.maxMp - num(m.maxMp, 0);
  m.maxHp=maxHp; m.maxMp=s.maxMp;
  m.atk=s.atk; m.matk=s.matk; m.def=s.def; m.spd=s.spd;
  m.str=s.str; m.con=s.con; m.agi=s.agi; m.int=s.int;
  m.hp = clamp(num(m.hp, 0)+dHp, 0, m.maxHp);
  m.mp = clamp(num(m.mp, 0)+dMp, 0, m.maxMp);
}
function setProfession(m, professionId){
  m.professionId = professionId;
  m.professionLevel = m.level;
  applyComputedStats(m);
}
function setClass(m, classId){
  m.classId = classId;
  m.classLevel = m.level;
  applyComputedStats(m);
}
function setAdvancement(m, advId){
  m.advId = advId;
  m.advLevel = m.level;
  applyComputedStats(m);
}
function classPassive(m){
  if(!m.classId) return null;
  const cls = CLASSES.find(c=>c.id===m.classId);
  return (cls && cls.passive) || null;
}
function hasPassive(m, id){
  const p = classPassive(m);
  return !!(p && p.id===id);
}
function displayClassName(m){
  if(m.advId && m.classId){
    const cls = CLASSES.find(c=>c.id===m.classId);
    const adv = cls && cls.advancements ? cls.advancements.find(a=>a.id===m.advId) : null;
    if(adv) return adv.name;
  }
  if(m.classId){
    const cls = CLASSES.find(c=>c.id===m.classId);
    if(cls) return cls.name;
  }
  if(m.professionId){
    const prof = PROFESSIONS.find(p=>p.id===m.professionId);
    if(prof) return prof.name;
  }
  return COMMONER.name;
}
function getSkills(m){
  let skills = COMMONER.skills.slice();
  if(m.professionId){
    const prof = PROFESSIONS.find(p=>p.id===m.professionId);
    if(prof && prof.skill) skills.push(prof.skill);
  }
  if(m.classId){
    const cls = CLASSES.find(c=>c.id===m.classId);
    if(cls && cls.skills) skills = skills.concat(cls.skills);
    if(cls && m.advId){
      const adv = cls.advancements.find(a=>a.id===m.advId);
      if(adv && adv.skill) skills.push(adv.skill);
    }
  }
  // 已裝備唯一：附加專屬技能
  if(typeof equippedUniqueSkills === 'function'){
    skills = skills.concat(equippedUniqueSkills(m));
  }
  return skills;
}
function buildMember(name, level){
  // gender 由名字推斷（頭像用）

  const m = {
    uid:'m_'+Math.floor(Math.random()*1e9),
    name,
    professionId:null, professionLevel:null,
    classId:null, classLevel:null,
    advId:null, advLevel:null,
    level: level||1, exp:0, nextExp: expForLevel(level||1),
    maxHp:0, hp:0, maxMp:0, mp:0,
    atk:0, matk:0, def:0, spd:0,
    str:0, con:0, agi:0, int:0,
    equip:emptyEquip(),
    buffDef:0, buffTurns:0, guarding:false, taunting:false,
    usedGuardianAngel:false
  };
  applyComputedStats(m);
  m.hp = m.maxHp; m.mp = m.maxMp;
  return m;
}
function memberPalette(m){
  if(m.classId){
    const cls = CLASSES.find(c=>c.id===m.classId);
    if(cls) return cls.palette;
  }
  if(m.professionId){
    const prof = PROFESSIONS.find(p=>p.id===m.professionId);
    if(prof) return prof.palette;
  }
  return COMMONER.palette;
}
function expForLevel(lv){
  lv = clamp(lv, 1, MAX_PLAYER_LEVEL);
  return Math.round(30 * Math.pow(lv, 1.5) * (1 + lv * 0.008));
}
function statTotal(m, stat){
  // 裝備與主屬性已計入 m.*，此處加戰鬥 buff + 唯一%加成
  let v;
  if(stat==='hp') v = m.maxHp;
  else if(stat==='mp') v = m.maxMp;
  else if(stat==='matk') v = m.matk || m.atk || 1;
  else if(stat==='atk') v = (m.atk||0) - num(m.atkDebuff, 0);
  else if(stat==='spd') v = (m.spd||0) - num(m.spdDebuff, 0);
  else v = m[stat];
  if(stat==='def' && m.buffTurns>0) v = num(v,0) + num(m.buffDef,0);
  v = num(v, 0);
  if(typeof sumEquipSpecial === 'function'){
    if(stat==='atk') v *= (1 + sumEquipSpecial(m, 'atkBonus'));
    if(stat==='matk') v *= (1 + sumEquipSpecial(m, 'matkBonus'));
    if(stat==='spd') v *= (1 + sumEquipSpecial(m, 'spdBonus'));
    // hpBonus 已在 applyComputedStats 寫入 maxHp，此處不再乘
  }
  return Math.max(0, Math.round(v));
}
function evaluateEvolution(m){
  if(m.level>=PROFESSION_LEVEL && !m.professionId){ S.pendingStage='profession'; return; }
  if(m.level>=CLASS_LEVEL && m.professionId && !m.classId){ S.pendingStage='class'; return; }
  if(m.level>=BRANCH_LEVEL && m.classId && !m.advId){ S.pendingStage='branch'; return; }
}
function autoEvolveAll(m, log){
  if(m.level>=PROFESSION_LEVEL && !m.professionId){
    const prof = choice(Math.random, PROFESSIONS);
    setProfession(m, prof.id);
    log.push(m.name+' 踏上了 ['+prof.name+'] 之路！');
  }
  if(m.level>=CLASS_LEVEL && m.professionId && !m.classId){
    const prof = PROFESSIONS.find(p=>p.id===m.professionId);
    if(prof && prof.leadsTo){
      const opts = CLASSES.filter(c=>prof.leadsTo.includes(c.id));
      if(opts.length){
        const cls = choice(Math.random, opts);
        setClass(m, cls.id);
        log.push(m.name+' 覺醒為 ['+cls.name+']！');
      }
    }
  }
  if(m.level>=BRANCH_LEVEL && m.classId && !m.advId){
    const cls = CLASSES.find(c=>c.id===m.classId);
    if(cls && cls.advancements && cls.advancements.length){
      const adv = choice(Math.random, cls.advancements);
      setAdvancement(m, adv.id);
      log.push(m.name+' 進一步覺醒為 ['+adv.name+']！');
    }
  }
}
function gainExp(m, amt, log){
  if(!m) return;
  log = log || [];
  amt = Math.max(0, Math.round(num(amt, 0)));
  if(amt <= 0) return;
  if(m.level >= MAX_PLAYER_LEVEL){
    m.exp = 0;
    m.nextExp = expForLevel(MAX_PLAYER_LEVEL);
    return;
  }
  m.exp = num(m.exp, 0) + amt;
  while(m.exp >= m.nextExp && m.level < MAX_PLAYER_LEVEL){
    m.exp -= m.nextExp;
    m.level++;
    applyComputedStats(m);
    m.nextExp = expForLevel(m.level);
    log.push(m.name+' 升到了 Lv.'+m.level+'！');
    if(m.isHero){
      evaluateEvolution(m);
    } else {
      autoEvolveAll(m, log);
    }
  }
  if(m.level >= MAX_PLAYER_LEVEL){
    m.level = MAX_PLAYER_LEVEL;
    m.exp = 0;
    m.nextExp = expForLevel(MAX_PLAYER_LEVEL);
    log.push(m.name+' 已達等級上限 '+MAX_PLAYER_LEVEL+'！');
  }
}


