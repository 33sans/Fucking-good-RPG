/* ============ 渲染 ============ */
let uiTab = 'inv';
/* ============ 存檔系統（localStorage） ============ */
const SAVE_KEY = 'ashfall_era_save_v1';
const SAVE_VERSION = 2;
function saveGame(manual){
  if(!S) return false;
  try{
    S.saveVersion = SAVE_VERSION;
    S.savedAt = Date.now();
    // 戰鬥／事件中不寫入（避免 ref／函式問題）；手動存檔除外且僅在安全畫面
    const payload = JSON.stringify(S);
    localStorage.setItem(SAVE_KEY, payload);
    if(manual && S.log) S.log.unshift('💾 進度已手動存檔。');
    return true;
  }catch(e){
    if(manual && S.log) S.log.unshift('存檔失敗：儲存空間不足或瀏覽器限制。');
    return false;
  }
}
function exportSave(){
  if(!S) return;
  try{
    S.saveVersion = SAVE_VERSION;
    S.savedAt = Date.now();
    const blob = new Blob([JSON.stringify(S, null, 2)], {type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'ashfall_save_'+new Date().toISOString().slice(0,10)+'.json';
    a.click();
    URL.revokeObjectURL(a.href);
    if(S.log) S.log.unshift('📤 存檔已匯出為檔案。');
  }catch(e){
    alert('匯出失敗');
  }
}
function importSaveFromText(text){
  try{
    const data = JSON.parse(text);
    if(!data || !data.party || !data.party.length) throw new Error('格式錯誤');
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    if(loadGame()){
      if(S.screen==='battle' || S.screen==='event'){
        S.battle = null; S.event = null; S.screen = 'hub';
      }
      if(S.log) S.log.unshift('📥 存檔已匯入。');
      saveGame(); // 寫回正規化後狀態
      render();
      return true;
    }
    throw new Error('讀取失敗');
  }catch(e){
    alert('匯入失敗：'+ (e.message||'未知錯誤'));
    return false;
  }
}
function formatSavedAt(ts){
  if(!ts) return '尚無';
  try{
    const d = new Date(ts);
    return d.toLocaleString('zh-TW', {month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
  }catch(e){ return '—'; }
}
function loadGame(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw) return false;
    S = JSON.parse(raw);
    if(!S || !S.party || !S.party.length){ S=null; return false; }
    // 致命修復：JSON.parse 後 S.hero 與 party[] 變成兩個獨立物件
    // 戰鬥升等改 party，花金幣改 S.hero → 必須合併後綁回同一參考
    const parsedHero = S.hero;
    let hero = S.party.find(m=>m.isHero)
      || (parsedHero && S.party.find(m=>m.uid===parsedHero.uid))
      || S.party[0];
    if(parsedHero && hero){
      if(typeof parsedHero.gold === 'number') hero.gold = parsedHero.gold;
      if(parsedHero.professionId && !hero.professionId){
        hero.professionId = parsedHero.professionId;
        hero.professionLevel = parsedHero.professionLevel;
      }
      if(parsedHero.classId && !hero.classId){
        hero.classId = parsedHero.classId;
        hero.classLevel = parsedHero.classLevel;
      }
      if(parsedHero.advId && !hero.advId){
        hero.advId = parsedHero.advId;
        hero.advLevel = parsedHero.advLevel;
      }
      if((parsedHero.level||0) > (hero.level||0)){
        hero.level = parsedHero.level;
        hero.exp = parsedHero.exp;
        hero.nextExp = parsedHero.nextExp;
        hero.maxHp = parsedHero.maxHp; hero.hp = parsedHero.hp;
        hero.maxMp = parsedHero.maxMp; hero.mp = parsedHero.mp;
        hero.atk = parsedHero.atk; hero.def = parsedHero.def; hero.spd = parsedHero.spd;
        if(parsedHero.equip) hero.equip = parsedHero.equip;
      }
    }
    hero.isHero = true;
    if(typeof hero.gold !== 'number') hero.gold = 0;
    S.hero = hero;
    const idx = S.party.findIndex(m=>m.uid===hero.uid);
    if(idx>=0) S.party[idx] = hero; else S.party.unshift(hero);
    if(!S.inventory) S.inventory = [];
    if(!Array.isArray(S.warehouse)) S.warehouse = [];
    if(!S.log) S.log = [];
    if(S.pendingStage==null) S.pendingStage = null;
    // 合併舊存檔散落藥水 + 正規化裝備 + 重算屬性
    stackExistingPotions();
    S.inventory.forEach(normalizeItem);
    S.warehouse.forEach(normalizeItem);
    // 舊存檔若背包裝備超過上限 → 溢出進倉庫
    ensureWarehouse();
    const gear = S.inventory.filter(i=>i.slot!=='potion');
    const pots = S.inventory.filter(i=>i.slot==='potion');
    if(gear.length > BACKPACK_CAP){
      const keep = gear.slice(0, BACKPACK_CAP);
      const overflow = gear.slice(BACKPACK_CAP);
      overflow.forEach(it=>{
        if(S.warehouse.length < WAREHOUSE_CAP) S.warehouse.push(it);
        else {
          const g = Math.max(1, Math.floor(equipPrice(it)*0.35));
          S.hero.gold = (S.hero.gold||0)+g;
        }
      });
      S.inventory = keep.concat(pots);
      S.log.unshift('讀檔整理：多餘裝備已移入倉庫（背包上限 '+BACKPACK_CAP+' 格）。');
    }

    S.party.forEach(m=>{
      ensureMemberEquip(m);
      Object.keys(m.equip).forEach(k=>{ if(m.equip[k]) normalizeItem(m.equip[k]); });
      applyComputedStats(m);
    });
    // 戰鬥／事件畫面讀檔不安全 → 強制回營地
    if(S.screen==='battle' || S.screen==='event' || !S.screen){
      S.battle = null;
      S.event = null;
      S.screen = 'hub';
    }
    // 淨化隊伍數值，避免舊存檔 level/hp 異常導致戰鬥 NaN
    S.party.forEach(m=>{
      m.level = Math.max(1, Number.isFinite(Number(m.level)) ? Math.floor(Number(m.level)) : 1);
      if(typeof applyComputedStats === 'function') applyComputedStats(m);
      m.maxHp = Math.max(1, Number(m.maxHp)||1);
      m.hp = Math.max(0, Math.min(Number(m.hp)||0, m.maxHp));
      m.maxMp = Math.max(0, Number(m.maxMp)||0);
      m.mp = Math.max(0, Math.min(Number(m.mp)||0, m.maxMp));
      m.atk = Math.max(1, Number(m.atk)||1);
      m.def = Math.max(0, Number(m.def)||0);
      m.spd = Math.max(1, Number(m.spd)||1);
      if(m.matk != null) m.matk = Math.max(1, Number(m.matk)||1);
    });
    evaluateEvolution(S.hero);
    if(S.pendingStage==='profession') S.screen='evolve-profession';
    else if(S.pendingStage==='class') S.screen='evolve-class';
    else if(S.pendingStage==='branch') S.screen='evolve-branch';
    return true;
  }catch(e){ S=null; return false; }
}
function hasSaveGame(){
  try{ return !!localStorage.getItem(SAVE_KEY); }catch(e){ return false; }
}
function deleteSaveGame(){
  try{ localStorage.removeItem(SAVE_KEY); }catch(e){ /* 忽略 */ }
}
function restartGame(){
  if(!confirm('確定要放棄目前的進度，重新開始一輪新的冒險嗎？此動作無法復原。')) return;
  deleteSaveGame();
  S = null;
  render();
}

/** 倉庫頁：沿用背包 UI 的倉庫篩選 */
function renderWarehouse(){
  if(S) S.invFilter = 'warehouse';
  return renderInventory();
}
function bindWarehouse(){
  bindInventory();
}

function render(){
  const root = document.getElementById('screens');
  if(!root) return;
  if(!S){ root.innerHTML = renderCharCreate(); bindCharCreate(); return; }
  if(S.screen==='hub') { root.innerHTML = renderHub(); bindHub(); }
  else if(S.screen==='battle') { root.innerHTML = renderBattle(); bindBattle(); }
  else if(S.screen==='event') { root.innerHTML = renderEvent(); bindEvent(); }
  else if(S.screen==='inventory') { root.innerHTML = renderInventory(); bindInventory(); }
  else if(S.screen==='warehouse') { root.innerHTML = renderWarehouse(); bindWarehouse(); }
  else if(S.screen==='shop') { root.innerHTML = renderShop(); bindShop(); }
  else if(S.screen==='tavern') { root.innerHTML = renderTavern(); bindTavern(); }
  else if(S.screen==='party') { root.innerHTML = renderParty(); bindParty(); }
  else if(S.screen==='evolve-profession') { root.innerHTML = renderEvolveProfession(); bindEvolveProfession(); }
  else if(S.screen==='evolve-class') { root.innerHTML = renderEvolveClass(); bindEvolveClass(); }
  else if(S.screen==='evolve-branch') { root.innerHTML = renderEvolveBranch(); bindEvolveBranch(); }
  requestAnimationFrame(paintSprites);
  // 存檔安全範圍：除了「戰鬥中」(battle.order[].ref 需要維持物件參照一致性)
  // 跟「事件選擇中」(event.choices[].act 是函式，無法被JSON序列化)以外，
  // 其他畫面（包含職業覺醒畫面）都是安全的存檔時機。
  if(S.screen!=='battle' && S.screen!=='event') saveGame();
}
let pendingSprites = [];
function queueSprite(id, seed, palette, size, opts){
  pendingSprites.push({id, seed, palette, size, opts: opts||{}});
}
function queueEquipIcon(id, seed, kind, color){ pendingSprites.push({id,seed,kind,color,equip:true}); }
function paintSprites(){
  pendingSprites.forEach(p=>{
    const c = document.getElementById(p.id);
    if(!c) return;
    if(p.equip) drawEquipIcon(c, p.seed, p.kind, p.color);
    else drawSprite(c, p.seed, p.palette, p.size||14, p.opts||{});
  });
  pendingSprites = [];
}

function renderCharCreate(){
  return `
  <div class="panel" style="text-align:center;">
    <canvas class="sprite" id="cc-commoner" width="72" height="72" style="margin:0 auto;display:block;"></canvas>
    <p class="section-title" style="margin-top:10px;">你是一介平凡的普通人</p>
    <p class="event-text">尚未踏上冒險之路，也還沒有任何專精。<br>
    隨著旅途的歷練，Lv.${PROFESSION_LEVEL} 時可以選擇一項<b style="color:var(--gold)">生活職業</b>（4選1），<br>
    Lv.${CLASS_LEVEL} 時將正式覺醒為<b style="color:var(--gold)">冒險職業</b>（該職業路線的2選1），<br>
    Lv.${BRANCH_LEVEL} 時再進行最終的<b style="color:var(--gold)">職業分支</b>（3選1）。<br>
    每一步的選擇都將深刻影響你的成長方向。</p>
    <button class="btn gold" id="start-btn" style="margin-top:10px;">踏上旅程</button>
    ${hasSaveGame()?`<button class="btn" id="continue-btn" style="margin-top:8px;">繼續冒險（讀取存檔）</button>
    <button class="btn" id="import-save-btn-title" style="margin-top:6px;">📥 匯入存檔檔案</button>
    <input type="file" id="import-save-file-title" accept="application/json,.json" style="display:none"/>`:''}
  </div>`;
}
function bindCharCreate(){
  queueSprite('cc-commoner', 'commoner_preview', COMMONER.palette, 14, {kind:'human'});
  document.getElementById('start-btn').addEventListener('click', ()=> newGame());
  const cont = document.getElementById('continue-btn');
  if(cont) cont.addEventListener('click', ()=>{
    if(loadGame()) render();
    else alert('讀檔失敗');
  });
  const impBtn = document.getElementById('import-save-btn-title');
  const impFile = document.getElementById('import-save-file-title');
  if(impBtn && impFile){
    impBtn.addEventListener('click', ()=> impFile.click());
    impFile.addEventListener('change', ()=>{
      const f = impFile.files && impFile.files[0];
      if(!f) return;
      const reader = new FileReader();
      reader.onload = ()=> importSaveFromText(String(reader.result||''));
      reader.readAsText(f);
      impFile.value = '';
    });
  }
}

function memberCardHtml(m, idx, opts){
  opts=opts||{};
  const hpPct = Math.max(0, Math.min(100, Math.round(num(m.hp,0)/Math.max(1,num(m.maxHp,1))*100)));
  const mpPct = m.maxMp? Math.max(0, Math.min(100, Math.round(num(m.mp,0)/Math.max(1,num(m.maxMp,1))*100))):0;
  const expPct = Math.max(0, Math.min(100, Math.round(num(m.exp,0)/Math.max(1,num(m.nextExp,1))*100)));
  const spriteId = (opts.prefix||'pc')+'-'+idx;
  if(opts.compact){
    return `
    <div class="member-card member-card-compact ${m.hp<=0?'dead':''} ${opts.activeClass||''}" data-uid="${m.uid}" data-pidx="${opts.pidx!=null?opts.pidx:idx}">
      <canvas class="sprite" id="${spriteId}" width="32" height="32"></canvas>
      <div class="member-info">
        <div class="member-name"><span>${esc(m.name)}${m.isHero?'★':''} <span class="small">Lv.${m.level}</span></span><span class="small">${esc(displayClassName(m))}</span></div>
        <div class="bar-wrap"><div class="bar" style="width:${hpPct}%;background:var(--hp)"></div></div>
        <div class="compact-stats"><span>HP ${m.hp}/${m.maxHp}</span>${m.maxMp? `<span>MP ${m.mp}/${m.maxMp}</span>`:''}</div>
        ${m.maxMp? `<div class="bar-wrap bar-wrap-mp"><div class="bar" style="width:${mpPct}%;background:var(--mp)"></div></div>`:''}
      </div>
    </div>`;
  }
  return `
  <div class="member-card ${m.hp<=0?'dead':''} ${opts.activeClass||''}" data-uid="${m.uid}" data-pidx="${opts.pidx!=null?opts.pidx:idx}">
    <canvas class="sprite" id="${spriteId}" width="48" height="48"></canvas>
    <div class="member-info">
      <div class="member-name"><span>${esc(m.name)}${m.isHero?' (你)':''} Lv.${m.level}</span><span class="small">${esc(displayClassName(m))}</span></div>
      <div class="bar-wrap"><div class="bar" style="width:${hpPct}%;background:var(--hp)"></div></div>
      <div class="small">HP ${m.hp}/${m.maxHp}</div>
      ${m.maxMp? `<div class="bar-wrap"><div class="bar" style="width:${mpPct}%;background:var(--mp)"></div></div><div class="small">MP ${m.mp}/${m.maxMp}</div>`:''}
      ${opts.showExp? `<div class="bar-wrap"><div class="bar" style="width:${expPct}%;background:var(--xp)"></div></div><div class="small">EXP ${m.exp}/${m.nextExp}</div>`:''}
    </div>
  </div>`;
}

function restCostHP(){ return 70 * Math.pow(2, S.party.length-1); }
function restCostMP(){ return 55 * Math.pow(2, S.party.length-1); }
function restHP(){
  const cost = restCostHP();
  if(S.hero.gold < cost){
    S.log.unshift('金幣不足，需要 '+cost+' 金幣才能讓全隊HP恢復（目前隊伍 '+S.party.length+' 人）。');
    render();
    return;
  }
  S.hero.gold -= cost;
  S.party.forEach(m=>{ m.hp=m.maxHp; });
  S.log.unshift('花費 '+cost+' 金幣，讓全隊HP完全恢復！');
  render();
}
function restMP(){
  const cost = restCostMP();
  if(S.hero.gold < cost){
    S.log.unshift('金幣不足，需要 '+cost+' 金幣才能讓全隊MP恢復（目前隊伍 '+S.party.length+' 人）。');
    render();
    return;
  }
  S.hero.gold -= cost;
  S.party.forEach(m=>{ m.mp=m.maxMp; });
  S.log.unshift('花費 '+cost+' 金幣，讓全隊MP完全恢復！');
  render();
}
function renderHub(){
  const hero=S.hero;
  const partyHtml = S.party.map((m,i)=>memberCardHtml(m,i,{prefix:'hub', showExp:true})).join('');
  const recentLog = S.log.slice(0,5).map(l=>`<div>${esc(l)}</div>`).join('') || '<div class="small">尚無紀錄……</div>';
  const costHP = restCostHP();
  const costMP = restCostMP();
  const canAffordHP = hero.gold >= costHP;
  const canAffordMP = hero.gold >= costMP;
  return `
  <div class="panel">
    <div class="topbar">
      <span class="pixel-font" style="font-size:11px;color:var(--gold);">💰 ${hero.gold} 金幣</span>
      <span class="small">已探索 ${S.daysSurvived} 次</span>
    </div>
    <div class="grid party-grid">${partyHtml}</div>
    <hr class="divider">
    <button class="btn gold btn-primary" id="explore-btn">🧭 前往探索</button>
    <div class="nav-grid nav-grid-4">
      <button class="btn btn-nav" id="inv-btn"><span class="nav-icon">🎒</span>背包</button>
      <button class="btn btn-nav" id="ware-btn"><span class="nav-icon">📦</span>倉庫</button>
      <button class="btn btn-nav" id="shop-btn"><span class="nav-icon">🏪</span>商店</button>
      <button class="btn btn-nav" id="tavern-btn"><span class="nav-icon">🍺</span>酒館</button>
    </div>
    <div class="utility-row" style="margin-top:10px;">
      <button class="btn btn-compact" id="party-btn">👥 隊伍</button>
      <button class="btn btn-compact ${canAffordHP?'gold':'danger'}" id="rest-hp-btn" ${canAffordHP?'':'disabled'}>💗 回HP（${costHP}）</button>
      <button class="btn btn-compact ${canAffordMP?'gold':'danger'}" id="rest-mp-btn" ${canAffordMP?'':'disabled'}>💧 回MP（${costMP}）</button>
    </div>
  </div>
  <div class="panel">
    <p class="section-title">冒險紀錄</p>
    <div class="log-box">${recentLog}</div>
    <hr class="divider">
    <div class="inv-bonus-line" style="text-align:center;margin:6px 0 4px;">存檔 · 上次：<b>${formatSavedAt(S.savedAt)}</b></div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-bottom:4px;">
      <button class="btn" id="manual-save-btn">💾 手動存檔</button>
      <button class="btn" id="export-save-btn">📤 匯出</button>
      <button class="btn" id="import-save-btn">📥 匯入</button>
    </div>
    <input type="file" id="import-save-file" accept="application/json,.json" style="display:none"/>
    <div style="text-align:center;"><button class="flee-link" id="restart-game-btn">🗑️ 放棄進度，重新開始</button></div>
  </div>`;
}
function bindHub(){
  S.party.forEach((m,i)=> queueSprite('hub-'+i, (m.name||'hero')+'_'+m.uid, memberPalette(m), 14, {kind:'human'}));
  document.getElementById('explore-btn').addEventListener('click', explore);
  document.getElementById('inv-btn').addEventListener('click', ()=>{ S.screen='inventory'; render(); });
  const wareBtn = document.getElementById('ware-btn');
  if(wareBtn) wareBtn.addEventListener('click', ()=>{ S.screen='warehouse'; render(); });
  document.getElementById('shop-btn').addEventListener('click', ()=>{ S.screen='shop'; render(); });
  document.getElementById('tavern-btn').addEventListener('click', ()=>{ S.screen='tavern'; render(); });
  const partyBtn = document.getElementById('party-btn');
  if(partyBtn) partyBtn.addEventListener('click', ()=>{ S.screen='party'; render(); });
  const restHpBtn = document.getElementById('rest-hp-btn');
  if(restHpBtn) restHpBtn.addEventListener('click', restHP);
  const restMpBtn = document.getElementById('rest-mp-btn');
  if(restMpBtn) restMpBtn.addEventListener('click', restMP);
  const restartBtn = document.getElementById('restart-game-btn');
  if(restartBtn) restartBtn.addEventListener('click', restartGame);
  const manSave = document.getElementById('manual-save-btn');
  if(manSave) manSave.addEventListener('click', ()=>{ saveGame(true); render(); });
  const expBtn = document.getElementById('export-save-btn');
  if(expBtn) expBtn.addEventListener('click', ()=>{ exportSave(); render(); });
  const impBtn = document.getElementById('import-save-btn');
  const impFile = document.getElementById('import-save-file');
  if(impBtn && impFile){
    impBtn.addEventListener('click', ()=> impFile.click());
    impFile.addEventListener('change', ()=>{
      const f = impFile.files && impFile.files[0];
      if(!f) return;
      const reader = new FileReader();
      reader.onload = ()=> importSaveFromText(String(reader.result||''));
      reader.readAsText(f);
      impFile.value = '';
    });
  }
}

function renderEvent(){
  const ev=S.event;
  const choices = ev.choices.map((c,i)=>`<button class="btn" data-i="${i}">${esc(c.label)}</button>`).join('');
  return `
  <div class="panel">
    <p class="section-title">${esc(ev.title)}</p>
    <p class="event-text">${esc(ev.text)}</p>
    <div class="choice-list">${choices}</div>
  </div>`;
}
function bindEvent(){
  document.querySelectorAll('[data-i]').forEach(btn=>{
    btn.addEventListener('click', ()=> resolveEvent(parseInt(btn.dataset.i)));
  });
}


function formatMonsterAffixDisplay(m){
  const names = (m.affixNames && m.affixNames.length)
    ? m.affixNames.slice()
    : ((m.affixes||[]).map(id=>{ const a=(typeof MONSTER_AFFIXES!=='undefined')&&MONSTER_AFFIXES.find(x=>x.id===id); return a?a.name:id; }));
  const emp = m.emperorTrait || null;
  const rest = names.filter(n=>n && n!==emp);
  const visible = [];
  if(emp) visible.push(emp);
  const take = emp ? 1 : 2;
  const others = rest.slice(0, take);
  others.forEach(n=> visible.push(n));
  const hidden = Math.max(0, rest.length - others.length);
  const line = visible.join(' · ') + (hidden>0 ? ' · +'+hidden : '');
  const full = (emp ? [emp] : []).concat(rest).join(' · ');
  return { line, full, count: (emp?1:0)+rest.length };
}
function formatMonsterRankTag(m){
  if(m.boss) return 'Boss';
  if(m.isBossMinion) return '眷屬';
  const r = m.rank || (m.elite ? 'elite' : 'normal');
  const map = {elite:'精英',veteran:'百戰',refined:'千煉',king:'王者',emperor:'帝王'};
  return map[r] || '';
}

function renderBattle(){
  const b=S.battle;
  const monsterHtml = b.monsters.map((m,i)=>{
    // 顯示前清一次 NaN，避免 UI 出現 "NaN"
    m.maxHp = Math.max(1, num(m.maxHp, 1));
    m.hp = clamp(num(m.hp, 0), 0, m.maxHp);
    const dead = m.hp<=0;
    const hpPct = Math.round((m.hp/m.maxHp)*100);
    const rankTag = formatMonsterRankTag(m);
    const affixInfo = formatMonsterAffixDisplay(m);
    const affixTags = affixInfo.line
      ? `<div class="small mon-affix-line" style="color:var(--legend);" title="${esc(affixInfo.full)}">${esc(affixInfo.line)}</div>`
      : '';
    const markTag = (m.marked && m.markTurns>0) ? `<div class="small" style="color:var(--gold);">◎ 追蹤標記 ${m.markTurns}回合</div>` : '';
    const eliteTag = rankTag ? `<div class="small" style="color:var(--legend);">◆ ${esc(rankTag)}</div>` : '';
    return `
    <div class="monster-box ${dead?'dead':'target-selectable'}" data-tidx="${i}">
      <canvas class="sprite" id="mon-${i}" width="48" height="48"></canvas>
      <div class="monster-name">${m.boss?'👑 ':''}${esc(m.name)} Lv.${m.level}</div>
      ${eliteTag}${affixTags}${markTag}
      <div class="bar-wrap" style="width:70px;margin:2px auto;"><div class="bar bar-anim" style="width:${hpPct}%;background:var(--hp)"></div></div>
      <div class="small">${m.hp}/${m.maxHp}</div>
    </div>`;
  }).join('');

  const current = b.order[b.turnIndex];
  const isPlayerTurn = !b.over && current && current.type==='party';
  const actor = isPlayerTurn ? current.ref : null;

  const partyHtml = S.party.map((m,i)=>{
    const active = actor && actor.uid===m.uid;
    return memberCardHtml(m,i,{prefix:'bp',activeClass:active?'active-turn':'', compact:true, pidx:i});
  }).join('');

  let actionPanel='';
  if(b.over){
    let msg = b.win===true ? '🎉 戰鬥勝利！' : (b.win==='flee' ? '你們逃離了戰鬥。' : '💀 隊伍全滅，狼狽撤退……');
    actionPanel = `<div style="text-align:center;"><p class="pixel-font" style="font-size:13px;color:var(--gold);margin-bottom:10px;">${msg}</p><button class="btn gold btn-primary" id="back-hub">返回營地</button></div>`;
  } else if(isPlayerTurn){
    const skillBtns = getSkills(actor).map((sk,i)=>{
      const est = skillEstimate(actor, sk);
      const uTag = sk.fromUnique ? '⚔' : '';
      return `<button class="btn skill-btn ${sk.fromUnique?'skill-unique':''}" data-skill="${i}" ${actor.mp<num(sk.mp,0)?'disabled':''}>
        <div class="skill-btn-head"><span>${uTag}${esc(sk.name)}</span><span class="mp-cost">MP${sk.mp}</span></div>
        <div class="small skill-btn-desc">${esc(sk.desc)}</div>
        <div class="small skill-btn-est">${esc(est)}</div>
      </button>`;
    }).join('');
    const hpPotions = S.inventory.filter(i=>i.slot==='potion' && i.kind!=='mp');
    const mpPotions = S.inventory.filter(i=>i.slot==='potion' && i.kind==='mp');
    const potionBtns = [];
    const hpCount = hpPotions.reduce((a,p)=>a+(p.count||1),0);
    const mpCount = mpPotions.reduce((a,p)=>a+(p.count||1),0);
    if(hpCount) potionBtns.push(`<button class="btn btn-compact" data-item-potion="${hpPotions[0].uid}">🧪 HP藥水 ×${hpCount}</button>`);
    if(mpCount) potionBtns.push(`<button class="btn btn-compact" data-item-potion="${mpPotions[0].uid}">💧 MP藥水 ×${mpCount}</button>`);
    if(potionBtns.length===0) potionBtns.push(`<button class="btn btn-compact" disabled>🧪 藥水（無）</button>`);
    actionPanel = `
    <p class="small" style="text-align:center;">輪到 <b style="color:var(--gold)">${esc(actor.name)}</b> 行動 — 請選擇動作，再點擊目標怪物</p>
    <button class="btn gold btn-primary" data-act="attack">⚔️ 攻擊</button>
    <p class="action-label">技能</p>
    <div class="skill-grid">${skillBtns}</div>
    <p class="action-label">道具與防禦</p>
    <div class="utility-row">
      ${potionBtns.join('')}
      <button class="btn btn-compact" data-act="defend">🛡️ 防禦</button>
    </div>
    <button class="flee-link" data-act="flee">🏃 逃跑</button>`;
  } else {
    actionPanel = `<p class="small" style="text-align:center;">敵方行動中...</p>`;
  }

  const logHtml = b.turnLog.slice(0,8).map(l=>{
    let cls='';
    if(/會心|重擊|削砍/.test(l)) cls='log-crit';
    else if(/擊倒|倒下了/.test(l)) cls='log-kill';
    else if(/造成 \d+/.test(l) || /點傷害/.test(l)) cls='log-hit';
    return `<div class="${cls}">${esc(l)}</div>`;
  }).join('');

  return `
  <div class="panel">
    <p class="section-title">第 ${b.roundNum} 回合 ${b.monsters[0]&&b.monsters[0].boss?'— ⚠️ BOSS戰':''}</p>
    <div class="monster-row">${monsterHtml}</div>
    <div class="grid battle-party-grid">${partyHtml}</div>
    <hr class="divider">
    <div id="action-panel">${actionPanel}</div>
  </div>
  <div class="panel battle-log-panel">
    <p class="section-title">戰鬥紀錄</p>
    <div class="log-box battle-log-box">${logHtml}</div>
  </div>`;
}
let pendingAction=null;
let actionToken=0;

function processBattleFx(){
  const b = S.battle;
  if(!b || !b.fx || !b.fx.length) return;
  const list = b.fx.splice(0, b.fx.length);
  list.forEach(fx=>{
    if(fx.kind!=='hit') return;
    let el = null;
    if(fx.target==='monster') el = document.querySelector('.monster-box[data-tidx="'+fx.idx+'"]');
    else if(fx.target==='party'){
      el = document.querySelector('.battle-party-grid [data-pidx="'+fx.idx+'"]')
        || document.querySelector('.member-card[data-pidx="'+fx.idx+'"]');
      if(!el){
        const cv = document.getElementById('bp-'+fx.idx);
        if(cv) el = cv.closest('.member-card') || cv.parentElement;
      }
      if(!el){
        const cards = document.querySelectorAll('.battle-party-grid .member-card');
        el = cards[fx.idx] || null;
      }
    }
    if(!el) return;
    el.classList.remove('hit-shake','hit-flash','kill-pulse');
    void el.offsetWidth;
    el.classList.add('hit-shake','hit-flash');
    if(fx.kill) el.classList.add('kill-pulse');
    // 跳字
    const tag = document.createElement('div');
    tag.className = 'combat-float-dmg ' + (fx.miss?'miss':(fx.crit?'crit':(fx.magic?'magic':'normal')));
    if(fx.miss) tag.textContent = 'MISS';
    else tag.textContent = (fx.crit?'✦ ':'') + (-Math.abs(num(fx.dmg,0)));
    el.appendChild(tag);
    setTimeout(()=>{ try{ tag.remove(); }catch(e){} }, 750);
    setTimeout(()=>{ try{ el.classList.remove('hit-shake','hit-flash','kill-pulse'); }catch(e){} }, 280);
  });
  // hit-stop：短暫凍結互動
  const ms = num(b._hitstopMs, 0);
  b._hitstopMs = 0;
  if(ms > 0){
    const root = document.getElementById('screens') || document.body;
    root.classList.add('battle-hitstop');
    setTimeout(()=> root.classList.remove('battle-hitstop'), ms);
  }
}
function bindBattle(){
  const b=S.battle;
  processBattleFx();
  b.monsters.forEach((m,i)=> queueSprite('mon-'+i, m.seed||m.name, PALETTES[m.type]||PALETTES.beast, 16, {kind:'monster', type:m.type}));
  S.party.forEach((m,i)=> queueSprite('bp-'+i, (m.name||'hero')+'_'+m.uid, memberPalette(m), 14, {kind:'human'}));
  const backBtn = document.getElementById('back-hub');
  if(backBtn) backBtn.addEventListener('click', ()=>{ routeHome(); render(); });

  const current = b.order[b.turnIndex];
  if(!current || current.type!=='party' || b.over) return;
  const actor = current.ref;
  pendingAction=null; // fresh turn's DOM: any earlier pending selection is now stale

  document.querySelectorAll('[data-act]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const act = btn.dataset.act;
      if(act==='attack'){ pendingAction={type:'attack', token:++actionToken}; promptTarget(actor, pendingAction.token); }
      else if(act==='defend'){ playerAction(actor.uid,'defend'); }
      else if(act==='flee'){ playerAction(actor.uid,'flee'); }
    });
  });
  document.querySelectorAll('[data-item-potion]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      playerAction(actor.uid,'item',null,null,btn.dataset.itemPotion);
    });
  });
  document.querySelectorAll('[data-skill]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const skillIdx = parseInt(btn.dataset.skill);
      const sk = getSkills(actor)[skillIdx];
      if(sk.type==='heal'){
        pendingAction={type:'skill', skillIdx, token:++actionToken};
        promptAllyTarget(actor, pendingAction.token);
      } else if(['heal_aoe','buff','guard','self_heal'].includes(sk.type)){
        playerAction(actor.uid,'skill',null,skillIdx);
      } else {
        pendingAction={type:'skill', skillIdx, token:++actionToken};
        promptTarget(actor, pendingAction.token);
      }
    });
  });
  // 直接點擊怪物 = 預設觸發普通攻擊（若沒有其他技能正在等待選擇目標）
  document.querySelectorAll('.monster-box.target-selectable').forEach(box=>{
    box.addEventListener('click', function defaultAttackHandler(){
      if(pendingAction) return;
      const idx = parseInt(box.dataset.tidx);
      playerAction(actor.uid,'attack',idx);
    });
  });
}
function promptTarget(actor, token){
  document.querySelectorAll('.monster-box.target-selectable').forEach(box=>{
    box.addEventListener('click', function handler(){
      if(!pendingAction || pendingAction.token!==token) return;
      const idx = parseInt(box.dataset.tidx);
      if(pendingAction.type==='attack') playerAction(actor.uid,'attack',idx);
      else playerAction(actor.uid,'skill',idx,pendingAction.skillIdx);
      pendingAction=null;
    }, {once:true});
  });
}
function promptAllyTarget(actor, token){
  // 用 data-uid 對應隊友（避免 DOM 順序與 party 索引不一致）；允許倒地（可復活）
  document.querySelectorAll('.member-card').forEach((card)=>{
    card.style.cursor='pointer';
    card.addEventListener('click', function handler(){
      if(!pendingAction || pendingAction.token!==token) return;
      const uid = card.getAttribute('data-uid');
      const idx = S.party.findIndex(m=>m.uid===uid);
      if(idx < 0) return;
      playerAction(actor.uid,'skill',idx,pendingAction.skillIdx);
      pendingAction=null;
    }, {once:true});
  });
}

/** 推估裝備後相對目前裝備的屬性差（僅顯示主要戰鬥屬性） */
function resolveCompareSlot(member, item){
  ensureMemberEquip(member);
  if(item && EQUIP_SLOT_IDS.includes(item.slot)) return item.slot;
  return item ? item.slot : 'weapon';
}
function invCompareMeta(member, item){
  if(!item || item.slot==='potion') return {html:'', delta:0, empty:false, upgrade:false};
  ensureMemberEquip(member);
  const slot = resolveCompareSlot(member, item);
  const cur = member.equip[slot];
  const empty = !cur;
  const stats = ['atk','matk','def','spd','hp','mp','str','con','agi','int'];
  const parts=[];
  let deltaScore = 0;
  const weights = {atk:1.2,matk:1.2,def:1.0,spd:0.9,hp:0.08,mp:0.06,str:1.1,con:1.0,agi:1.0,int:1.1};
  stats.forEach(st=>{
    const d = itemStatSum(item, st) - itemStatSum(cur, st);
    if(d===0) return;
    deltaScore += d * (weights[st]||1);
    const cls = d>0 ? 'delta-up' : 'delta-down';
    const sign = d>0 ? '+' : '';
    parts.push(`<span class="${cls}">${statLabel(st)} ${sign}${d}</span>`);
  });
  let html;
  if(empty) html = `<div class="inv-compare"><span class="delta-up">空槽可直接裝備</span></div>`;
  else if(!parts.length) html = `<div class="inv-compare delta-same">與目前裝備數值相近</div>`;
  else html = `<div class="inv-compare">相對已裝備：${parts.join(' · ')}</div>`;
  return {html, delta:deltaScore, empty, upgrade: empty || deltaScore > 0.5};
}
function invCompareHtml(member, item){
  return invCompareMeta(member, item).html;
}
function slotLabelOf(slot){
  const d = EQUIP_SLOT_DEFS.find(s=>s.id===slot);
  return d ? d.label : (slot||'');
}
function sortInventory(mode){
  if(!S || !S.inventory) return;
  const rank = (id)=>{ const i=RARITIES.findIndex(r=>r.id===id); return i<0?0:i; };
  const pots = S.inventory.filter(i=>i.slot==='potion');
  const gear = S.inventory.filter(i=>i.slot!=='potion');
  if(mode==='rarity'){
    gear.sort((a,b)=> rank(b.rarity)-rank(a.rarity) || itemPowerScore(b)-itemPowerScore(a));
  } else if(mode==='slot'){
    const order = ['weapon','offhand','armor','head','cape','hands','feet','accessory'];
    gear.sort((a,b)=>{
      const ia = order.indexOf(a.slot), ib = order.indexOf(b.slot);
      return (ia<0?99:ia)-(ib<0?99:ib) || rank(b.rarity)-rank(a.rarity);
    });
  } else if(mode==='level'){
    gear.sort((a,b)=> (b.itemLevel||1)-(a.itemLevel||1) || rank(b.rarity)-rank(a.rarity));
  } else {
    // name
    gear.sort((a,b)=> String(a.name).localeCompare(String(b.name),'zh'));
  }
  pots.sort((a,b)=> String(a.kind).localeCompare(String(b.kind)) || (b.value||0)-(a.value||0));
  S.inventory = gear.concat(pots);
  if(S.log) S.log.unshift('背包已整理（'+({rarity:'稀有度',slot:'欄位',level:'等級',name:'名稱'}[mode]||mode)+'）。');
}

function renderInventory(){
  S.party.forEach(m=>{ ensureMemberEquip(m); applyComputedStats(m); });
  const selMember = S.party.find(m=>m.uid===S.invSelectedUid) || S.hero;
  ensureMemberEquip(selMember);
  if(!S.invFilter) S.invFilter = 'all';
  if(!S.invSort) S.invSort = 'rarity';
  const filter = S.invFilter;
  const GRID = BACKPACK_CAP; // 背包硬上限；多的自動進倉庫

  const memberTabs = S.party.map(m=>`
    <button class="btn ${m.uid===selMember.uid?'active':''}" data-selmember="${m.uid}">
      ${esc(m.name)}${m.isHero?' ★':''}
    </button>`).join('');

  const hpPct = Math.max(0, Math.min(100, Math.round((selMember.hp/Math.max(1,selMember.maxHp))*100)));
  const mpPct = Math.max(0, Math.min(100, Math.round((selMember.mp/Math.max(1,selMember.maxMp||1))*100)));

  // 紙娃娃裝備格
  const dollHtml = EQUIP_SLOT_DEFS.map(def=>{
    const item = selMember.equip[def.id];
    const can = !item && S.inventory.some(i=>i.slot===def.id);
    if(!item){
    
  return `<div class="bp-slot empty ${can?'empty-can':''}" data-area="${def.area}" data-dollslot="${def.id}">
        <div class="sl">${def.label}</div>
        <div class="sn">${can?'可裝備':'空'}</div>
      </div>`;
    }
    return `<div class="bp-slot ${S.invSelectedItemUid===item.uid?'selected':''}" data-area="${def.area}" data-dollslot="${def.id}" data-equid="${item.uid}">
      <canvas class="sprite" id="eq-${def.id}" width="36" height="36"></canvas>
      <div class="sl">${def.label}</div>
      <div class="sn rarity-${item.rarity}">${esc(item.name)}</div>
    </div>`;
  }).join('');

  // 篩選
  ensureWarehouse();
  const bagMode = filter === 'warehouse' ? 'warehouse' : 'bag';
  const filters = [
    {id:'all',label:'全部'},{id:'weapon',label:'武器'},{id:'offhand',label:'副手'},
    {id:'armor',label:'胸甲'},{id:'head',label:'頭部'},{id:'cape',label:'披風'},
    {id:'hands',label:'手套'},{id:'feet',label:'鞋子'},{id:'accessory',label:'飾品'},
    {id:'potion',label:'藥水'},{id:'upgrade',label:'可升級'},{id:'warehouse',label:'倉庫'}
  ];
  const filterHtml = filters.map(f=>`
    <button class="btn ${filter===f.id?'active':''}" data-invfilter="${f.id}">${f.label}</button>
  `).join('');

  let filtered;
  if(filter==='warehouse'){
    filtered = (S.warehouse||[]).slice();
  } else {
    filtered = S.inventory.filter(item=>{
      if(filter==='all') return true;
      if(filter==='potion') return item.slot==='potion';
      if(filter==='upgrade'){
        if(item.slot==='potion') return false;
        return invCompareMeta(selMember, item).upgrade;
      }
      return item.slot===filter;
    });
  }

  // 倉庫分頁
  if(filter==='warehouse'){
    if(S.warePage == null || S.warePage < 0) S.warePage = 0;
    const totalPages = Math.max(1, Math.ceil(Math.max(filtered.length, 1) / WAREHOUSE_PAGE_SIZE));
    if(S.warePage >= totalPages) S.warePage = totalPages - 1;
  } else {
    S.warePage = 0;
  }
  const warePage = filter==='warehouse' ? (S.warePage||0) : 0;
  const wareTotalPages = filter==='warehouse'
    ? Math.max(1, Math.ceil(Math.max(filtered.length, 1) / WAREHOUSE_PAGE_SIZE))
    : 1;
  const pageStart = filter==='warehouse' ? warePage * WAREHOUSE_PAGE_SIZE : 0;
  const pageItems = filter==='warehouse'
    ? filtered.slice(pageStart, pageStart + WAREHOUSE_PAGE_SIZE)
    : filtered;

  // 背包格（固定 GRID 格）；倉庫只顯示當前頁
  const cells = [];
  const cellCap = filter==='warehouse' ? WAREHOUSE_PAGE_SIZE : GRID;
  for(let i=0;i<cellCap;i++){
    const item = filter==='warehouse' ? pageItems[i] : filtered[i];
    if(!item){
      cells.push(`<div class="bp-cell empty" title="${filter==='warehouse'?'倉庫空位':'背包空位'}"></div>`);
      continue;
    }
    const realIdx = filter==='warehouse' ? -1 : S.inventory.indexOf(item);
    const sel = S.invSelectedItemUid===item.uid ? 'selected' : '';
    if(item.slot==='potion'){
      const icon = item.kind==='mp' ? '💧' : '🧪';
      const cnt = item.count||1;
      cells.push(`<div class="bp-cell ${sel}" data-invuid="${item.uid}" title="${esc(item.name)}">
        <span style="font-size:22px;line-height:1;">${icon}</span>
        ${cnt>1?`<span class="cnt">×${cnt}</span>`:''}
      </div>`);
    } else {
      const meta = invCompareMeta(selMember, item);
      const tag = filter==='warehouse' ? '<span class="tag fit">倉</span>' : (meta.empty ? '<span class="tag fit">裝</span>' : (meta.upgrade ? '<span class="tag up">↑</span>' : ''));
      const canvasId = filter==='warehouse' ? ('wh-'+i) : ('inv-'+realIdx);
      const uidAttr = filter==='warehouse' ? `data-invuid="${item.uid}"` : `data-invuid="${item.uid}"`;
      cells.push(`<div class="bp-cell ${sel}" ${uidAttr} title="${esc(item.name)}">
        ${tag}
        <canvas class="sprite" id="${canvasId}" width="40" height="40"></canvas>
      </div>`);
    }
  }

  // 詳情面板
  let detailHtml = '';
  const selItem = S.invSelectedItemUid
    ? (S.inventory.find(i=>i.uid===S.invSelectedItemUid)
        || (S.warehouse||[]).find(i=>i.uid===S.invSelectedItemUid)
        || EQUIP_SLOT_IDS.map(s=>selMember.equip[s]).find(eq=>eq && eq.uid===S.invSelectedItemUid))
    : null;
  if(!selItem){
    detailHtml = `<div class="meta">點選背包中的物品或左側裝備，查看詳情。<br>空槽已預留，之後可放劇情／收藏道具。</div>`;
  } else if(selItem.slot==='potion'){
    const statName = selItem.kind==='mp' ? 'MP' : 'HP';
    detailHtml = `
      <div class="ttl">${selItem.kind==='mp'?'💧':'🧪'} <b>${esc(selItem.name)}</b> ×${selItem.count||1}</div>
      <div class="meta">類型：消耗品<br>效果：恢復 ${selItem.value} ${statName}</div>
      <div class="bp-detail-actions">
        <button class="btn gold" data-usepot="${selItem.uid}">對 ${esc(selMember.name)} 使用</button>
      </div>`;
  } else {
    const onDoll = EQUIP_SLOT_IDS.some(s=>selMember.equip[s] && selMember.equip[s].uid===selItem.uid);
    const meta = invCompareMeta(selMember, selItem);
    const uEff = (selItem.isUnique||selItem.rarity==='unique') ? uniqueEffectDesc(selItem) : '';
    const uSk = (selItem.isUnique||selItem.rarity==='unique') ? getUniqueSkill(selItem) : null;
    const resNote = resonanceDesc(selItem);
    detailHtml = `
      <div class="ttl"><span class="rarity-${selItem.rarity}">${esc(selItem.name)}</span></div>
      <div class="meta">
        欄位：${slotLabelOf(selItem.slot)} · Lv.${selItem.itemLevel||1}${(selItem.isUnique||selItem.rarity==='unique')?' · 唯一':''}${selItem.rarity==='ancient'?' · 千古':''}<br>
        ${equipAffixText(selItem)}
        ${uEff?`<br><span style="color:var(--r-unique)">✦ 被動：${esc(uEff)}</span>`:''}
        ${uSk?`<br><span style="color:var(--r-unique)">⚔ 專屬技能「${esc(uSk.name)}」MP${uSk.mp} — ${esc(uSk.desc||'')}</span>`:''}
        ${resNote?`<br><span style="color:var(--r-ancient)">✦ 共鳴·${esc(resNote)}</span>`:''}
        ${meta.html}
      </div>
      <div class="bp-detail-actions">
        ${onDoll
          ? `<button class="btn" data-unequip="${selItem.slot}">卸下</button>`
          : (filter==='warehouse'
              ? `<button class="btn gold" data-withdraw="${selItem.uid}">取出到背包</button>`
              : `<button class="btn gold" data-equip="${selItem.uid}">裝備 → ${esc(selMember.name)}</button>
                 <button class="btn" data-deposit="${selItem.uid}">存入倉庫</button>`)}
      </div>`;
  }

  const bonusBits = ['atk','matk','def','spd','hp','str','int'].map(st=>{
    const b = equipBonus(selMember, st);
    if(!b) return '';
    return `<span>${statLabel(st)} <b class="delta-up">+${b}</b></span>`;
  }).filter(Boolean).join(' · ') || '<span class="delta-same">無裝備加成</span>';

  let modalHtml = '';
  if(S.itemModalUid){
    const mItem = (filter==='warehouse' ? (S.warehouse||[]) : S.inventory).find(i=>i.uid===S.itemModalUid)
      || Object.values(selMember.equip||{}).find(i=>i && i.uid===S.itemModalUid)
      || (S.warehouse||[]).find(i=>i.uid===S.itemModalUid)
      || S.inventory.find(i=>i.uid===S.itemModalUid);
    if(mItem && mItem.slot!=='potion'){
      const meta = invCompareMeta(selMember, mItem);
      const uEff = (mItem.isUnique||mItem.rarity==='unique') ? uniqueEffectDesc(mItem) : '';
      const uSk = (mItem.isUnique||mItem.rarity==='unique') ? getUniqueSkill(mItem) : null;
      const resNote = typeof resonanceDesc==='function' ? resonanceDesc(mItem) : '';
      const onDoll = Object.values(selMember.equip||{}).some(e=>e && e.uid===mItem.uid);
      const uniqueBlocked = (mItem.isUnique||mItem.rarity==='unique') && uniqueAlreadyEquipped(mItem, mItem.uid);
      modalHtml = `
      <div class="item-modal-mask" id="item-modal-mask">
        <div class="item-modal" style="position:relative;">
          <button class="btn" id="item-modal-close" style="position:absolute;right:8px;top:8px;padding:4px 10px;">關閉</button>
          <div class="im-title"><span class="rarity-${mItem.rarity}">${esc(mItem.name)}</span></div>
          <div class="im-meta">
            欄位：${slotLabelOf(mItem.slot)} · Lv.${mItem.itemLevel||1}
            ${(mItem.isUnique||mItem.rarity==='unique')?' · <b>唯一</b>':''}${mItem.rarity==='ancient'?' · 千古':''}<br>
            ${equipAffixText(mItem)}
            ${uEff?`<br><span style="color:var(--r-unique)">✦ 被動：${esc(uEff)}</span>`:''}
            ${uSk?`<br><span style="color:var(--r-unique)">⚔ 技能「${esc(uSk.name)}」MP${uSk.mp} — ${esc(uSk.desc||'')}</span>`:''}
            ${resNote?`<br><span style="color:var(--r-ancient)">✦ 共鳴·${esc(resNote)}</span>`:''}
            <div class="inv-compare">${meta.html||''}</div>
            ${uniqueBlocked?'<div style="color:#e07a7a;margin-top:4px;">全隊已有隊員裝備同名唯一，無法再裝備（可放倉庫收藏）。</div>':''}
          </div>
          <div class="im-actions">
            ${onDoll
              ? `<button class="btn" data-unequip="${mItem.slot}">卸下</button>`
              : (filter==='warehouse'
                  ? `<button class="btn gold" data-withdraw="${mItem.uid}">取出到背包</button>`
                  : `<button class="btn gold" data-equip="${mItem.uid}" ${uniqueBlocked?'disabled':''}>裝備 → ${esc(selMember.name)}</button>
                     <button class="btn" data-deposit="${mItem.uid}">存入倉庫</button>`)}
            <button class="btn" id="item-modal-close-2">關閉</button>
          </div>
        </div>
      </div>`;
    }
  }

  return `
  <div class="panel bp-wrap">
    <p class="section-title">BACKPACK · 隊伍整備</p>
    <div class="inv-bonus-line" style="margin-bottom:6px;">
      背包裝備 <b>${backpackGearCount()}/${BACKPACK_CAP}</b>
      · 倉庫 <b>${(S.warehouse||[]).length}/${WAREHOUSE_CAP}</b>
      · 滿包掉落會自動進倉庫，倉庫滿則折價出售
    </div>
    <div class="bp-member-tabs">${memberTabs}</div>
    <div class="bp-main">
      <div class="bp-left">
        <div class="bp-char">
          <canvas class="sprite" id="inv-hero-sprite" width="64" height="64" style="width:64px;height:64px;"></canvas>
          <div class="bp-char-meta">
            <div class="nm">${esc(selMember.name)}</div>
            <div>Lv.${selMember.level} · ${esc(displayClassName(selMember))}</div>
            <div class="bp-bars">
              <div class="bp-bar-row"><span>HP</span><div class="bp-bar hp"><i style="width:${hpPct}%"></i></div><b>${selMember.hp}/${selMember.maxHp}</b></div>
              <div class="bp-bar-row"><span>MP</span><div class="bp-bar mp"><i style="width:${mpPct}%"></i></div><b>${selMember.mp}/${selMember.maxMp}</b></div>
            </div>
            <div class="bp-gold-exp">
              <span>金幣 <b>${S.hero.gold||0}</b></span>
              <span>EXP <b>${selMember.exp||0}/${selMember.nextExp||expForLevel(selMember.level)}</b></span>
            </div>
          </div>
        </div>
        <p class="bp-equip-title">EQUIPMENT</p>
        <div class="bp-doll">${dollHtml}</div>
        <div class="inv-bonus-line" style="margin-top:8px;">裝備加成：${bonusBits}</div>
        <div class="inv-bonus-line">物攻 ${statTotal(selMember,'atk')} · 魔攻 ${statTotal(selMember,'matk')} · 防 ${statTotal(selMember,'def')} · 速 ${statTotal(selMember,'spd')}</div>
      </div>
      <div class="bp-right">
        <div class="bp-toolbar">
          ${filterHtml}
        </div>
        <div class="bp-toolbar">
          <span class="small" style="margin-right:4px;">整理</span>
          <button class="btn" data-invsort="rarity">稀有度</button>
          <button class="btn" data-invsort="slot">欄位</button>
          <button class="btn" data-invsort="level">等級</button>
          <button class="btn" data-invsort="name">名稱</button>
        </div>
        ${filter==='warehouse' ? `
        <div class="bp-toolbar" style="justify-content:center;align-items:center;gap:8px;">
          <button class="btn" id="ware-page-prev" ${warePage<=0?'disabled':''}>◀ 上一頁</button>
          <span class="small">倉庫第 <b>${warePage+1}</b> / ${wareTotalPages} 頁</span>
          <span class="small">（${filtered.length}/${WAREHOUSE_CAP}）</span>
          <button class="btn" id="ware-page-next" ${warePage>=wareTotalPages-1?'disabled':''}>下一頁 ▶</button>
        </div>` : ''}
        <div class="bp-grid">${cells.join('')}</div>
      </div>
    </div>
    <div class="bp-detail">${detailHtml}</div>
    <div style="text-align:center;margin-top:4px;"><button class="btn" id="back-hub2">返回營地</button></div>
  </div>
  ${modalHtml}`;
}
function statLabel(s){
  return {
    atk:'物攻', matk:'魔攻', def:'防禦', spd:'速度',
    hp:'生命', mp:'魔力',
    str:'力量', con:'體質', agi:'敏捷', int:'智力',
    heal:'治療', luck:'幸運'
  }[s]||s;
}
function equipAffixText(item){
  if(item.affixes && item.affixes.length){
    return item.affixes.map(a=>{
      const tag = a.label && a.label!=='主屬性' ? a.label+' ' : '';
      return tag+'+'+a.value+' '+statLabel(a.stat);
    }).join(' · ');
  }
  let s = '+'+item.value+' '+statLabel(item.stat);
  if(item.extraStat) s += ' · 額外+'+item.extraValue+' '+statLabel(item.extraStat);
  return s;
}
function skillEstimate(actor, sk){
  const atk = statTotal(actor,'atk');
  const matk = statTotal(actor,'matk');
  const cc = Math.round(critChance(actor, sk)*100);
  switch(sk.type){
    case 'phys':
      return '預估 ~'+Math.round(atk*(sk.mult||1))+' 物傷（物攻×'+ (sk.mult||1) +'−防×0.5）';
    case 'phys_crit':
      return '預估 ~'+Math.round(atk*(sk.mult||1))+' 物傷，爆擊率約 '+(sk.crit!=null?Math.round(sk.crit*100):Math.max(cc,45))+'%（×'+CF.CRIT_MULT+'）';
    case 'phys_multi':
    case 'phys_multi2': {
      const hits = sk.hits || (sk.type==='phys_multi'?3:2);
      return '預估總傷 ~'+Math.round(atk*(sk.mult||1)*hits)+'（'+hits+' 連擊，每段物攻×'+(sk.mult||1)+'）';
    }
    case 'magic':
      return '預估 ~'+Math.round(matk*(sk.mult||1))+' 魔傷（魔攻×'+(sk.mult||1)+'−防×0.25）'+(sk.holy?'；對邪惡×1.25':'');
    case 'magic_aoe':
      return '預估 ~'+Math.round(matk*(sk.mult||1))+'/敵（魔攻×'+(sk.mult||1)+'）';
    case 'magic_dot':
      return '預估 ~'+Math.round(matk*(sk.mult||1))+'/敵 + 中毒'+(sk.poisonTurns||3)+'回合';
    case 'heal':
      return '預估治療 ~'+calcHealAmt(actor, sk.heal||1)+' HP（魔攻×係數+智力×0.6+Lv×2）';
    case 'heal_aoe':
      return '預估群體治療 ~'+calcHealAmt(actor, sk.heal||0.8)+' HP／人';
    case 'self_heal':
      return '恢復 ~'+Math.round(actor.maxHp*(sk.heal||0.2))+' HP + '+(sk.mpGain!=null?sk.mpGain:10)+' MP';
    case 'buff':
      return '全隊防禦+'+(Math.round((sk.buffDefRatio!=null?sk.buffDefRatio:0.2)*100))+'%，'+(sk.buffTurns||2)+' 回合';
    case 'guard':
      return '嘲諷 + 自身防禦+'+(Math.round((sk.buffDefRatio!=null?sk.buffDefRatio:0.6)*100))+'%，'+(sk.buffTurns||2)+' 回合';
    case 'steal':
      return '物傷（×'+(sk.mult||1.1)+'）+ 偷取 '+(sk.stealMin||5)+'~'+(sk.stealMax||15)+' 金';
    case 'mark':
      return '輔助：標記 '+(sk.markTurns||3)+' 回合，受傷+' + Math.round(((sk.markMult||1.35)-1)*100) + '%';
    default: return '';
  }
}
function bindInventory(){
  const selMember = S.party.find(m=>m.uid===S.invSelectedUid) || S.hero;
  ensureMemberEquip(selMember);
  // 角色立繪
  const heroCv = document.getElementById('inv-hero-sprite');
  if(heroCv) drawSprite(heroCv, (selMember.name||'hero')+'_'+selMember.uid, memberPalette(selMember), 16, {kind:'human', gender: selMember.gender || (typeof guessGenderFromName==='function'?guessGenderFromName(selMember.name):null)});
  EQUIP_SLOT_IDS.forEach(slot=>{
    const item = selMember.equip[slot];
    const cv = document.getElementById('eq-'+slot);
    if(item && cv){
      const kind = (slot==='weapon'||slot==='offhand') ? 'weapon' : (slot==='accessory' ? 'accessory' : 'armor');
      drawEquipIcon(cv, item.seed, kind, item.rarityHex);
    }
  });
  S.inventory.forEach((item,i)=>{
    if(item.slot==='potion') return;
    const el = document.getElementById('inv-'+i);
    if(el){
      const kind = (item.slot==='weapon'||item.slot==='offhand') ? 'weapon' : (item.slot==='accessory' ? 'accessory' : 'armor');
      drawEquipIcon(el, item.seed, kind, item.rarityHex);
    }
  });

  document.querySelectorAll('[data-selmember]').forEach(btn=> btn.addEventListener('click', ()=>{
    S.invSelectedUid = btn.dataset.selmember;
    S.invSelectedItemUid = null;
    render();
  }));
  document.querySelectorAll('[data-invfilter]').forEach(btn=> btn.addEventListener('click', ()=>{
    S.invFilter = btn.dataset.invfilter;
    S.invSelectedItemUid = null;
    if(S.invFilter==='warehouse') S.warePage = 0;
    render();
  }));
  document.querySelectorAll('[data-invsort]').forEach(btn=> btn.addEventListener('click', ()=>{
    sortInventory(btn.dataset.invsort);
    render();
  }));
  document.querySelectorAll('[data-invuid]').forEach(btn=> btn.addEventListener('click', ()=>{
    S.invSelectedItemUid = btn.dataset.invuid;
    S.itemModalUid = btn.dataset.invuid;
    render();
  }));
  document.querySelectorAll('[data-equid]').forEach(btn=> btn.addEventListener('click', ()=>{
    if(btn.dataset.equid){
      S.invSelectedItemUid = btn.dataset.equid;
      S.itemModalUid = btn.dataset.equid;
      render();
    }
  }));
  document.querySelectorAll('[data-unequip]').forEach(btn=> btn.addEventListener('click', ()=> {
    unequipItem(btn.dataset.unequip, selMember.uid);
    S.invSelectedItemUid = null;
  }));
  document.querySelectorAll('[data-equip]').forEach(btn=> btn.addEventListener('click', ()=>{
    const item = S.inventory.find(i=>i.uid===btn.dataset.equip);
    if(item) equipItem(item, selMember.uid);
  }));
  document.querySelectorAll('[data-usepot]').forEach(btn=> btn.addEventListener('click', ()=>{
    const item = S.inventory.find(i=>i.uid===btn.dataset.usepot);
    if(item) usePotionOutOfBattle(item, selMember.uid);
  }));
  document.querySelectorAll('[data-deposit]').forEach(btn=> btn.addEventListener('click', ()=>{
    depositToWarehouse(btn.dataset.deposit);
    S.invSelectedItemUid = null;
    render();
  }));
  document.querySelectorAll('[data-withdraw]').forEach(btn=> btn.addEventListener('click', ()=>{
    withdrawFromWarehouse(btn.dataset.withdraw);
    S.invSelectedItemUid = null;
    render();
  }));
  const prevP = document.getElementById('ware-page-prev');
  const nextP = document.getElementById('ware-page-next');
  if(prevP) prevP.addEventListener('click', ()=>{
    S.warePage = Math.max(0, (S.warePage||0) - 1);
    S.invSelectedItemUid = null;
    render();
  });
  if(nextP) nextP.addEventListener('click', ()=>{
    const total = Math.max(1, Math.ceil(((S.warehouse||[]).length || 1) / WAREHOUSE_PAGE_SIZE));
    S.warePage = Math.min(total - 1, (S.warePage||0) + 1);
    S.invSelectedItemUid = null;
    render();
  });
  const closeModal = ()=>{ S.itemModalUid = null; render(); };
  const c1 = document.getElementById('item-modal-close');
  const c2 = document.getElementById('item-modal-close-2');
  if(c1) c1.addEventListener('click', closeModal);
  if(c2) c2.addEventListener('click', closeModal);
  const mask = document.getElementById('item-modal-mask');
  if(mask) mask.addEventListener('click', (e)=>{ if(e.target===mask) closeModal(); });

  // 倉庫頁 icon（僅當前頁）
  if(S.invFilter==='warehouse'){
    const page = S.warePage||0;
    const start = page * WAREHOUSE_PAGE_SIZE;
    const pageItems = (S.warehouse||[]).slice(start, start + WAREHOUSE_PAGE_SIZE);
    pageItems.forEach((item,i)=>{
      if(!item || item.slot==='potion') return;
      const el = document.getElementById('wh-'+i);
      if(el){
        const kind = (item.slot==='weapon'||item.slot==='offhand') ? 'weapon' : (item.slot==='accessory' ? 'accessory' : 'armor');
        drawEquipIcon(el, item.seed, kind, item.rarityHex);
      }
    });
  }
  const back = document.getElementById('back-hub2');
  if(back) back.addEventListener('click', ()=>{ routeHome(); render(); });
}

