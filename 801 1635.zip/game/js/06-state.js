/* ============ 遊戲狀態 ============ */
let S = null; // 全域 state
function newGame(){
  const hero = buildMember('你', 1);
  hero.gold = 50;
  hero.isHero = true;
  S = {
    screen:'hub',
    hero,
    party:[hero],
    inventory:[{uid:'pot_start',slot:'potion',kind:'hp',name:'治療藥水',value:60,count:1}],
    warehouse:[],
    log:[],
    battle:null,
    daysSurvived:0,
    event:null,
    pendingStage:null,
    shopStock:null,
    shopTab:'buy',
    invSelectedUid:hero.uid,
    tavernStock:null,
    wareFilter:'all',
    warePage:0
  };
  render();
}
function routeHome(){
  // 修復：每次回營地重算轉職，避免 pendingStage 遺失後卡死
  if(S.hero) evaluateEvolution(S.hero);
  if(S.pendingStage==='profession') S.screen='evolve-profession';
  else if(S.pendingStage==='class') S.screen='evolve-class';
  else if(S.pendingStage==='branch') S.screen='evolve-branch';
  else S.screen='hub';
}

